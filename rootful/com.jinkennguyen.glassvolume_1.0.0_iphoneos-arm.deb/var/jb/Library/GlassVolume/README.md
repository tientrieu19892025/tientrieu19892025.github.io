# GlassVolume — Liquid Glass Volume HUD for iOS

**GlassVolume** là tweak tinh chỉnh thanh âm lượng iOS chuyên nghiệp, đổi vị trí sang cạnh phải màn hình với phong cách Liquid Glass (Kính lỏng) đẳng cấp.

## Tính năng chính
- **Đổi vị trí thanh âm lượng sang phải**: Dễ dàng thao tác bằng một tay (cùng tùy chọn vị trí trên/trái).
- **Giao diện Liquid Glass**: Tích hợp khúc xạ kính, hiệu ứng vát mép pha lê, vết loé sáng specular và chiều sâu gradient.
- **5 Chủ đề kính độc đáo**: Liquid Clear, Frosted Glass, Deep Ocean, Neon Cyan Glow, Dark Obsidian.
- **Bước âm lượng chuẩn xác**: Tùy chỉnh 16, 32, 64, 100 bước tăng giảm âm lượng siêu mượt.
- **Rung phản hồi xúc giác (Haptic Feedback)**: Rung nhẹ theo từng nấc tăng giảm.
- **Tích hợp Cài đặt hoàn chỉnh**: Đầy đủ thẻ cài đặt chuyên nghiệp, hiển thị chuẩn trong Cài đặt iOS, hỗ trợ đa ngôn ngữ Anh - Việt.
- **Hỗ trợ đầy đủ các bản Jailbreak**: Rootless (Dopamine), Rootful (unc0ver/palera1n), RootHide.

## Thông tin tác giả & Quyên góp
- **Tác giả (Developer)**: Jinken Nguyen - 1989
- **Ngân hàng (Bank)**: MB Bank
- **Số tài khoản (Account)**: `0345140889`
- **Chủ tài khoản (Owner)**: Nguyễn Tiến Triều
