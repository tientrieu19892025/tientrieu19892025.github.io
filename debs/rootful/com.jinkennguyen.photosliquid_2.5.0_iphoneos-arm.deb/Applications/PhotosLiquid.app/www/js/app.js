// 50 Toggles definitions with dynamic actions and active bindings
const SETTINGS_SECTIONS = [
  {
    title: "1. HIỂN THỊ LƯỚI & NGHỆ THUẬT ẢNH",
    items: [
      { id: "enhancedGrid", name: "Bo góc lưới ảnh mượt mà (18pt)", desc: "Góc ảnh cong mềm tự nhiên", default: true },
      { id: "gridGlowBorder", name: "Viền sáng ngọc trai (Glow Outline)", desc: "Đường viền kính phản chiếu đa sắc", default: true },
      { id: "aspectFitGrid", name: "Xem tỉ lệ ảnh gốc không cắt xén", desc: "Ảnh giữ trọn vẹn khung hình", default: false },
      { id: "perspective3D", name: "Hiệu ứng thị sai nghiêng 3D", desc: "Ảnh nghiêng chuyển động nhẹ", default: true },
      { id: "glassCardGrid", name: "Khung thẻ kính nổi sang trọng", desc: "Đổ bóng đa lớp nổi bật", default: true },
      { id: "dynamicMesh", name: "Nền cực quang Ambient Aurora", desc: "Chuyển sắc mượt mà không chói", default: true },
      { id: "microZoom", name: "Phóng to lướt nhẹ khi chạm", desc: "Cảm giác chạm trực quan chân thực", default: true },
      { id: "assetBadge", name: "Hiện thời lượng video trên ảnh", desc: "Thời gian video rõ ràng", default: true },
      { id: "cleanGrid", name: "Ẩn các nhãn thông tin phụ", desc: "Tập trung tối đa vào bức ảnh", default: false },
      { id: "oledDark", name: "Chế độ OLED Đen sâu thẳm", desc: "Tiết kiệm pin màn hình OLED", default: false }
    ]
  },
  {
    title: "2. BỘ LỌC & NHÓM ẢNH THÔNG MINH",
    items: [
      { id: "separateVideos", name: "Tách riêng bộ sưu tập Video", desc: "Xem nhanh các clip trong máy", default: true },
      { id: "groupScreenshots", name: "Nhóm ảnh chụp màn hình", desc: "Tự động phân loại screenshot", default: true },
      { id: "groupPortraits", name: "Nhóm ảnh chân dung xoá phông", desc: "Lọc ảnh Portrait chất lượng", default: true },
      { id: "groupRAW", name: "Nhóm ảnh RAW chuyên nghiệp", desc: "Dành cho nhiếp ảnh gia", default: false },
      { id: "groupBursts", name: "Nhóm ảnh chụp liên tục", desc: "Quản lý chùm ảnh gọn gàng", default: false },
      { id: "groupAnimated", name: "Nhóm ảnh động GIF", desc: "Duyệt nhanh ảnh chuyển động", default: false },
      { id: "groupSelfies", name: "Nhóm ảnh selfie mặt trước", desc: "Tập hợp các bức ảnh tự chụp", default: false },
      { id: "groupLivePhotos", name: "Nhóm ảnh Live Photos", desc: "Xem riêng bộ sưu tập Live", default: true },
      { id: "smartDuplicate", name: "Lọc ảnh tương tự nhau", desc: "Gợi ý dọn dẹp dung lượng", default: false },
      { id: "hideHiddenAlbum", name: "Khoá ẩn hoàn toàn Album ẩn", desc: "Bảo vệ riêng tư tối đa", default: false }
    ]
  },
  {
    title: "3. TRÌNH XEM ẢNH FULLSCREEN",
    items: [
      { id: "infiniteZoom", name: "Thu phóng vô hạn (Infinite Zoom)", desc: "Zoom ảnh siêu nét căng", default: true },
      { id: "quickFav", name: "Thả tim 1 chạm ❤️", desc: "Thêm vào danh sách yêu thích", default: true },
      { id: "quickCopy", name: "Sao chép ảnh vào Clipboard", desc: "Dán nhanh qua Zalo, Messenger", default: true },
      { id: "showExif", name: "Xem thông số máy ảnh & kích thước", desc: "Hiện pixel, ngày chụp", default: true },
      { id: "quickFlip", name: "Lật ảnh đối xứng ngang", desc: "Đổi hướng ảnh lập tức", default: false },
      { id: "quickRotate", name: "Xoay ảnh 90 độ tức thì", desc: "Xoay chiều trực quan", default: true },
      { id: "fastDelete", name: "Xoá ảnh nhanh khỏi máy", desc: "Thao tác dọn dẹp tiện lợi", default: true },
      { id: "showFileSize", name: "Hiện kích thước ảnh", desc: "Biết ngay thông số ảnh", default: true },
      { id: "swipeDownDismiss", name: "Vuốt xuống để đóng ảnh", desc: "Thao tác cử chỉ mượt mà", default: true },
      { id: "protectWithLock", name: "Bảo mật riêng tư khi xem", desc: "Chống nhìn trộm", default: false }
    ]
  },
  {
    title: "4. TRÌNH PHÁT VIDEO THẾ HỆ MỚI",
    items: [
      { id: "autoLoop", name: "Tự động phát lại video (Loop)", desc: "Lặp lại vô hạn mượt mà", default: true },
      { id: "autoUnmute", name: "Tự động bật âm thanh khi xem", desc: "Không cần nhấn nút loa", default: false },
      { id: "doubleTapSeek", name: "Chạm 2 lần để tua video", desc: "Điều hướng video nhanh", default: true },
      { id: "saveFrame", name: "Trích xuất khung hình video sắc nét", desc: "Lưu frame đẹp thành ảnh tĩnh", default: true },
      { id: "hold2X", name: "Nhấn giữ màn hình tua 2X", desc: "Tăng tốc độ phát video", default: true },
      { id: "smooth60fps", name: "Chuyển động video mượt mà 60/120fps", desc: "Tối ưu hóa GPU ProMotion", default: true },
      { id: "pipMode", name: "Xem video dạng cửa sổ nổi", desc: "Vừa xem vừa lướt ảnh khác", default: false },
      { id: "videoMuteDefault", name: "Tắt tiếng video xem trước", desc: "Tránh ồn nơi công cộng", default: true },
      { id: "rememberPlayback", name: "Ghi nhớ đoạn đang phát dở", desc: "Tiếp tục xem khi mở lại", default: true },
      { id: "volumeGesture", name: "Vuốt dọc chỉnh âm lượng", desc: "Cử chỉ âm thanh tiện dụng", default: true }
    ]
  },
  {
    title: "5. HỆ THỐNG & TRẢI NGHIỆM ĐỈNH CAO",
    items: [
      { id: "hapticFeedback", name: "Rung phản hồi xúc giác (Haptic)", desc: "Cảm giác chạm phím sắc sảo", default: true },
      { id: "gpuMetalAccel", name: "Tăng tốc phần cứng Metal Engine", desc: "Cuộn 120Hz không giật lag", default: true },
      { id: "cacheFastThumb", name: "Bộ nhớ đệm ảnh thumbnail tức thì", desc: "Mở app hiển thị ngay lập tức", default: true },
      { id: "hideHomeBar", name: "Tự ẩn thanh Home Bar khi ngắm ảnh", desc: "Mở rộng không gian hiển thị", default: false },
      { id: "preventDimming", name: "Giữ màn hình luôn sáng rõ", desc: "Không tự khoá khi xem album", default: true },
      { id: "trashProtection", name: "Bảo vệ thùng rác an toàn", desc: "Chống bấm nhầm xoá vĩnh viễn", default: true },
      { id: "neonDockGlow", name: "Hiệu ứng viền phát sáng thanh Dock", desc: "Kính lỏng tương lai iOS 27", default: true },
      { id: "autoOrientation", name: "Tự xoay theo chiều ảnh gốc", desc: "Không cần tắt khoá xoay", default: false },
      { id: "lowDataMode", name: "Chế độ tải ảnh tiết kiệm", desc: "Tối ưu cho máy dung lượng thấp", default: false },
      { id: "aboutCredits", name: "Giới thiệu tác giả & Donate", desc: "Credit: Jinken Nguyen - 1989", default: true }
    ]
  }
];

let appState = {
  currentTab: 'library',
  currentFilter: 'all',
  layoutCol: 3,
  photos: [],
  currentPhotoIndex: -1,
  currentPhoto: null,
  currentRotation: 0,
  zoomScale: 1.0,
  zoomPanX: 0,
  zoomPanY: 0,
  settings: {}
};

// Initialize Settings
function initSettings() {
  const saved = localStorage.getItem('photos27_settings');
  if (saved) {
    try { appState.settings = JSON.parse(saved); } catch(e) {}
  }
  SETTINGS_SECTIONS.forEach(sec => {
    sec.items.forEach(item => {
      if (appState.settings[item.id] === undefined) {
        appState.settings[item.id] = item.default;
      }
    });
  });
}

function saveSetting(id, val) {
  appState.settings[id] = val;
  localStorage.setItem('photos27_settings', JSON.stringify(appState.settings));
  applySettingsEffects();
}

function applySettingsEffects() {
  const grid = document.getElementById('photo-grid');
  const searchGrid = document.getElementById('search-grid');
  
  const allGrids = [grid, searchGrid].filter(Boolean);
  
  allGrids.forEach(g => {
    // 1. Aspect Fit
    if (appState.settings.aspectFitGrid) {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.add('aspect-fit'));
    } else {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.remove('aspect-fit'));
    }
    
    // 2. 3D Card
    if (appState.settings.perspective3D) {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.add('card-3d'));
    } else {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.remove('card-3d'));
    }

    // 3. Glow Border
    if (appState.settings.gridGlowBorder) {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.add('glow-border'));
    } else {
      g.querySelectorAll('.photo-item').forEach(el => el.classList.remove('glow-border'));
    }

    // 4. Clean Grid (Hide badges)
    if (appState.settings.cleanGrid) {
      g.querySelectorAll('.item-badge, .fav-badge').forEach(el => el.style.display = 'none');
    } else {
      g.querySelectorAll('.item-badge, .fav-badge').forEach(el => el.style.display = '');
    }

    // 5. Enhanced Grid (Rounded corners)
    if (appState.settings.enhancedGrid === false) {
      g.querySelectorAll('.photo-item').forEach(el => el.style.borderRadius = '4px');
    } else {
      g.querySelectorAll('.photo-item').forEach(el => el.style.borderRadius = '');
    }
  });

  // 6. Dynamic Mesh / Ambient Aurora
  if (appState.settings.dynamicMesh) {
    document.body.style.backgroundImage = 'var(--bg-gradient)';
  } else {
    document.body.style.backgroundImage = 'none';
  }

  // 7. OLED Dark
  if (appState.settings.oledDark) {
    document.body.style.background = '#000000';
    document.body.style.backgroundImage = 'none';
  } else if (!appState.settings.dynamicMesh) {
    document.body.style.background = '#060a17';
  }

  // 8. Dock Glow
  const dock = document.querySelector('.floating-dock');
  if (dock) {
    if (appState.settings.neonDockGlow) {
      dock.style.boxShadow = '0 16px 42px rgba(0, 0, 0, 0.65), 0 0 25px rgba(0, 242, 254, 0.35)';
    } else {
      dock.style.boxShadow = '0 8px 20px rgba(0,0,0,0.4)';
    }
  }

  // 9. Video Auto-loop in Fullscreen
  const vid = document.getElementById('viewer-video');
  if (vid) {
    vid.loop = (appState.settings.autoLoop !== false);
    vid.muted = (appState.settings.autoUnmute ? false : (appState.settings.videoMuteDefault !== false));
  }

  // 10. Native Setting: preventDimming
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.applyNativeSetting) {
    window.webkit.messageHandlers.applyNativeSetting.postMessage({
      key: 'preventDimming',
      value: appState.settings.preventDimming !== false
    });
  }
}

function triggerHaptic(type = 'medium') {
  if (appState.settings.hapticFeedback !== false && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.haptic) {
    window.webkit.messageHandlers.haptic.postMessage({ type: type });
  }
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (t) {
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
  }
}
window.showToast = showToast;

function copySTK() {
  triggerHaptic('success');
  if (navigator.clipboard) {
    navigator.clipboard.writeText('0345140889');
  }
  showToast("Đã sao chép STK: 0345140889 (MB Bank)");
}

// Native Bridge Callbacks
window.receiveNativePhotos = function(photosJson) {
  try {
    const list = typeof photosJson === 'string' ? JSON.parse(photosJson) : photosJson;
    if (Array.isArray(list)) {
      appState.photos = list;
      
      // Update hero memory banner
      const heroPhoto = list.find(p => p.isFav) || list[0];
      if (heroPhoto) {
        const heroImg = document.getElementById('hero-img');
        if (heroImg) heroImg.src = heroPhoto.thumb;
      }
      
      renderGallery();
      renderAlbums();
      renderMemories();
    }
  } catch(e) {
    console.error("Error parsing photos:", e);
  }
};

window.receiveFullMedia = function(localId, mediaData, isVideo) {
  if (appState.currentPhoto && appState.currentPhoto.id === localId) {
    const imgEl = document.getElementById('viewer-img');
    const vidEl = document.getElementById('viewer-video');
    const playBtn = document.getElementById('btn-play-native');
    
    if (isVideo) {
      if (vidEl) {
        vidEl.src = mediaData;
        vidEl.style.display = 'block';
        if (appState.settings.autoUnmute) vidEl.muted = false;
        vidEl.play().catch(e => {
          console.log("Autoplay waiting for tap", e);
        });
      }
      if (imgEl) imgEl.style.display = 'none';
      if (playBtn) playBtn.style.display = 'flex';
    } else {
      if (playBtn) playBtn.style.display = 'none';
      if (vidEl) {
        vidEl.pause();
        vidEl.style.display = 'none';
      }
      if (imgEl) {
        // Swap to high resolution lossless image
        imgEl.src = mediaData;
        imgEl.style.display = 'block';
      }
    }
  }
};

function triggerNativePlayer() {
  triggerHaptic('heavy');
  if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.playVideoNative) {
    window.webkit.messageHandlers.playVideoNative.postMessage({ id: appState.currentPhoto.id });
  }
}

window.onFavoriteUpdated = function(localId, isFav) {
  const p = appState.photos.find(x => x.id === localId);
  if (p) p.isFav = isFav;
  if (appState.currentPhoto && appState.currentPhoto.id === localId) {
    appState.currentPhoto.isFav = isFav;
    updateViewerFavButton(isFav);
  }
  renderGallery();
  renderAlbums();
  showToast(isFav ? "Đã thêm vào Yêu thích ❤️" : "Đã bỏ Yêu thích 💔");
};

window.onPhotoDeleted = function(localId) {
  appState.photos = appState.photos.filter(x => x.id !== localId);
  closeViewer();
  renderGallery();
  renderAlbums();
  showToast("Đã xoá ảnh khỏi thư viện 🗑️");
};

// Fullscreen Photo Viewer Logic with Multi-touch Zoom and Next/Prev Swiping
function getFilteredPhotos() {
  let list = appState.photos;
  if (appState.currentFilter === 'videos') list = list.filter(p => p.isVideo);
  else if (appState.currentFilter === 'favs') list = list.filter(p => p.isFav);
  else if (appState.currentFilter === 'screenshots') list = list.filter(p => p.isScreenshot);
  else if (appState.currentFilter === 'portraits') list = list.filter(p => p.isPortrait);
  else if (appState.currentFilter === 'live') list = list.filter(p => p.isLive);
  return list;
}

function updateZoomTransform(animated = false) {
  const container = document.getElementById('zoom-container');
  const indicator = document.getElementById('zoom-indicator');
  if (!container) return;
  
  if (animated) {
    container.classList.add('animating');
  } else {
    container.classList.remove('animating');
  }
  
  container.style.transform = `translate(${appState.zoomPanX}px, ${appState.zoomPanY}px) scale(${appState.zoomScale})`;
  
  if (indicator) {
    if (appState.zoomScale > 1.05) {
      indicator.textContent = `${appState.zoomScale.toFixed(1)}x`;
      indicator.classList.add('visible');
    } else {
      indicator.classList.remove('visible');
    }
  }
}

function resetZoom(animated = true) {
  appState.zoomScale = 1.0;
  appState.zoomPanX = 0;
  appState.zoomPanY = 0;
  updateZoomTransform(animated);
}

function toggleZoomLevel() {
  triggerHaptic('medium');
  if (appState.zoomScale > 1.2) {
    resetZoom(true);
  } else {
    appState.zoomScale = 2.5;
    appState.zoomPanX = 0;
    appState.zoomPanY = 0;
    updateZoomTransform(true);
  }
}

function openFullscreenPhotoByIndex(idx, direction) {
  const list = getFilteredPhotos();
  if (idx < 0 || idx >= list.length) return;
  
  triggerHaptic('medium');
  appState.currentPhotoIndex = idx;
  const photo = list[idx];
  appState.currentPhoto = photo;
  appState.currentRotation = 0;
  resetZoom(false);
  
  const modal = document.getElementById('modal-viewer');
  const imgEl = document.getElementById('viewer-img');
  const vidEl = document.getElementById('viewer-video');
  const playNativeBtn = document.getElementById('btn-play-native');
  const titleEl = document.getElementById('viewer-title');
  const subEl = document.getElementById('viewer-sub');
  
  if (titleEl) {
    titleEl.textContent = photo.isVideo ? 'Video' : (photo.isScreenshot ? 'Ảnh chụp màn hình' : (photo.isPortrait ? 'Chân dung' : 'Ảnh'));
  }
  if (subEl) {
    const dim = (photo.width && photo.height) ? `${photo.width} × ${photo.height}` : '';
    subEl.textContent = `${idx + 1}/${list.length} • ${photo.date || ''} ${dim ? '• ' + dim : ''}`;
  }
  
  updateViewerFavButton(photo.isFav);
  
  // Apply directional slide animation class
  imgEl.className = '';
  if (direction === 'next') {
    imgEl.classList.add('enter-from-right');
  } else if (direction === 'prev') {
    imgEl.classList.add('enter-from-left');
  }
  
  if (photo.isVideo) {
    if (playNativeBtn) playNativeBtn.style.display = 'flex';
    if (imgEl) {
      imgEl.src = photo.thumb;
      imgEl.style.display = 'block';
    }
    if (vidEl) {
      vidEl.style.display = 'none';
      vidEl.pause();
    }
  } else {
    if (playNativeBtn) playNativeBtn.style.display = 'none';
    if (vidEl) {
      vidEl.pause();
      vidEl.style.display = 'none';
    }
    if (imgEl) {
      imgEl.src = photo.thumb;
      imgEl.style.display = 'block';
    }
  }
  
  modal.classList.add('active');
  
  // Request full lossless resolution image or video asset from native
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.getFullPhoto) {
    window.webkit.messageHandlers.getFullPhoto.postMessage({ id: photo.id });
  }
}

function showNextPhoto() {
  const list = getFilteredPhotos();
  if (appState.currentPhotoIndex < list.length - 1) {
    resetZoom(false);
    const imgEl = document.getElementById('viewer-img');
    imgEl.classList.remove('enter-from-right', 'enter-from-left');
    imgEl.classList.add('swipe-left-anim');
    setTimeout(() => {
      openFullscreenPhotoByIndex(appState.currentPhotoIndex + 1, 'next');
    }, 140);
  } else {
    showToast("Đã là mục cuối cùng");
  }
}

function showPrevPhoto() {
  if (appState.currentPhotoIndex > 0) {
    resetZoom(false);
    const imgEl = document.getElementById('viewer-img');
    imgEl.classList.remove('enter-from-right', 'enter-from-left');
    imgEl.classList.add('swipe-right-anim');
    setTimeout(() => {
      openFullscreenPhotoByIndex(appState.currentPhotoIndex - 1, 'prev');
    }, 140);
  } else {
    showToast("Đã là mục đầu tiên");
  }
}

function closeViewer() {
  triggerHaptic('medium');
  const modal = document.getElementById('modal-viewer');
  const vidEl = document.getElementById('viewer-video');
  const playNativeBtn = document.getElementById('btn-play-native');
  if (vidEl) {
    vidEl.pause();
    vidEl.src = '';
  }
  if (playNativeBtn) playNativeBtn.style.display = 'none';
  if (modal) modal.classList.remove('active');
  resetZoom(false);
  appState.currentPhoto = null;
  appState.currentPhotoIndex = -1;
}

function updateViewerFavButton(isFav) {
  const btn = document.getElementById('btn-viewer-fav');
  if (btn) {
    btn.textContent = isFav ? '❤️' : '🤍';
  }
}

// Render Gallery (Library Tab)
function renderGallery() {
  const grid = document.getElementById('photo-grid');
  const countLbl = document.getElementById('section-count');
  if (!grid) return;
  grid.innerHTML = '';
  
  const filtered = getFilteredPhotos();
  
  if (countLbl) {
    countLbl.textContent = `${filtered.length} mục`;
  }
  
  filtered.forEach((p, idx) => {
    const item = document.createElement('div');
    let classes = 'photo-item';
    if (appState.settings.aspectFitGrid) classes += ' aspect-fit';
    if (appState.settings.perspective3D) classes += ' card-3d';
    if (appState.settings.gridGlowBorder) classes += ' glow-border';
    item.className = classes;
    
    let html = `<img src="${p.thumb || p.url}" alt="" loading="lazy">`;
    if (p.isVideo && !appState.settings.cleanGrid) {
      html += `<div class="item-badge">▶ ${p.duration || '0:15'}</div>`;
    }
    if (p.isFav && !appState.settings.cleanGrid) {
      html += `<div class="fav-badge">❤️</div>`;
    }
    item.innerHTML = html;
    
    // Tapping opens fullscreen with interactive swipe and zoom
    item.onclick = () => openFullscreenPhotoByIndex(idx);
    grid.appendChild(item);
  });
}

// Render Albums Tab
function renderAlbums() {
  const container = document.getElementById('albums-grid');
  if (!container) return;
  container.innerHTML = '';
  
  const albums = [
    { id: 'all', name: 'Gần đây', icon: '🖼️', count: appState.photos.length, thumb: appState.photos[0]?.thumb },
    { id: 'favs', name: 'Yêu thích', icon: '❤️', count: appState.photos.filter(p => p.isFav).length, thumb: appState.photos.find(p => p.isFav)?.thumb },
    { id: 'videos', name: 'Video', icon: '🎬', count: appState.photos.filter(p => p.isVideo).length, thumb: appState.photos.find(p => p.isVideo)?.thumb },
    { id: 'screenshots', name: 'Ảnh chụp MH', icon: '📱', count: appState.photos.filter(p => p.isScreenshot).length, thumb: appState.photos.find(p => p.isScreenshot)?.thumb },
    { id: 'portraits', name: 'Chân dung', icon: '✨', count: appState.photos.filter(p => p.isPortrait).length, thumb: appState.photos.find(p => p.isPortrait)?.thumb },
    { id: 'live', name: 'Live Photos', icon: '💫', count: appState.photos.filter(p => p.isLive).length, thumb: appState.photos.find(p => p.isLive)?.thumb }
  ];
  
  albums.forEach(alb => {
    const card = document.createElement('div');
    card.className = 'album-card';
    card.innerHTML = `
      <div class="album-thumb">
        ${alb.thumb ? `<img src="${alb.thumb}" alt="">` : alb.icon}
      </div>
      <div class="album-info">
        <div class="album-name">${alb.name}</div>
        <div class="album-count">${alb.count} mục</div>
      </div>
    `;
    card.onclick = () => {
      triggerHaptic('medium');
      switchTab('library');
      document.querySelectorAll('.cat-chip').forEach(c => {
        c.classList.toggle('active', c.getAttribute('data-filter') === alb.id);
      });
      appState.currentFilter = alb.id;
      renderGallery();
    };
    container.appendChild(card);
  });
}

// Render Memories Tab
function renderMemories() {
  const container = document.getElementById('memories-list');
  if (!container) return;
  container.innerHTML = '';
  
  const favs = appState.photos.filter(p => p.isFav);
  const sampleMemories = [
    { title: "Những ngày tuyệt vời", sub: "Khoảnh khắc được bạn gắn sao yêu thích", list: favs.length > 0 ? favs : appState.photos.slice(0, 4) },
    { title: "Chuyến phiêu lưu số", sub: "Tuyển chọn bởi thuật toán iOS 27 Liquid", list: appState.photos.slice(0, 6) }
  ];
  
  sampleMemories.forEach(mem => {
    const card = document.createElement('div');
    card.className = 'memory-card';
    const bgThumb = mem.list[0]?.thumb || '';
    card.innerHTML = `
      <img class="memory-bg" src="${bgThumb}" alt="" onerror="this.style.display='none'">
      <div class="memory-overlay">
        <span class="memory-tag">Bộ sưu tập Kỷ niệm</span>
        <div class="memory-title">${mem.title}</div>
        <div class="memory-subtitle">${mem.sub} • ${mem.list.length} bức ảnh</div>
      </div>
    `;
    card.onclick = () => {
      if (mem.list.length > 0) {
        openFullscreenPhotoByIndex(0);
      }
    };
    container.appendChild(card);
  });
}

// Tab Switching
function switchTab(tabName) {
  triggerHaptic('medium');
  appState.currentTab = tabName;
  
  // Update dock buttons
  document.querySelectorAll('.dock-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
  });
  
  // Show active tab pane
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.remove('active');
  });
  const activePane = document.getElementById(`tab-${tabName}`);
  if (activePane) activePane.classList.add('active');
  
  // Show / hide category bar based on tab
  const catBar = document.getElementById('category-bar');
  if (catBar) {
    catBar.style.display = (tabName === 'library') ? 'flex' : 'none';
  }
  
  // Update header title
  const titleEl = document.getElementById('app-title');
  if (titleEl) {
    if (tabName === 'library') titleEl.textContent = 'Photos 27';
    else if (tabName === 'memories') titleEl.textContent = 'Kỷ Niệm';
    else if (tabName === 'albums') titleEl.textContent = 'Album';
    else if (tabName === 'search') titleEl.textContent = 'Tìm Kiếm';
  }
}

// Search Logic
function handleSearch(query) {
  const searchGrid = document.getElementById('search-grid');
  const countLbl = document.getElementById('search-count');
  if (!searchGrid) return;
  searchGrid.innerHTML = '';
  
  const q = query.trim().toLowerCase();
  if (!q) {
    if (countLbl) countLbl.textContent = '0 kết quả';
    return;
  }
  
  const results = appState.photos.filter(p => {
    if (q === 'video' || q === 'clip') return p.isVideo;
    if (q === 'fav' || q === 'yeu thich' || q === 'yêu thích') return p.isFav;
    if (q === 'chup man hinh' || q === 'screenshot') return p.isScreenshot;
    if (q === 'chan dung' || q === 'portrait') return p.isPortrait;
    return p.date && p.date.toLowerCase().includes(q);
  });
  
  if (countLbl) countLbl.textContent = `${results.length} kết quả`;
  
  results.forEach(p => {
    const item = document.createElement('div');
    item.className = 'photo-item' + (appState.settings.aspectFitGrid ? ' aspect-fit' : '') + (appState.settings.perspective3D ? ' card-3d' : '');
    item.innerHTML = `<img src="${p.thumb || p.url}" alt="">`;
    item.onclick = () => {
      const idx = appState.photos.indexOf(p);
      if (idx !== -1) openFullscreenPhotoByIndex(idx);
    };
    searchGrid.appendChild(item);
  });
}

// Render Settings Sheet (50 Toggles)
function renderSettings() {
  const container = document.getElementById('settings-list');
  if (!container) return;
  container.innerHTML = '';
  
  SETTINGS_SECTIONS.forEach(sec => {
    const title = document.createElement('div');
    title.className = 'setting-group-title';
    title.textContent = sec.title;
    container.appendChild(title);
    
    const card = document.createElement('div');
    card.className = 'setting-card';
    
    sec.items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'setting-row';
      const isChecked = appState.settings[item.id] !== false;
      
      row.innerHTML = `
        <div class="setting-info">
          <div class="setting-name">${item.name}</div>
          <div class="setting-desc">${item.desc}</div>
        </div>
        <label class="switch">
          <input type="checkbox" id="set_${item.id}" ${isChecked ? 'checked' : ''}>
          <span class="slider"></span>
        </label>
      `;
      
      const chk = row.querySelector('input');
      chk.onchange = (e) => {
        triggerHaptic('medium');
        saveSetting(item.id, e.target.checked);
      };
      card.appendChild(row);
    });
    
    container.appendChild(card);
  });
  
  // Donate Box
  const donate = document.createElement('div');
  donate.className = 'donate-box';
  donate.innerHTML = `
    <div style="font-weight:700; font-size:15px; margin-bottom:4px;">☕ Donate Tác Giả</div>
    <div style="font-size:12px; color:var(--text-sub); line-height:1.5;">
      Credit: Jinken Nguyen - 1989<br>
      MB Bank · 0345140889 · Nguyễn Tiến Triều
    </div>
    <button class="donate-btn" onclick="copySTK()">📋 Sao chép STK MB Bank</button>
  `;
  container.appendChild(donate);
}

// DOM Ready & Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  initSettings();
  renderSettings();
  applySettingsEffects();
  
  // Dock Bottom Tabs
  document.querySelectorAll('.dock-btn').forEach(btn => {
    btn.onclick = () => {
      const tab = btn.getAttribute('data-tab');
      if (tab) switchTab(tab);
    };
  });
  
  // Category Chips
  document.querySelectorAll('.cat-chip').forEach(chip => {
    chip.onclick = () => {
      triggerHaptic('medium');
      document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      appState.currentFilter = chip.getAttribute('data-filter');
      renderGallery();
    };
  });
  
  // Search Input Listener
  const searchInp = document.getElementById('search-input');
  if (searchInp) {
    searchInp.addEventListener('input', (e) => {
      handleSearch(e.target.value);
    });
  }
  
  // Grid Column Toggle
  const colBtn = document.getElementById('btn-grid-col');
  if (colBtn) {
    colBtn.onclick = () => {
      triggerHaptic('medium');
      const grid = document.getElementById('photo-grid');
      if (appState.layoutCol === 3) {
        appState.layoutCol = 2;
        grid.className = 'photo-grid col-2';
        colBtn.textContent = '📰';
      } else if (appState.layoutCol === 2) {
        appState.layoutCol = 4;
        grid.className = 'photo-grid col-4';
        colBtn.textContent = '📱';
      } else {
        appState.layoutCol = 3;
        grid.className = 'photo-grid';
        colBtn.textContent = '📐';
      }
    };
  }
  
  // Aspect Fit Toggle
  const aspectBtn = document.getElementById('btn-aspect-fit');
  if (aspectBtn) {
    aspectBtn.onclick = () => {
      triggerHaptic('medium');
      appState.settings.aspectFitGrid = !appState.settings.aspectFitGrid;
      saveSetting('aspectFitGrid', appState.settings.aspectFitGrid);
    };
  }
  
  // Settings Sheet Toggle
  const openSet = document.getElementById('btn-open-settings');
  const closeSet = document.getElementById('btn-close-settings');
  const sheet = document.getElementById('settings-sheet');
  if (openSet && sheet) {
    openSet.onclick = () => {
      triggerHaptic('medium');
      sheet.classList.add('active');
    };
  }
  if (closeSet && sheet) {
    closeSet.onclick = () => {
      triggerHaptic('medium');
      sheet.classList.remove('active');
    };
  }

  // Fullscreen Viewer Controls
  const closeViewerBtn = document.getElementById('btn-viewer-close');
  if (closeViewerBtn) closeViewerBtn.onclick = closeViewer;

  const prevBtn = document.getElementById('btn-viewer-prev');
  if (prevBtn) prevBtn.onclick = showPrevPhoto;

  const nextBtn = document.getElementById('btn-viewer-next');
  if (nextBtn) nextBtn.onclick = showNextPhoto;

  const zoomBtn = document.getElementById('btn-viewer-zoom');
  if (zoomBtn) zoomBtn.onclick = toggleZoomLevel;

  const playNativeBtn = document.getElementById('btn-play-native');
  if (playNativeBtn) playNativeBtn.onclick = triggerNativePlayer;

  const shareBtn = document.getElementById('btn-viewer-share');
  if (shareBtn) {
    shareBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sharePhoto) {
        triggerHaptic('medium');
        window.webkit.messageHandlers.sharePhoto.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const moreViewerBtn = document.getElementById('btn-viewer-more');
  if (moreViewerBtn) {
    moreViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.openActionMenu) {
        triggerHaptic('medium');
        window.webkit.messageHandlers.openActionMenu.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const favViewerBtn = document.getElementById('btn-viewer-fav');
  if (favViewerBtn) {
    favViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.toggleFavorite) {
        triggerHaptic('medium');
        window.webkit.messageHandlers.toggleFavorite.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const copyViewerBtn = document.getElementById('btn-viewer-copy');
  if (copyViewerBtn) {
    copyViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.copyPhoto) {
        triggerHaptic('medium');
        window.webkit.messageHandlers.copyPhoto.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const rotateViewerBtn = document.getElementById('btn-viewer-rotate');
  if (rotateViewerBtn) {
    rotateViewerBtn.onclick = () => {
      triggerHaptic('medium');
      appState.currentRotation = (appState.currentRotation + 90) % 360;
      const img = document.getElementById('viewer-img');
      if (img) img.style.transform = `rotate(${appState.currentRotation}deg)`;
    };
  }

  const deleteViewerBtn = document.getElementById('btn-viewer-delete');
  if (deleteViewerBtn) {
    deleteViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.deletePhoto) {
        triggerHaptic('heavy');
        window.webkit.messageHandlers.deletePhoto.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  // Multi-Touch Pinch Zoom, Double Tap, and Inertial Swiping
  const viewerBody = document.getElementById('viewer-body');
  let initialPinchDist = 0;
  let startScale = 1.0;
  let touchStartX = 0;
  let touchStartY = 0;
  let panStartX = 0;
  let panStartY = 0;
  let isDragging = false;
  let lastTapTime = 0;

  function getDistance(t1, t2) {
    const dx = t1.clientX - t2.clientX;
    const dy = t1.clientY - t2.clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  if (viewerBody) {
    viewerBody.addEventListener('touchstart', (e) => {
      if (e.touches.length === 2) {
        // Pinch zoom start
        initialPinchDist = getDistance(e.touches[0], e.touches[1]);
        startScale = appState.zoomScale;
      } else if (e.touches.length === 1) {
        const now = Date.now();
        if (now - lastTapTime < 300) {
          // Double Tap to toggle Zoom
          toggleZoomLevel();
          lastTapTime = 0;
          return;
        }
        lastTapTime = now;
        
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        panStartX = appState.zoomPanX;
        panStartY = appState.zoomPanY;
        isDragging = true;
      }
    }, { passive: true });

    viewerBody.addEventListener('touchmove', (e) => {
      if (e.touches.length === 2) {
        // Pinch Zoom in action
        const currentDist = getDistance(e.touches[0], e.touches[1]);
        if (initialPinchDist > 0) {
          const factor = currentDist / initialPinchDist;
          appState.zoomScale = Math.min(Math.max(startScale * factor, 0.8), 8.0);
          updateZoomTransform(false);
        }
      } else if (e.touches.length === 1 && isDragging) {
        const deltaX = e.touches[0].clientX - touchStartX;
        const deltaY = e.touches[0].clientY - touchStartY;
        
        if (appState.zoomScale > 1.05) {
          // Pan inside zoomed image
          appState.zoomPanX = panStartX + deltaX;
          appState.zoomPanY = panStartY + deltaY;
          updateZoomTransform(false);
        } else {
          // Normal swiping & dismiss physics
          const container = document.getElementById('zoom-container');
          if (Math.abs(deltaX) > Math.abs(deltaY) && container) {
            container.style.transform = `translateX(${deltaX * 0.7}px)`;
          } else if (deltaY > 0 && container) {
            container.style.transform = `translateY(${deltaY * 0.6}px) scale(${Math.max(0.7, 1 - deltaY / 600)})`;
          }
        }
      }
    }, { passive: true });

    viewerBody.addEventListener('touchend', (e) => {
      if (e.touches.length === 0) {
        isDragging = false;
        
        if (appState.zoomScale < 1.0) {
          resetZoom(true);
          return;
        }
        
        if (appState.zoomScale <= 1.05) {
          const deltaX = e.changedTouches[0].clientX - touchStartX;
          const deltaY = e.changedTouches[0].clientY - touchStartY;
          
          // Dismiss
          if (deltaY > 90 && Math.abs(deltaY) > Math.abs(deltaX) * 1.3) {
            closeViewer();
          } 
          // Previous / Next photo
          else if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY)) {
            if (deltaX < 0) {
              showNextPhoto();
            } else {
              showPrevPhoto();
            }
          } else {
            resetZoom(true);
          }
        }
      }
    }, { passive: true });
  }
  
  // Request Native Photos
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.loadLibrary) {
    window.webkit.messageHandlers.loadLibrary.postMessage({});
  }
});
