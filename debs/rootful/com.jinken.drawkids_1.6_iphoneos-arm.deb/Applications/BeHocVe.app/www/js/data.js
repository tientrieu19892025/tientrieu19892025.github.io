// ============================================================
// DỮ LIỆU - Bé học Vẽ (thuần Việt)
// Thứ tự script: js/data.js -> js/app.js
// QUY TẮC: chỉ dùng cú pháp ES5 (var, function, nối chuỗi bằng +).
// ============================================================
"use strict";

// ---------------- Map audio theo contract (164 + 8 clip donate + 17 clip ph_) ----------------
var UI_AUDIO_KEYS = [
  "nav_home", "nav_free", "nav_steps", "nav_coloring", "nav_trace", "nav_colors",
  "nav_shapes", "nav_games", "nav_daily", "nav_progress", "nav_gallery", "nav_settings",
  "ui_choice", "ui_truefalse", "ui_memory", "ui_count", "ui_mix", "ui_oddone",
  "ui_saved", "ui_deleted", "ui_confirm_del", "ui_theme", "ui_fontsize", "ui_layout",
  "guide_free", "guide_steps", "guide_coloring", "guide_trace", "guide_colors",
  "guide_shapes", "guide_choice", "guide_truefalse", "guide_memory", "guide_count",
  "guide_mix", "guide_oddone",
  "praise1", "praise2", "praise3", "praise4", "praise5", "praise6",
  "vitry1", "vitry2", "great", "tryagain",
  "welcome", "hello", "ui_name_ask", "ui_avatar_ask",
  "col_do", "col_cam", "col_vang", "col_xanhla", "col_xanhduong", "col_tim",
  "col_hong", "col_nau", "col_den", "col_trang", "col_xam", "col_xanhngoc",
  "shp_tron", "shp_vuong", "shp_tamgiac", "shp_chunhat", "shp_binhhanh",
  "shp_sao", "shp_traitim", "shp_thoi",
  "step_meo", "step_ca", "step_hoa", "step_oto", "step_mattroi", "step_chim",
  "step_nha", "step_buom", "step_tao", "step_tho",
  "buoc_1", "buoc_2", "buoc_3", "buoc_4", "buoc_5", "buoc_6",
  "step_done", "lesson_done",
  "dr_brush", "dr_eraser", "dr_undo", "dr_clear", "dr_save", "dr_palette",
  "dr_saved_ok", "dr_cleared_ok",
  "cnt_1", "cnt_2", "cnt_3", "cnt_4", "cnt_5", "cnt_6", "cnt_7", "cnt_8", "cnt_9", "cnt_10",
  "mix_dovang", "mix_xanhvang", "mix_doxanh", "mix_dentrang",
  "tf_1", "tf_2", "tf_3", "tf_4", "tf_5", "tf_6",
  "tf_7", "tf_8", "tf_9", "tf_10", "tf_11", "tf_12",
  "daily_done", "gal_empty", "ui_back", "name_saved",
  "dn_nav", "dn_thanks1", "dn_thanks2", "dn_thanks3", "dn_bank", "dn_note",
  "dn_copied", "dn_copyfail",
  "ph_intro", "ph_guide", "ph_readerr", "ph_toolarge", "ph_saved",
  "ph_deleted", "ph_confirm_del", "ph_full", "ph_nophoto", "ph_color_guide",
  "ph_eraser_guide", "ph_color_done", "ph_draw_guide", "ph_draw_done",
  "ph_learn_guide", "ph_storage_full", "ph_open"
];
var UI_AUDIO = {};
(function () {
  for (var i = 0; i < UI_AUDIO_KEYS.length; i++) {
    UI_AUDIO[UI_AUDIO_KEYS[i]] = "audio/" + UI_AUDIO_KEYS[i] + ".mp3";
  }
})();

// ---------------- 12 màu sắc ----------------
var COLORS = [
  { id: "do",       name: "Đỏ",        hex: "#E53935", audio: "col_do" },
  { id: "cam",      name: "Cam",       hex: "#FB8C00", audio: "col_cam" },
  { id: "vang",     name: "Vàng",      hex: "#FDD835", audio: "col_vang" },
  { id: "xanhla",   name: "Xanh lá",   hex: "#43A047", audio: "col_xanhla" },
  { id: "xanhduong",name: "Xanh dương",hex: "#1E88E5", audio: "col_xanhduong" },
  { id: "tim",      name: "Tím",       hex: "#8E24AA", audio: "col_tim" },
  { id: "hong",     name: "Hồng",      hex: "#EC407A", audio: "col_hong" },
  { id: "nau",      name: "Nâu",       hex: "#8D6E63", audio: "col_nau" },
  { id: "den",      name: "Đen",       hex: "#212121", audio: "col_den" },
  { id: "trang",    name: "Trắng",     hex: "#FFFFFF", audio: "col_trang" },
  { id: "xam",      name: "Xám",       hex: "#9E9E9E", audio: "col_xam" },
  { id: "xanhngoc", name: "Xanh ngọc", hex: "#00ACC1", audio: "col_xanhngoc" }
];
function colorById(id) {
  for (var i = 0; i < COLORS.length; i++) if (COLORS[i].id === id) return COLORS[i];
  return COLORS[0];
}

// ---------------- 8 hình khối (svg trên viewBox 0 0 100 100) ----------------
var SHAPES = [
  { id: "tron",    name: "Hình tròn",     ex: "Bánh xe, quả bóng, mặt trời", audio: "shp_tron",
    svg: '<circle cx="50" cy="50" r="38"/>' },
  { id: "vuong",   name: "Hình vuông",    ex: "Khăn ăn, bàn cờ, khung ảnh", audio: "shp_vuong",
    svg: '<rect x="14" y="14" width="72" height="72" rx="8"/>' },
  { id: "tamgiac", name: "Hình tam giác", ex: "Mũ sinh nhật, mái nhà, cánh buồm", audio: "shp_tamgiac",
    svg: '<path d="M50,14 L88,82 L12,82 Z"/>' },
  { id: "chunhat", name: "Hình chữ nhật", ex: "Cửa sổ, quyển sách, điện thoại", audio: "shp_chunhat",
    svg: '<rect x="10" y="26" width="80" height="48" rx="8"/>' },
  { id: "bauduc",  name: "Hình bình hành", ex: "Cái hộp nằm nghiêng, mảnh đất xéo", audio: "shp_binhhanh",
    svg: '<path d="M32,14 L90,14 L68,86 L10,86 Z"/>' },
  { id: "sao",     name: "Hình ngôi sao", ex: "Ngôi sao trên trời, sao trang trí", audio: "shp_sao",
    svg: '<path d="M50,8 L61,38 L93,38 L67,57 L76,88 L50,69 L24,88 L33,57 L7,38 L39,38 Z"/>' },
  { id: "traitim", name: "Hình trái tim", ex: "Trái tim yêu thương của bé", audio: "shp_traitim",
    svg: '<path d="M50,84 C20,62 12,36 28,25 C40,17 50,25 50,33 C50,25 60,17 72,25 C88,36 80,62 50,84 Z"/>' },
  { id: "thoi",    name: "Hình thoi",     ex: "Viên kim cương, cánh diều", audio: "shp_thoi",
    svg: '<path d="M50,8 L86,50 L50,92 L14,50 Z"/>' }
];
function shapeById(id) {
  for (var i = 0; i < SHAPES.length; i++) if (SHAPES[i].id === id) return SHAPES[i];
  return SHAPES[0];
}

// ---------------- 10 bài học vẽ từng bước (viewBox 0 0 300 300) ----------------
var STEP_LESSONS = [
  { id: "meo", name: "Chú mèo", emoji: "🐱", audio: "step_meo", steps: [
    { t: "Bước 1: Vẽ cái đầu tròn xoe", svg: '<circle cx="150" cy="125" r="55"/>' },
    { t: "Bước 2: Vẽ hai cái tai nhọn", svg: '<path d="M108,85 L92,38 L140,62 Z M192,85 L208,38 L160,62 Z"/>' },
    { t: "Bước 3: Vẽ mắt và mũi xinh", svg: '<circle cx="132" cy="118" r="8"/><circle cx="168" cy="118" r="8"/><path d="M142,142 L158,142 L150,152 Z"/>' },
    { t: "Bước 4: Vẽ miệng và râu mèo", svg: '<path d="M150,152 Q150,162 140,164 M150,152 Q150,162 160,164 M100,138 L68,132 M100,148 L68,150 M200,138 L232,132 M200,148 L232,150"/>' },
    { t: "Bước 5: Vẽ thân và đuôi dài", svg: '<ellipse cx="150" cy="235" rx="45" ry="52"/><path d="M192,232 Q245,238 238,175"/>' }
  ]},
  { id: "ca", name: "Con cá", emoji: "🐟", audio: "step_ca", steps: [
    { t: "Bước 1: Vẽ mình cá bầu bĩnh", svg: '<ellipse cx="140" cy="150" rx="70" ry="48"/>' },
    { t: "Bước 2: Vẽ đuôi cá xòe ra", svg: '<path d="M210,150 L262,112 L262,188 Z"/>' },
    { t: "Bước 3: Vẽ mắt và miệng cười", svg: '<circle cx="117" cy="140" r="10"/><path d="M88,168 Q100,174 112,168"/>' },
    { t: "Bước 4: Vẽ vây trên và vây bên", svg: '<path d="M140,102 Q160,78 188,92 Q170,104 140,102 Z M158,162 Q178,178 172,198 Q158,186 158,162 Z"/>' },
    { t: "Bước 5: Vẽ vảy cá và bong bóng", svg: '<path d="M128,132 q14,14 0,28 M152,132 q14,14 0,28 M176,132 q14,14 0,28"/><circle cx="70" cy="84" r="8"/><circle cx="47" cy="58" r="5"/>' }
  ]},
  { id: "hoa", name: "Bông hoa", emoji: "🌸", audio: "step_hoa", steps: [
    { t: "Bước 1: Vẽ thân hoa thẳng đứng", svg: '<path d="M150,285 L150,165"/>' },
    { t: "Bước 2: Vẽ hai chiếc lá xanh", svg: '<path d="M150,235 Q118,228 102,200 Q134,198 150,235 Z M150,235 Q182,228 198,200 Q166,198 150,235 Z"/>' },
    { t: "Bước 3: Vẽ năm cánh hoa tròn", svg: '<circle cx="150" cy="62" r="28"/><circle cx="190" cy="95" r="28"/><circle cx="175" cy="140" r="28"/><circle cx="125" cy="140" r="28"/><circle cx="110" cy="95" r="28"/>' },
    { t: "Bước 4: Vẽ nhụy hoa ở giữa", svg: '<circle cx="150" cy="105" r="20"/><circle cx="150" cy="105" r="3"/>' }
  ]},
  { id: "oto", name: "Ô tô", emoji: "🚗", audio: "step_oto", steps: [
    { t: "Bước 1: Vẽ thân xe dài", svg: '<rect x="55" y="155" width="180" height="55" rx="12"/>' },
    { t: "Bước 2: Vẽ nóc xe phía trên", svg: '<path d="M105,155 v-32 a12,12 0 0,1 12,-12 h56 a12,12 0 0,1 12,12 v32 Z"/>' },
    { t: "Bước 3: Vẽ hai bánh xe tròn", svg: '<circle cx="100" cy="212" r="22"/><circle cx="200" cy="212" r="22"/>' },
    { t: "Bước 4: Vẽ cửa kính và đèn xe", svg: '<rect x="118" y="122" width="54" height="30" rx="4"/><circle cx="240" cy="182" r="8"/>' }
  ]},
  { id: "mattroi", name: "Ông mặt trời", emoji: "☀️", audio: "step_mattroi", steps: [
    { t: "Bước 1: Vẽ vòng tròn thật to", svg: '<circle cx="150" cy="150" r="60"/>' },
    { t: "Bước 2: Vẽ các tia nắng xung quanh", svg: '<path d="M150,68 L150,42 M150,258 L150,232 M68,150 L42,150 M258,150 L232,150 M92,92 L74,74 M226,226 L208,208 M208,92 L226,74 M74,226 L92,208"/>' },
    { t: "Bước 3: Vẽ mặt cười thật tươi", svg: '<circle cx="130" cy="140" r="8"/><circle cx="170" cy="140" r="8"/><path d="M128,172 Q150,188 172,172"/>' }
  ]},
  { id: "chim", name: "Chú chim", emoji: "🐦", audio: "step_chim", steps: [
    { t: "Bước 1: Vẽ mình chim tròn trịa", svg: '<ellipse cx="145" cy="175" rx="55" ry="40"/>' },
    { t: "Bước 2: Vẽ đầu và mỏ nhọn", svg: '<circle cx="205" cy="120" r="30"/><path d="M232,114 L250,122 L232,132 Z"/>' },
    { t: "Bước 3: Vẽ cánh và mắt đen", svg: '<path d="M125,165 Q160,142 190,162 Q160,180 125,165 Z"/><circle cx="210" cy="112" r="5"/>' },
    { t: "Bước 4: Vẽ đuôi và chân nhỏ", svg: '<path d="M95,165 L62,148 L66,182 Z M135,214 L135,240 M160,214 L160,240"/>' }
  ]},
  { id: "nha", name: "Ngôi nhà", emoji: "🏠", audio: "step_nha", steps: [
    { t: "Bước 1: Vẽ tường nhà vuông vắn", svg: '<rect x="90" y="160" width="120" height="95"/>' },
    { t: "Bước 2: Vẽ mái nhà hình tam giác", svg: '<path d="M70,165 L150,92 L230,165 Z"/>' },
    { t: "Bước 3: Vẽ cửa ra vào và cửa sổ", svg: '<rect x="135" y="198" width="30" height="57"/><rect x="102" y="180" width="32" height="32"/>' },
    { t: "Bước 4: Vẽ ống khói và ông mặt trời", svg: '<rect x="186" y="108" width="22" height="38"/><circle cx="252" cy="62" r="20"/>' }
  ]},
  { id: "buom", name: "Con bướm", emoji: "🦋", audio: "step_buom", steps: [
    { t: "Bước 1: Vẽ thân và đầu bướm", svg: '<ellipse cx="150" cy="155" rx="13" ry="45"/><circle cx="150" cy="102" r="13"/>' },
    { t: "Bước 2: Vẽ đôi cánh xòe rộng", svg: '<path d="M138,130 Q88,88 66,130 Q88,182 138,166 Z M162,130 Q212,88 234,130 Q212,182 162,166 Z"/>' },
    { t: "Bước 3: Vẽ hai chiếc râu cong", svg: '<path d="M144,90 Q134,70 122,64 M156,90 Q166,70 178,64"/>' },
    { t: "Bước 4: Vẽ chấm tròn trên cánh", svg: '<circle cx="104" cy="136" r="9"/><circle cx="196" cy="136" r="9"/>' }
  ]},
  { id: "tao", name: "Quả táo", emoji: "🍎", audio: "step_tao", steps: [
    { t: "Bước 1: Vẽ quả táo tròn căng", svg: '<path d="M150,115 C110,115 95,152 100,192 C105,232 130,252 150,252 C170,252 195,232 200,192 C205,152 190,115 150,115 Z"/>' },
    { t: "Bước 2: Vẽ cuống táo nhỏ", svg: '<path d="M150,115 Q150,96 156,86"/>' },
    { t: "Bước 3: Vẽ chiếc lá xanh", svg: '<path d="M160,92 Q184,80 200,92 Q184,108 160,92 Z"/>' },
    { t: "Bước 4: Vẽ vệt sáng bóng", svg: '<path d="M120,165 Q126,192 142,205"/>' }
  ]},
  { id: "tho", name: "Chú thỏ", emoji: "🐰", audio: "step_tho", steps: [
    { t: "Bước 1: Vẽ cái đầu tròn", svg: '<circle cx="150" cy="165" r="50"/>' },
    { t: "Bước 2: Vẽ đôi tai dài", svg: '<ellipse cx="124" cy="78" rx="16" ry="44"/><ellipse cx="176" cy="78" rx="16" ry="44"/>' },
    { t: "Bước 3: Vẽ mắt và mũi hồng", svg: '<circle cx="134" cy="160" r="7"/><circle cx="166" cy="160" r="7"/><path d="M143,180 L157,180 L150,188 Z"/>' },
    { t: "Bước 4: Vẽ miệng và thân tròn", svg: '<path d="M150,188 L150,198"/><ellipse cx="150" cy="252" rx="52" ry="32"/>' }
  ]}
];
function lessonById(id) {
  for (var i = 0; i < STEP_LESSONS.length; i++) if (STEP_LESSONS[i].id === id) return STEP_LESSONS[i];
  return null;
}

// ---------------- 10 tranh tô màu (line-art, data-r = vùng tô) ----------------
var COLORING_PAGES = [
  { id: "buom", name: "Con bướm", emoji: "🦋", svg:
    '<ellipse cx="150" cy="155" rx="13" ry="45" data-r="than"/>' +
    '<circle cx="150" cy="102" r="13" data-r="dau"/>' +
    '<path d="M138,130 Q88,88 66,130 Q88,182 138,166 Z" data-r="canh"/>' +
    '<path d="M162,130 Q212,88 234,130 Q212,182 162,166 Z" data-r="canh"/>' +
    '<circle cx="104" cy="136" r="9" data-r="cham"/><circle cx="196" cy="136" r="9" data-r="cham"/>' },
  { id: "ca", name: "Con cá", emoji: "🐟", svg:
    '<ellipse cx="140" cy="150" rx="70" ry="48" data-r="than"/>' +
    '<path d="M210,150 L262,112 L262,188 Z" data-r="duoi"/>' +
    '<path d="M140,102 Q160,78 188,92 Q170,104 140,102 Z" data-r="vay"/>' },
  { id: "nha", name: "Ngôi nhà", emoji: "🏠", svg:
    '<rect x="90" y="160" width="120" height="95" data-r="tuong"/>' +
    '<path d="M70,165 L150,92 L230,165 Z" data-r="mai"/>' +
    '<rect x="135" y="198" width="30" height="57" data-r="cua"/>' +
    '<rect x="102" y="180" width="32" height="32" data-r="cuaso"/>' },
  { id: "hoa", name: "Bông hoa", emoji: "🌸", svg:
    '<path d="M144,285 L144,165 L156,165 L156,285 Z" data-r="than"/>' +
    '<path d="M150,235 Q118,228 102,200 Q134,198 150,235 Z" data-r="la"/>' +
    '<path d="M150,235 Q182,228 198,200 Q166,198 150,235 Z" data-r="la"/>' +
    '<circle cx="150" cy="62" r="28" data-r="canh"/><circle cx="190" cy="95" r="28" data-r="canh"/>' +
    '<circle cx="175" cy="140" r="28" data-r="canh"/><circle cx="125" cy="140" r="28" data-r="canh"/>' +
    '<circle cx="110" cy="95" r="28" data-r="canh"/><circle cx="150" cy="105" r="20" data-r="nhuy"/>' },
  { id: "oto", name: "Ô tô", emoji: "🚗", svg:
    '<rect x="55" y="155" width="180" height="55" rx="12" data-r="than"/>' +
    '<path d="M105,155 v-32 a12,12 0 0,1 12,-12 h56 a12,12 0 0,1 12,12 v32 Z" data-r="kinh"/>' +
    '<circle cx="100" cy="212" r="22" data-r="banh"/><circle cx="200" cy="212" r="22" data-r="banh"/>' },
  { id: "meo", name: "Chú mèo", emoji: "🐱", svg:
    '<circle cx="150" cy="130" r="55" data-r="dau"/>' +
    '<path d="M108,85 L92,38 L140,62 Z" data-r="tai"/><path d="M192,85 L208,38 L160,62 Z" data-r="tai"/>' +
    '<ellipse cx="150" cy="248" rx="45" ry="40" data-r="than"/>' },
  { id: "tho", name: "Chú thỏ", emoji: "🐰", svg:
    '<ellipse cx="124" cy="78" rx="16" ry="44" data-r="tai"/><ellipse cx="176" cy="78" rx="16" ry="44" data-r="tai"/>' +
    '<circle cx="150" cy="165" r="50" data-r="dau"/>' +
    '<ellipse cx="150" cy="256" rx="50" ry="32" data-r="than"/>' },
  { id: "tao", name: "Quả táo", emoji: "🍎", svg:
    '<path d="M150,115 C110,115 95,152 100,192 C105,232 130,252 150,252 C170,252 195,232 200,192 C205,152 190,115 150,115 Z" data-r="tao"/>' +
    '<path d="M146,115 L146,90 L154,90 L154,115 Z" data-r="cuong"/>' +
    '<path d="M160,92 Q184,80 200,92 Q184,108 160,92 Z" data-r="la"/>' },
  { id: "mattroi", name: "Ông mặt trời", emoji: "☀️", svg:
    '<circle cx="150" cy="150" r="55" data-r="mat"/>' +
    '<path d="M138,74 L150,44 L162,74 Z" data-r="tia"/><path d="M138,226 L150,256 L162,226 Z" data-r="tia"/>' +
    '<path d="M74,138 L44,150 L74,162 Z" data-r="tia"/><path d="M226,138 L256,150 L226,162 Z" data-r="tia"/>' +
    '<path d="M88,88 L66,66 L100,80 Z" data-r="tia"/><path d="M206,94 L228,72 L212,102 Z" data-r="tia"/>' +
    '<path d="M88,198 L66,220 L100,204 Z" data-r="tia"/><path d="M206,206 L228,228 L198,212 Z" data-r="tia"/>' },
  { id: "thuyen", name: "Chiếc thuyền", emoji: "⛵", svg:
    '<path d="M60,208 L240,208 L208,250 L92,250 Z" data-r="thuyen"/>' +
    '<rect x="146" y="100" width="8" height="112" data-r="cot"/>' +
    '<path d="M158,200 L158,112 L214,200 Z" data-r="buom"/>' +
    '<path d="M28,266 q26,-22 52,0 t52,0 t52,0 t52,0 t52,0 L288,292 L28,292 Z" data-r="song"/>' }
];
function coloringById(id) {
  for (var i = 0; i < COLORING_PAGES.length; i++) if (COLORING_PAGES[i].id === id) return COLORING_PAGES[i];
  return null;
}

// ---------------- Mẫu tô nét: pts = mảng các nét, mỗi nét là mảng [x,y] ----------------
function _ptsLine(x1, y1, x2, y2, n) {
  var p = [], i;
  for (i = 0; i <= n; i++) p.push([x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n]);
  return p;
}
function _ptsCircle(cx, cy, r, n) {
  var p = [], i, a;
  for (i = 0; i <= n; i++) { a = i / n * Math.PI * 2; p.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
  return p;
}
function _ptsWave() {
  var p = [], x;
  for (x = 40; x <= 260; x += 8) p.push([x, 150 + 55 * Math.sin((x - 40) / 220 * Math.PI * 4)]);
  return p;
}
function _ptsStar(cx, cy, ro, ri) {
  var p = [], i, a, r;
  for (i = 0; i <= 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; r = (i % 2 === 0) ? ro : ri; p.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
  return p;
}
function _ptsHeart(cx, cy, s) {
  var p = [], i, t, x, y;
  for (i = 0; i <= 44; i++) {
    t = i / 44 * Math.PI * 2;
    x = 16 * Math.pow(Math.sin(t), 3);
    y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
    p.push([cx + x * s, cy - y * s]);
  }
  return p;
}
var TRACE_ITEMS = [
  { id: "thang",   name: "Đường thẳng",   emoji: "➖", pts: [_ptsLine(40, 150, 260, 150, 12)], closed: false },
  { id: "ziczac",  name: "Đường ziczac",  emoji: "⚡", pts: [[[40, 150], [85, 100], [130, 200], [175, 100], [220, 200], [260, 150]]], closed: false },
  { id: "song",    name: "Đường sóng",    emoji: "🌊", pts: [_ptsWave()], closed: false },
  { id: "tron",    name: "Hình tròn",     emoji: "⭕", pts: [_ptsCircle(150, 150, 88, 26)], closed: true },
  { id: "vuong",   name: "Hình vuông",    emoji: "🟧", pts: [[[70, 70], [230, 70], [230, 230], [70, 230]]], closed: true },
  { id: "tamgiac", name: "Hình tam giác", emoji: "🔺", pts: [[[150, 62], [238, 228], [62, 228]]], closed: true },
  { id: "sao",     name: "Hình ngôi sao", emoji: "⭐", pts: [_ptsStar(150, 158, 95, 40)], closed: true },
  { id: "traitim", name: "Hình trái tim", emoji: "❤️", pts: [_ptsHeart(150, 168, 6.2)], closed: true },
  { id: "so0", emoji: "0️⃣", name: "Số 0", pts: [[[150, 62], [182, 78], [202, 116], [202, 178], [182, 216], [150, 232], [118, 216], [98, 178], [98, 116], [118, 78]]], closed: true },
  { id: "so1", emoji: "1️⃣", name: "Số 1", pts: [[[128, 96], [150, 66], [150, 234]]], closed: false },
  { id: "so2", emoji: "2️⃣", name: "Số 2", pts: [[[102, 104], [112, 74], [142, 62], [172, 74], [176, 104], [158, 136], [104, 206], [104, 234], [192, 234]]], closed: false },
  { id: "so3", emoji: "3️⃣", name: "Số 3", pts: [[[104, 88], [144, 62], [180, 82], [170, 118], [134, 132], [170, 148], [180, 184], [140, 210], [100, 192]]], closed: false },
  { id: "so4", emoji: "4️⃣", name: "Số 4", pts: [[[162, 62], [108, 162], [196, 162]], [[162, 62], [162, 234]]], closed: false },
  { id: "so5", emoji: "5️⃣", name: "Số 5", pts: [[[182, 72], [118, 72], [112, 132], [148, 142], [184, 158], [178, 202], [138, 226], [104, 208]]], closed: false },
  { id: "so6", emoji: "6️⃣", name: "Số 6", pts: [[[172, 72], [138, 82], [112, 132], [104, 182], [120, 216], [152, 230], [182, 214], [184, 182], [158, 168], [122, 174]]], closed: false },
  { id: "so7", emoji: "7️⃣", name: "Số 7", pts: [[[100, 72], [192, 72], [128, 234]]], closed: false },
  { id: "so8", emoji: "8️⃣", name: "Số 8", pts: [[[150, 62], [176, 78], [176, 108], [150, 124], [124, 108], [124, 78]], [[150, 124], [186, 144], [186, 188], [158, 214], [132, 214], [112, 188], [114, 144]]], closed: true },
  { id: "so9", emoji: "9️⃣", name: "Số 9", pts: [[[128, 228], [160, 218], [186, 168], [194, 118], [178, 84], [148, 70], [120, 86], [116, 116], [142, 132], [176, 126]]], closed: false }
];
function traceById(id) {
  for (var i = 0; i < TRACE_ITEMS.length; i++) if (TRACE_ITEMS[i].id === id) return TRACE_ITEMS[i];
  return null;
}

// ---------------- 4 combo pha màu ----------------
var MIX_COMBOS = [
  { a: "do",        b: "vang",      r: "cam",     audio: "mix_dovang",   sAudio: "mixs_dovang" },
  { a: "xanhduong", b: "vang",      r: "xanhla",  audio: "mix_xanhvang", sAudio: "mixs_xanhvang" },
  { a: "do",        b: "xanhduong", r: "tim",     audio: "mix_doxanh",   sAudio: "mixs_doxanh" },
  { a: "den",       b: "trang",     r: "xam",     audio: "mix_dentrang", sAudio: "mixs_dentrang" }
];

// ---------------- 12 câu đúng / sai về màu sắc ----------------
var TF_ITEMS = [
  { id: "tf_1",  text: "Cà chua có màu đỏ.",          ok: true },
  { id: "tf_2",  text: "Quả chuối có màu xanh dương.", ok: false },
  { id: "tf_3",  text: "Lá cây có màu xanh lá.",       ok: true },
  { id: "tf_4",  text: "Mặt trời có màu tím.",         ok: false },
  { id: "tf_5",  text: "Bầu trời có màu xanh dương.",  ok: true },
  { id: "tf_6",  text: "Tuyết có màu đen.",            ok: false },
  { id: "tf_7",  text: "Quả cam có màu cam.",          ok: true },
  { id: "tf_8",  text: "Con quạ có màu trắng.",        ok: false },
  { id: "tf_9",  text: "Hoa hồng có màu hồng.",        ok: true },
  { id: "tf_10", text: "Sô cô la có màu nâu.",         ok: true },
  { id: "tf_11", text: "Quả dưa hấu có màu vàng.",     ok: false },
  { id: "tf_12", text: "Đám mây có màu trắng.",        ok: true }
];


// ============================================================
// NỘI DUNG MỚI v1.1 (đã merge từ newdata.js ngày 2026-10-01)
// 6 bài vẽ từng bước + 6 tranh tô màu + 8 chữ cái tô nét + game Đố vui hội họa
// ============================================================
STEP_LESSONS = STEP_LESSONS.concat([
  {
    "id": "les11",
    "name": "Con chó",
    "emoji": "🐶",
    "audio": "les11_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ cái đầu tròn xoe",
        "svg": "<circle cx=\"150\" cy=\"120\" r=\"55\"/>"
      },
      {
        "t": "Bước 2: Vẽ đôi tai cụp xinh",
        "svg": "<path d=\"M108,82 Q72,88 68,132 Q96,124 110,100 Z\"/><path d=\"M192,82 Q228,88 232,132 Q204,124 190,100 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ mắt, mũi và miệng",
        "svg": "<circle cx=\"132\" cy=\"112\" r=\"8\"/><circle cx=\"168\" cy=\"112\" r=\"8\"/><ellipse cx=\"150\" cy=\"138\" rx=\"10\" ry=\"7\"/><path d=\"M150,145 L150,156 M150,156 Q141,163 133,157 M150,156 Q159,163 167,157\"/>"
      },
      {
        "t": "Bước 4: Vẽ lưỡi thè và đốm lông",
        "svg": "<path d=\"M141,158 L141,182 Q150,188 159,182 L159,158\"/><path d=\"M150,166 L150,182\"/><circle cx=\"182\" cy=\"88\" r=\"11\"/>"
      },
      {
        "t": "Bước 5: Vẽ thân, chân và đuôi",
        "svg": "<ellipse cx=\"150\" cy=\"238\" rx=\"42\" ry=\"40\"/><path d=\"M122,272 L122,292 M178,272 L178,292\"/><path d=\"M190,240 Q232,234 230,196\"/>"
      }
    ]
  },
  {
    "id": "les12",
    "name": "Con vịt",
    "emoji": "🦆",
    "audio": "les12_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ mình vịt bầu bĩnh",
        "svg": "<ellipse cx=\"140\" cy=\"178\" rx=\"65\" ry=\"46\"/>"
      },
      {
        "t": "Bước 2: Vẽ đầu tròn và mỏ dẹt",
        "svg": "<circle cx=\"205\" cy=\"100\" r=\"32\"/><path d=\"M232,94 L258,103 L232,114 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ mắt và cánh xinh",
        "svg": "<circle cx=\"200\" cy=\"93\" r=\"6\"/><path d=\"M108,168 Q145,146 178,168 Q145,190 108,168 Z\"/>"
      },
      {
        "t": "Bước 4: Vẽ đuôi và chân vịt",
        "svg": "<path d=\"M78,168 L46,152 L50,188 Z\"/><path d=\"M118,222 L118,244 M118,244 L106,254 M118,244 L130,254 M162,222 L162,244 M162,244 L150,254 M162,244 L174,254\"/>"
      },
      {
        "t": "Bước 5: Vẽ chỏm lông và mặt nước",
        "svg": "<path d=\"M196,70 Q190,54 180,50 M204,68 Q204,52 210,44\"/><path d=\"M40,272 q26,-16 52,0 t52,0 t52,0 t52,0\"/>"
      }
    ]
  },
  {
    "id": "les13",
    "name": "Cái cây",
    "emoji": "🌳",
    "audio": "les13_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân cây thẳng đứng",
        "svg": "<path d=\"M140,292 L143,170 L157,170 L160,292 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ cành cây hai bên",
        "svg": "<path d=\"M144,215 L106,182 M156,205 L192,176\"/>"
      },
      {
        "t": "Bước 3: Vẽ tán lá tròn to",
        "svg": "<circle cx=\"150\" cy=\"108\" r=\"55\"/><circle cx=\"103\" cy=\"140\" r=\"36\"/><circle cx=\"197\" cy=\"140\" r=\"36\"/>"
      },
      {
        "t": "Bước 4: Vẽ những quả chín",
        "svg": "<circle cx=\"128\" cy=\"102\" r=\"10\"/><circle cx=\"172\" cy=\"118\" r=\"10\"/><circle cx=\"150\" cy=\"140\" r=\"10\"/>"
      },
      {
        "t": "Bước 5: Vẽ cỏ dưới gốc cây",
        "svg": "<path d=\"M84,292 q8,-20 16,0 M108,292 q8,-26 16,0 M176,292 q8,-20 16,0 M200,292 q8,-26 16,0\"/>"
      }
    ]
  },
  {
    "id": "les14",
    "name": "Quả dưa hấu",
    "emoji": "🍉",
    "audio": "les14_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ nửa quả dưa hấu",
        "svg": "<path d=\"M60,145 A95,95 0 0,0 240,145 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ viền vỏ dưa",
        "svg": "<path d=\"M74,145 A81,81 0 0,0 226,145\"/>"
      },
      {
        "t": "Bước 3: Vẽ sọc trên vỏ dưa",
        "svg": "<path d=\"M108,68 Q100,105 103,145 M150,52 L150,145 M192,68 Q200,105 197,145\"/>"
      },
      {
        "t": "Bước 4: Vẽ hạt dưa xinh",
        "svg": "<ellipse cx=\"118\" cy=\"105\" rx=\"5\" ry=\"8\"/><ellipse cx=\"150\" cy=\"120\" rx=\"5\" ry=\"8\"/><ellipse cx=\"182\" cy=\"105\" rx=\"5\" ry=\"8\"/><ellipse cx=\"134\" cy=\"82\" rx=\"5\" ry=\"8\"/><ellipse cx=\"166\" cy=\"82\" rx=\"5\" ry=\"8\"/>"
      }
    ]
  },
  {
    "id": "les15",
    "name": "Con thuyền",
    "emoji": "🚤",
    "audio": "les15_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân thuyền",
        "svg": "<path d=\"M70,190 L230,190 L200,242 L100,242 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ ghế ngồi",
        "svg": "<path d=\"M120,190 L120,170 L180,170 L180,190\"/>"
      },
      {
        "t": "Bước 3: Vẽ hai mái chèo",
        "svg": "<path d=\"M96,168 L56,128\"/><ellipse cx=\"49\" cy=\"121\" rx=\"13\" ry=\"8\" transform=\"rotate(-40 49 121)\"/><path d=\"M204,168 L244,128\"/><ellipse cx=\"251\" cy=\"121\" rx=\"13\" ry=\"8\" transform=\"rotate(40 251 121)\"/>"
      },
      {
        "t": "Bước 4: Vẽ sóng nước",
        "svg": "<path d=\"M40,264 q26,-18 52,0 t52,0 t52,0 t52,0\"/>"
      }
    ]
  },
  {
    "id": "les16",
    "name": "Ngôi sao biển",
    "emoji": "⭐",
    "audio": "les16_intro",
    "steps": [
      {
        "t": "Bước 1: Vẽ ngôi sao năm cánh",
        "svg": "<path d=\"M150,58 L166,114 L224,114 L177,149 L193,206 L150,171 L107,206 L123,149 L76,114 L134,114 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ mắt cười xinh",
        "svg": "<circle cx=\"138\" cy=\"128\" r=\"7\"/><circle cx=\"162\" cy=\"128\" r=\"7\"/><path d=\"M140,146 Q150,155 160,146\"/>"
      },
      {
        "t": "Bước 3: Vẽ chấm tròn trên cánh",
        "svg": "<circle cx=\"150\" cy=\"92\" r=\"6\"/><circle cx=\"186\" cy=\"132\" r=\"6\"/><circle cx=\"170\" cy=\"180\" r=\"6\"/><circle cx=\"130\" cy=\"180\" r=\"6\"/><circle cx=\"114\" cy=\"132\" r=\"6\"/>"
      },
      {
        "t": "Bước 4: Vẽ cát và vỏ sò",
        "svg": "<path d=\"M50,266 L250,266\"/><circle cx=\"82\" cy=\"252\" r=\"12\"/><path d=\"M205,266 Q200,246 218,246 Q236,246 232,266 Z\"/>"
      }
    ]
  }
]);
COLORING_PAGES = COLORING_PAGES.concat([
  {
    "id": "col11",
    "name": "Con ong",
    "emoji": "🐝",
    "audio": "col11",
    "svg": "<ellipse cx=\"150\" cy=\"168\" rx=\"58\" ry=\"48\" data-r=\"than\"/><path d=\"M118,124 Q150,142 182,124 L182,150 Q150,168 118,150 Z\" data-r=\"soc\"/><path d=\"M112,176 Q150,196 188,176 L188,202 Q150,222 112,202 Z\" data-r=\"soc\"/><circle cx=\"150\" cy=\"94\" r=\"24\" data-r=\"dau\"/><ellipse cx=\"102\" cy=\"100\" rx=\"24\" ry=\"36\" data-r=\"canh\"/><ellipse cx=\"198\" cy=\"100\" rx=\"24\" ry=\"36\" data-r=\"canh\"/><path d=\"M206,176 L230,188 L206,200 Z\" data-r=\"ngoi\"/>"
  },
  {
    "id": "col12",
    "name": "Quả chuối",
    "emoji": "🍌",
    "audio": "col12",
    "svg": "<path d=\"M82,72 C62,160 102,230 192,240 C240,245 268,220 262,196 C258,180 240,182 236,198 C230,224 200,230 170,222 C120,210 100,150 108,74 Z\" data-r=\"chuoi\"/><rect x=\"96\" y=\"56\" width=\"24\" height=\"28\" rx=\"7\" data-r=\"cuong\"/><circle cx=\"260\" cy=\"200\" r=\"10\" data-r=\"dau\"/>"
  },
  {
    "id": "col13",
    "name": "Đám mây",
    "emoji": "☁️",
    "audio": "col13",
    "svg": "<circle cx=\"105\" cy=\"188\" r=\"34\" data-r=\"may\"/><circle cx=\"150\" cy=\"158\" r=\"44\" data-r=\"may\"/><circle cx=\"200\" cy=\"168\" r=\"38\" data-r=\"may\"/><circle cx=\"228\" cy=\"198\" r=\"28\" data-r=\"may\"/><path d=\"M115,240 q11,15 0,27 q-11,-12 0,-27 Z\" data-r=\"mua\"/><path d=\"M155,248 q11,15 0,27 q-11,-12 0,-27 Z\" data-r=\"mua\"/><path d=\"M195,240 q11,15 0,27 q-11,-12 0,-27 Z\" data-r=\"mua\"/>"
  },
  {
    "id": "col14",
    "name": "Con rùa",
    "emoji": "🐢",
    "audio": "col14",
    "svg": "<ellipse cx=\"150\" cy=\"168\" rx=\"74\" ry=\"56\" data-r=\"mai\"/><path d=\"M150,128 L184,148 L184,188 L150,208 L116,188 L116,148 Z\" data-r=\"van\"/><circle cx=\"236\" cy=\"152\" r=\"25\" data-r=\"dau\"/><ellipse cx=\"96\" cy=\"218\" rx=\"20\" ry=\"13\" data-r=\"chan\"/><ellipse cx=\"204\" cy=\"218\" rx=\"20\" ry=\"13\" data-r=\"chan\"/><ellipse cx=\"92\" cy=\"128\" rx=\"17\" ry=\"12\" data-r=\"chan\"/><path d=\"M78,168 L52,158 L56,182 Z\" data-r=\"duoi\"/>"
  },
  {
    "id": "col15",
    "name": "Cái nấm",
    "emoji": "🍄",
    "audio": "col15",
    "svg": "<path d=\"M55,148 C55,72 105,55 150,55 C195,55 245,72 245,148 C200,132 100,132 55,148 Z\" data-r=\"mu\"/><circle cx=\"110\" cy=\"98\" r=\"13\" data-r=\"cham\"/><circle cx=\"165\" cy=\"86\" r=\"10\" data-r=\"cham\"/><circle cx=\"196\" cy=\"112\" r=\"12\" data-r=\"cham\"/><path d=\"M126,138 L126,230 Q150,242 174,230 L174,138 Q150,128 126,138 Z\" data-r=\"than\"/><path d=\"M50,264 Q75,246 100,264 Q125,246 150,264 Q175,246 200,264 Q225,246 250,264 L250,282 L50,282 Z\" data-r=\"co\"/>"
  },
  {
    "id": "col16",
    "name": "Chiếc diều",
    "emoji": "🪁",
    "audio": "col16",
    "svg": "<path d=\"M150,42 L214,130 L150,130 Z\" data-r=\"tren\"/><path d=\"M214,130 L150,218 L150,130 Z\" data-r=\"phai\"/><path d=\"M150,218 L86,130 L150,130 Z\" data-r=\"duoi\"/><path d=\"M86,130 L150,42 L150,130 Z\" data-r=\"trai\"/><path d=\"M146,218 Q136,244 151,262 L159,257 Q146,242 154,218 Z\" data-r=\"day\"/><path d=\"M141,236 L129,245 L144,249 Z\" data-r=\"no\"/><path d=\"M149,251 L139,261 L154,263 Z\" data-r=\"no\"/>"
  }
]);
TRACE_ITEMS = TRACE_ITEMS.concat([
  {
    "id": "chu_a",
    "emoji": "🇦",
    "name": "Chữ A",
    "audio": "chu_a",
    "closed": false,
    "pts": [
      [
        [
          100,
          234
        ],
        [
          150,
          66
        ],
        [
          200,
          234
        ]
      ],
      [
        [
          124,
          152
        ],
        [
          176,
          152
        ]
      ]
    ]
  },
  {
    "id": "chu_b",
    "emoji": "🇧",
    "name": "Chữ B",
    "audio": "chu_b",
    "closed": false,
    "pts": [
      [
        [
          130,
          66
        ],
        [
          130,
          234
        ]
      ],
      [
        [
          130,
          66
        ],
        [
          168,
          66
        ],
        [
          186,
          88
        ],
        [
          186,
          122
        ],
        [
          168,
          144
        ],
        [
          130,
          144
        ]
      ],
      [
        [
          130,
          144
        ],
        [
          168,
          144
        ],
        [
          188,
          164
        ],
        [
          188,
          208
        ],
        [
          168,
          234
        ],
        [
          130,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_c",
    "emoji": "🇨",
    "name": "Chữ C",
    "audio": "chu_c",
    "closed": false,
    "pts": [
      [
        [
          192,
          98
        ],
        [
          160,
          66
        ],
        [
          120,
          72
        ],
        [
          100,
          112
        ],
        [
          100,
          188
        ],
        [
          122,
          226
        ],
        [
          162,
          232
        ],
        [
          192,
          202
        ]
      ]
    ]
  },
  {
    "id": "chu_d",
    "emoji": "🇩",
    "name": "Chữ D",
    "audio": "chu_d",
    "closed": false,
    "pts": [
      [
        [
          130,
          66
        ],
        [
          130,
          234
        ]
      ],
      [
        [
          130,
          66
        ],
        [
          172,
          66
        ],
        [
          200,
          122
        ],
        [
          200,
          178
        ],
        [
          172,
          234
        ],
        [
          130,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_e",
    "emoji": "🇪",
    "name": "Chữ E",
    "audio": "chu_e",
    "closed": false,
    "pts": [
      [
        [
          182,
          66
        ],
        [
          112,
          66
        ],
        [
          112,
          234
        ],
        [
          182,
          234
        ]
      ],
      [
        [
          112,
          150
        ],
        [
          166,
          150
        ]
      ]
    ]
  },
  {
    "id": "chu_f",
    "emoji": "🇫",
    "name": "Chữ F",
    "audio": "chu_f",
    "closed": false,
    "pts": [
      [
        [
          182,
          66
        ],
        [
          112,
          66
        ],
        [
          112,
          234
        ]
      ],
      [
        [
          112,
          150
        ],
        [
          166,
          150
        ]
      ]
    ]
  },
  {
    "id": "chu_g",
    "emoji": "🇬",
    "name": "Chữ G",
    "audio": "chu_g",
    "closed": false,
    "pts": [
      [
        [
          192,
          92
        ],
        [
          160,
          64
        ],
        [
          118,
          74
        ],
        [
          100,
          118
        ],
        [
          102,
          182
        ],
        [
          126,
          222
        ],
        [
          168,
          232
        ],
        [
          192,
          206
        ],
        [
          192,
          166
        ],
        [
          156,
          166
        ]
      ]
    ]
  },
  {
    "id": "chu_h",
    "emoji": "🇭",
    "name": "Chữ H",
    "audio": "chu_h",
    "closed": false,
    "pts": [
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ]
      ],
      [
        [
          190,
          66
        ],
        [
          190,
          234
        ]
      ],
      [
        [
          110,
          150
        ],
        [
          190,
          150
        ]
      ]
    ]
  }
]);

// Game mới: ĐỐ VUI HỘI HỌA (12 câu, mỗi câu {id, audio, q, choices[3], answer})
var ART_QUIZ = [
  {
    "id": "art_q01",
    "audio": "art_q01",
    "q": "Cầu vồng có mấy màu?",
    "choices": [
      "Năm màu",
      "Sáu màu",
      "Bảy màu"
    ],
    "answer": 2
  },
  {
    "id": "art_q02",
    "audio": "art_q02",
    "q": "Bé pha màu đỏ với màu vàng thì được màu gì?",
    "choices": [
      "Màu cam",
      "Màu tím",
      "Màu hồng"
    ],
    "answer": 0
  },
  {
    "id": "art_q03",
    "audio": "art_q03",
    "q": "Con ngựa vằn có hai màu gì?",
    "choices": [
      "Đen và trắng",
      "Đỏ và vàng",
      "Xanh và tím"
    ],
    "answer": 0
  },
  {
    "id": "art_q04",
    "audio": "art_q04",
    "q": "Lá cây có màu gì?",
    "choices": [
      "Màu đỏ",
      "Màu xanh lá",
      "Màu vàng"
    ],
    "answer": 1
  },
  {
    "id": "art_q05",
    "audio": "art_q05",
    "q": "Bé pha màu xanh dương với màu vàng thì được màu gì?",
    "choices": [
      "Màu xanh lá",
      "Màu cam",
      "Màu tím"
    ],
    "answer": 0
  },
  {
    "id": "art_q06",
    "audio": "art_q06",
    "q": "Ông mặt trời có màu gì?",
    "choices": [
      "Màu tím",
      "Màu xanh dương",
      "Màu vàng"
    ],
    "answer": 2
  },
  {
    "id": "art_q07",
    "audio": "art_q07",
    "q": "Bầu trời trong xanh có màu gì?",
    "choices": [
      "Màu xanh dương",
      "Màu nâu",
      "Màu đen"
    ],
    "answer": 0
  },
  {
    "id": "art_q08",
    "audio": "art_q08",
    "q": "Bé pha màu đen với màu trắng thì được màu gì?",
    "choices": [
      "Màu xám",
      "Màu hồng",
      "Màu đỏ"
    ],
    "answer": 0
  },
  {
    "id": "art_q09",
    "audio": "art_q09",
    "q": "Quả cà chua chín có màu gì?",
    "choices": [
      "Màu xanh lá",
      "Màu đỏ",
      "Màu tím"
    ],
    "answer": 1
  },
  {
    "id": "art_q10",
    "audio": "art_q10",
    "q": "Ban đêm, bầu trời tối có màu gì?",
    "choices": [
      "Màu đen",
      "Màu trắng",
      "Màu vàng"
    ],
    "answer": 0
  },
  {
    "id": "art_q11",
    "audio": "art_q11",
    "q": "Bé pha màu đỏ với màu xanh dương thì được màu gì?",
    "choices": [
      "Màu tím",
      "Màu cam",
      "Màu nâu"
    ],
    "answer": 0
  },
  {
    "id": "art_q12",
    "audio": "art_q12",
    "q": "Cánh hoa hướng dương có màu gì?",
    "choices": [
      "Màu xanh dương",
      "Màu vàng",
      "Màu tím"
    ],
    "answer": 1
  }
];
function artQuizById(id) {
  for (var i = 0; i < ART_QUIZ.length; i++) if (ART_QUIZ[i].id === id) return ART_QUIZ[i];
  return null;
}

// 38 key audio mới -> nối vào map UI_AUDIO (giữ nguyên tham chiếu object UA)
UI_AUDIO_KEYS = UI_AUDIO_KEYS.concat(["les11_intro","les12_intro","les13_intro","les14_intro","les15_intro","les16_intro","col11","col12","col13","col14","col15","col16","chu_a","chu_b","chu_c","chu_d","chu_e","chu_f","chu_g","chu_h","art_intro","art_guide","art_q01","art_q02","art_q03","art_q04","art_q05","art_q06","art_q07","art_q08","art_q09","art_q10","art_q11","art_q12","gal_name","gal_named_ok","gal_slide","gal_slide_end"]);
(function () {
  for (var i = 0; i < UI_AUDIO_KEYS.length; i++) {
    if (!UI_AUDIO[UI_AUDIO_KEYS[i]]) UI_AUDIO[UI_AUDIO_KEYS[i]] = "audio/" + UI_AUDIO_KEYS[i] + ".mp3";
  }
})();



// ============================================================
// NỘI DUNG MỚI v1.2 (ngày 2026-10-01)
// +26 mẫu tô nét (18 chữ cái I-Z + 8 mẫu mới) | +16 bài vẽ từng bước
// +22 tranh tô màu | +24 câu đố vui hội họa | +8 màu | +4 hình khối | +6 combo pha màu
// ============================================================
TRACE_ITEMS = TRACE_ITEMS.concat([
  {
    "id": "chu_i",
    "emoji": "🇮",
    "name": "Chữ I",
    "audio": "chu_i",
    "closed": false,
    "pts": [
      [
        [
          90,
          66
        ],
        [
          130,
          66
        ]
      ],
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ]
      ],
      [
        [
          90,
          234
        ],
        [
          130,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_j",
    "emoji": "🇯",
    "name": "Chữ J",
    "audio": "chu_j",
    "closed": false,
    "pts": [
      [
        [
          170,
          66
        ],
        [
          170,
          196
        ],
        [
          152,
          224
        ],
        [
          120,
          228
        ],
        [
          100,
          208
        ]
      ]
    ]
  },
  {
    "id": "chu_k",
    "emoji": "🇰",
    "name": "Chữ K",
    "audio": "chu_k",
    "closed": false,
    "pts": [
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ]
      ],
      [
        [
          192,
          66
        ],
        [
          110,
          150
        ]
      ],
      [
        [
          148,
          112
        ],
        [
          192,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_l",
    "emoji": "🇱",
    "name": "Chữ L",
    "audio": "chu_l",
    "closed": false,
    "pts": [
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ],
        [
          192,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_m",
    "emoji": "🇲",
    "name": "Chữ M",
    "audio": "chu_m",
    "closed": false,
    "pts": [
      [
        [
          100,
          234
        ],
        [
          100,
          66
        ],
        [
          150,
          150
        ],
        [
          200,
          66
        ],
        [
          200,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_n",
    "emoji": "🇳",
    "name": "Chữ N",
    "audio": "chu_n",
    "closed": false,
    "pts": [
      [
        [
          100,
          234
        ],
        [
          100,
          66
        ],
        [
          200,
          234
        ],
        [
          200,
          66
        ]
      ]
    ]
  },
  {
    "id": "chu_o",
    "emoji": "🇴",
    "name": "Chữ O",
    "audio": "chu_o",
    "closed": true,
    "pts": [
      [
        [
          150,
          66
        ],
        [
          184,
          84
        ],
        [
          200,
          120
        ],
        [
          200,
          180
        ],
        [
          184,
          216
        ],
        [
          150,
          234
        ],
        [
          116,
          216
        ],
        [
          100,
          180
        ],
        [
          100,
          120
        ],
        [
          116,
          84
        ]
      ]
    ]
  },
  {
    "id": "chu_p",
    "emoji": "🇵",
    "name": "Chữ P",
    "audio": "chu_p",
    "closed": false,
    "pts": [
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ]
      ],
      [
        [
          110,
          66
        ],
        [
          170,
          66
        ],
        [
          192,
          92
        ],
        [
          192,
          128
        ],
        [
          170,
          152
        ],
        [
          110,
          152
        ]
      ]
    ]
  },
  {
    "id": "chu_q",
    "emoji": "🇶",
    "name": "Chữ Q",
    "audio": "chu_q",
    "closed": false,
    "pts": [
      [
        [
          150,
          66
        ],
        [
          184,
          84
        ],
        [
          200,
          120
        ],
        [
          200,
          180
        ],
        [
          184,
          216
        ],
        [
          150,
          234
        ],
        [
          116,
          216
        ],
        [
          100,
          180
        ],
        [
          100,
          120
        ],
        [
          116,
          84
        ]
      ],
      [
        [
          168,
          198
        ],
        [
          208,
          242
        ]
      ]
    ]
  },
  {
    "id": "chu_r",
    "emoji": "🇷",
    "name": "Chữ R",
    "audio": "chu_r",
    "closed": false,
    "pts": [
      [
        [
          110,
          66
        ],
        [
          110,
          234
        ]
      ],
      [
        [
          110,
          66
        ],
        [
          170,
          66
        ],
        [
          192,
          92
        ],
        [
          192,
          128
        ],
        [
          170,
          152
        ],
        [
          110,
          152
        ]
      ],
      [
        [
          150,
          152
        ],
        [
          198,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_s",
    "emoji": "🇸",
    "name": "Chữ S",
    "audio": "chu_s",
    "closed": false,
    "pts": [
      [
        [
          188,
          96
        ],
        [
          160,
          66
        ],
        [
          118,
          76
        ],
        [
          104,
          108
        ],
        [
          112,
          142
        ],
        [
          150,
          150
        ],
        [
          188,
          158
        ],
        [
          196,
          192
        ],
        [
          178,
          222
        ],
        [
          140,
          232
        ],
        [
          106,
          216
        ]
      ]
    ]
  },
  {
    "id": "chu_t",
    "emoji": "🇹",
    "name": "Chữ T",
    "audio": "chu_t",
    "closed": false,
    "pts": [
      [
        [
          150,
          66
        ],
        [
          150,
          234
        ]
      ],
      [
        [
          95,
          66
        ],
        [
          205,
          66
        ]
      ]
    ]
  },
  {
    "id": "chu_u",
    "emoji": "🇺",
    "name": "Chữ U",
    "audio": "chu_u",
    "closed": false,
    "pts": [
      [
        [
          100,
          66
        ],
        [
          100,
          178
        ],
        [
          116,
          212
        ],
        [
          140,
          228
        ],
        [
          160,
          228
        ],
        [
          184,
          212
        ],
        [
          200,
          178
        ],
        [
          200,
          66
        ]
      ]
    ]
  },
  {
    "id": "chu_v",
    "emoji": "🇻",
    "name": "Chữ V",
    "audio": "chu_v",
    "closed": false,
    "pts": [
      [
        [
          95,
          66
        ],
        [
          150,
          234
        ],
        [
          205,
          66
        ]
      ]
    ]
  },
  {
    "id": "chu_w",
    "emoji": "🇼",
    "name": "Chữ W",
    "audio": "chu_w",
    "closed": false,
    "pts": [
      [
        [
          80,
          66
        ],
        [
          110,
          234
        ],
        [
          150,
          130
        ],
        [
          190,
          234
        ],
        [
          220,
          66
        ]
      ]
    ]
  },
  {
    "id": "chu_x",
    "emoji": "🇽",
    "name": "Chữ X",
    "audio": "chu_x",
    "closed": false,
    "pts": [
      [
        [
          100,
          66
        ],
        [
          200,
          234
        ]
      ],
      [
        [
          200,
          66
        ],
        [
          100,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_y",
    "emoji": "🇾",
    "name": "Chữ Y",
    "audio": "chu_y",
    "closed": false,
    "pts": [
      [
        [
          95,
          66
        ],
        [
          150,
          150
        ],
        [
          205,
          66
        ]
      ],
      [
        [
          150,
          150
        ],
        [
          150,
          234
        ]
      ]
    ]
  },
  {
    "id": "chu_z",
    "emoji": "🇿",
    "name": "Chữ Z",
    "audio": "chu_z",
    "closed": false,
    "pts": [
      [
        [
          100,
          66
        ],
        [
          200,
          66
        ],
        [
          100,
          234
        ],
        [
          200,
          234
        ]
      ]
    ]
  },
  {
    "id": "tr_duongcong",
    "emoji": "↪️",
    "name": "Đường cong",
    "pts": [
      [
        [
          40,
          170
        ],
        [
          90,
          110
        ],
        [
          150,
          80
        ],
        [
          210,
          110
        ],
        [
          260,
          170
        ]
      ]
    ],
    "closed": false
  },
  {
    "id": "tr_songdoi",
    "emoji": "〰️",
    "name": "Sóng đôi",
    "pts": [
      [
        [
          40,
          120
        ],
        [
          90,
          80
        ],
        [
          140,
          120
        ],
        [
          190,
          80
        ],
        [
          240,
          120
        ]
      ],
      [
        [
          40,
          180
        ],
        [
          90,
          140
        ],
        [
          140,
          180
        ],
        [
          190,
          140
        ],
        [
          240,
          180
        ]
      ]
    ],
    "closed": false
  },
  {
    "id": "tr_hinhthang",
    "emoji": "🔷",
    "name": "Hình thang",
    "pts": [
      [
        [
          90,
          230
        ],
        [
          110,
          80
        ],
        [
          190,
          80
        ],
        [
          210,
          230
        ]
      ]
    ],
    "closed": true
  },
  {
    "id": "tr_ngugiac",
    "emoji": "⬠",
    "name": "Ngũ giác",
    "pts": [
      [
        [
          150,
          60
        ],
        [
          236,
          122
        ],
        [
          203,
          223
        ],
        [
          97,
          223
        ],
        [
          64,
          122
        ]
      ]
    ],
    "closed": true
  },
  {
    "id": "tr_lucgiac",
    "emoji": "⬡",
    "name": "Lục giác",
    "pts": [
      [
        [
          240,
          150
        ],
        [
          195,
          228
        ],
        [
          105,
          228
        ],
        [
          60,
          150
        ],
        [
          105,
          72
        ],
        [
          195,
          72
        ]
      ]
    ],
    "closed": true
  },
  {
    "id": "tr_dammay",
    "emoji": "☁️",
    "name": "Đám mây",
    "pts": [
      [
        [
          90,
          200
        ],
        [
          70,
          170
        ],
        [
          80,
          135
        ],
        [
          115,
          120
        ],
        [
          135,
          95
        ],
        [
          170,
          100
        ],
        [
          195,
          120
        ],
        [
          225,
          130
        ],
        [
          235,
          165
        ],
        [
          215,
          195
        ],
        [
          170,
          205
        ],
        [
          120,
          208
        ]
      ]
    ],
    "closed": true
  },
  {
    "id": "tr_giotnuoc",
    "emoji": "💧",
    "name": "Giọt nước",
    "pts": [
      [
        [
          150,
          60
        ],
        [
          195,
          140
        ],
        [
          195,
          190
        ],
        [
          165,
          225
        ],
        [
          135,
          225
        ],
        [
          105,
          190
        ],
        [
          105,
          140
        ]
      ]
    ],
    "closed": true
  },
  {
    "id": "tr_chiecla",
    "emoji": "🍃",
    "name": "Chiếc lá",
    "pts": [
      [
        [
          70,
          230
        ],
        [
          120,
          140
        ],
        [
          180,
          100
        ],
        [
          230,
          70
        ],
        [
          190,
          170
        ],
        [
          140,
          220
        ]
      ]
    ],
    "closed": true
  }
]);
STEP_LESSONS = STEP_LESSONS.concat([
  {
    "id": "cua",
    "name": "Con cua",
    "emoji": "🦀",
    "audio": "step_cua",
    "steps": [
      {
        "t": "Bước 1: Vẽ mình cua dẹp tròn",
        "svg": "<ellipse cx=\"150\" cy=\"160\" rx=\"70\" ry=\"45\"/>"
      },
      {
        "t": "Bước 2: Vẽ hai cái càng to",
        "svg": "<path d=\"M80,150 L62,128\"/><circle cx=\"58\" cy=\"112\" r=\"20\"/><path d=\"M220,150 L238,128\"/><circle cx=\"242\" cy=\"112\" r=\"20\"/>"
      },
      {
        "t": "Bước 3: Vẽ mắt trên cuống",
        "svg": "<path d=\"M130,120 L130,142 M170,120 L170,142\"/><circle cx=\"130\" cy=\"112\" r=\"10\"/><circle cx=\"170\" cy=\"112\" r=\"10\"/>"
      },
      {
        "t": "Bước 4: Vẽ tám cái chân",
        "svg": "<path d=\"M95,198 L75,232 M120,203 L105,240 M180,203 L195,240 M205,198 L225,232\"/>"
      },
      {
        "t": "Bước 5: Vẽ miệng cười xinh",
        "svg": "<path d=\"M138,172 Q150,182 162,172\"/>"
      }
    ]
  },
  {
    "id": "ong",
    "name": "Con ong",
    "emoji": "🐝",
    "audio": "step_ong",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân ong bầu bĩnh",
        "svg": "<ellipse cx=\"150\" cy=\"165\" rx=\"55\" ry=\"48\"/>"
      },
      {
        "t": "Bước 2: Vẽ sọc vàng đen",
        "svg": "<path d=\"M120,122 Q150,140 180,122 L180,148 Q150,166 120,148 Z\"/><path d=\"M113,172 Q150,192 187,172 L187,198 Q150,218 113,198 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ cái đầu tròn",
        "svg": "<circle cx=\"150\" cy=\"92\" r=\"24\"/>"
      },
      {
        "t": "Bước 4: Vẽ đôi cánh mỏng",
        "svg": "<ellipse cx=\"100\" cy=\"100\" rx=\"22\" ry=\"34\"/><ellipse cx=\"200\" cy=\"100\" rx=\"22\" ry=\"34\"/>"
      },
      {
        "t": "Bước 5: Vẽ râu và ngòi nhọn",
        "svg": "<path d=\"M140,70 Q134,52 124,46 M160,70 Q166,52 176,46\"/><circle cx=\"122\" cy=\"44\" r=\"4\"/><circle cx=\"178\" cy=\"44\" r=\"4\"/><path d=\"M204,172 L226,184 L204,196 Z\"/>"
      }
    ]
  },
  {
    "id": "tulip",
    "name": "Hoa tulip",
    "emoji": "🌷",
    "audio": "step_tulip",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân hoa thẳng",
        "svg": "<path d=\"M150,290 L150,170\"/>"
      },
      {
        "t": "Bước 2: Vẽ hai chiếc lá",
        "svg": "<path d=\"M150,240 Q118,232 104,205 Q134,202 150,240 Z\"/><path d=\"M150,240 Q182,232 196,205 Q166,202 150,240 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ ba cánh hoa",
        "svg": "<path d=\"M112,170 Q105,110 135,85 Q140,110 150,95 Q160,110 165,85 Q195,110 188,170 Z\"/>"
      },
      {
        "t": "Bước 4: Vẽ đài hoa",
        "svg": "<path d=\"M135,170 Q150,186 165,170\"/>"
      }
    ]
  },
  {
    "id": "thong",
    "name": "Cây thông",
    "emoji": "🎄",
    "audio": "step_thong",
    "steps": [
      {
        "t": "Bước 1: Vẽ tầng lá trên",
        "svg": "<path d=\"M150,50 L196,130 L104,130 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ tầng lá giữa",
        "svg": "<path d=\"M150,100 L212,190 L88,190 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ tầng lá dưới",
        "svg": "<path d=\"M150,150 L228,245 L72,245 Z\"/>"
      },
      {
        "t": "Bước 4: Vẽ thân cây",
        "svg": "<rect x=\"138\" y=\"245\" width=\"24\" height=\"40\"/>"
      },
      {
        "t": "Bước 5: Vẽ sao và quả châu",
        "svg": "<path d=\"M150,22 L156,36 L171,36 L159,45 L164,59 L150,50 L136,59 L141,45 L129,36 L144,36 Z\"/><circle cx=\"130\" cy=\"160\" r=\"8\"/><circle cx=\"170\" cy=\"200\" r=\"8\"/>"
      }
    ]
  },
  {
    "id": "chuoi",
    "name": "Quả chuối",
    "emoji": "🍌",
    "audio": "step_chuoi",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân chuối cong",
        "svg": "<path d=\"M100,70 C85,150 120,225 195,238 C230,244 252,228 248,208 C245,195 230,197 228,210 C224,228 200,232 175,226 C130,214 110,155 118,72 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ cuống chuối",
        "svg": "<rect x=\"106\" y=\"56\" width=\"24\" height=\"26\" rx=\"6\"/>"
      },
      {
        "t": "Bước 3: Vẽ đầu chuối",
        "svg": "<circle cx=\"246\" cy=\"212\" r=\"9\"/>"
      },
      {
        "t": "Bước 4: Vẽ sọc trên vỏ",
        "svg": "<path d=\"M140,120 Q135,165 145,205 M175,130 Q170,175 178,212\"/>"
      }
    ]
  },
  {
    "id": "keo",
    "name": "Cái kẹo",
    "emoji": "🍬",
    "audio": "step_keo",
    "steps": [
      {
        "t": "Bước 1: Vẽ viên kẹo tròn",
        "svg": "<circle cx=\"150\" cy=\"150\" r=\"55\"/>"
      },
      {
        "t": "Bước 2: Vẽ hai đầu xoắn",
        "svg": "<path d=\"M95,150 L45,120 L45,180 Z\"/><path d=\"M205,150 L255,120 L255,180 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ đường xoắn ốc",
        "svg": "<path d=\"M150,105 Q185,105 185,140 Q185,172 152,172 Q125,172 125,148 Q125,128 143,128\"/>"
      },
      {
        "t": "Bước 4: Vẽ chấm bi xinh",
        "svg": "<circle cx=\"128\" cy=\"150\" r=\"7\"/><circle cx=\"172\" cy=\"150\" r=\"7\"/><circle cx=\"150\" cy=\"185\" r=\"7\"/>"
      }
    ]
  },
  {
    "id": "rua",
    "name": "Con rùa",
    "emoji": "🐢",
    "audio": "step_rua",
    "steps": [
      {
        "t": "Bước 1: Vẽ mai rùa to",
        "svg": "<ellipse cx=\"150\" cy=\"165\" rx=\"75\" ry=\"55\"/>"
      },
      {
        "t": "Bước 2: Vẽ vân trên mai",
        "svg": "<path d=\"M150,125 L182,145 L182,185 L150,205 L118,185 L118,145 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ cái đầu tròn",
        "svg": "<circle cx=\"238\" cy=\"150\" r=\"25\"/>"
      },
      {
        "t": "Bước 4: Vẽ bốn cái chân",
        "svg": "<ellipse cx=\"95\" cy=\"215\" rx=\"20\" ry=\"12\"/><ellipse cx=\"205\" cy=\"215\" rx=\"20\" ry=\"12\"/><ellipse cx=\"92\" cy=\"128\" rx=\"17\" ry=\"11\"/><ellipse cx=\"208\" cy=\"128\" rx=\"17\" ry=\"11\"/>"
      },
      {
        "t": "Bước 5: Vẽ mắt và đuôi",
        "svg": "<circle cx=\"242\" cy=\"144\" r=\"5\"/><path d=\"M78,165 L52,155 L56,180 Z\"/>"
      }
    ]
  },
  {
    "id": "ga",
    "name": "Con gà",
    "emoji": "🐔",
    "audio": "step_ga",
    "steps": [
      {
        "t": "Bước 1: Vẽ mình gà tròn",
        "svg": "<ellipse cx=\"150\" cy=\"180\" rx=\"60\" ry=\"45\"/>"
      },
      {
        "t": "Bước 2: Vẽ đầu và mào đỏ",
        "svg": "<circle cx=\"205\" cy=\"105\" r=\"30\"/><path d=\"M188,80 Q185,62 196,58 Q198,70 205,66 Q208,76 216,74 Q214,84 222,86\"/>"
      },
      {
        "t": "Bước 3: Vẽ mỏ và mắt",
        "svg": "<path d=\"M232,100 L252,108 L232,118 Z\"/><circle cx=\"208\" cy=\"98\" r=\"5\"/>"
      },
      {
        "t": "Bước 4: Vẽ cánh và đuôi",
        "svg": "<path d=\"M115,170 Q150,150 180,170 Q150,192 115,170 Z\"/><path d=\"M95,165 L60,140 L62,180 Z\"/>"
      },
      {
        "t": "Bước 5: Vẽ đôi chân",
        "svg": "<path d=\"M135,222 L135,250 M135,250 L123,262 M135,250 L147,262 M165,222 L165,250 M165,250 L153,262 M165,250 L177,262\"/>"
      }
    ]
  },
  {
    "id": "dieu",
    "name": "Cái diều",
    "emoji": "🪁",
    "audio": "step_dieu",
    "steps": [
      {
        "t": "Bước 1: Vẽ khung diều",
        "svg": "<path d=\"M150,50 L215,135 L150,220 L85,135 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ thanh ngang",
        "svg": "<path d=\"M85,135 L215,135\"/>"
      },
      {
        "t": "Bước 3: Vẽ dây diều",
        "svg": "<path d=\"M150,220 Q140,250 155,270\"/>"
      },
      {
        "t": "Bước 4: Vẽ cái nơ",
        "svg": "<path d=\"M148,240 L134,248 L148,256 Z\"/><path d=\"M152,240 L166,248 L152,256 Z\"/>"
      },
      {
        "t": "Bước 5: Vẽ thêm nơ dưới",
        "svg": "<path d=\"M151,262 L141,270 L155,272 Z\"/>"
      }
    ]
  },
  {
    "id": "bong",
    "name": "Quả bóng",
    "emoji": "⚽",
    "audio": "step_bong",
    "steps": [
      {
        "t": "Bước 1: Vẽ vòng tròn to",
        "svg": "<circle cx=\"150\" cy=\"150\" r=\"70\"/>"
      },
      {
        "t": "Bước 2: Vẽ miếng vá giữa",
        "svg": "<path d=\"M150,125 L174,143 L165,171 L135,171 L126,143 Z\"/>"
      },
      {
        "t": "Bước 3: Vẽ đường nối",
        "svg": "<path d=\"M150,125 L150,95 M174,143 L200,132 M165,171 L182,196 M135,171 L118,196 M126,143 L100,132\"/>"
      },
      {
        "t": "Bước 4: Vẽ viền miếng vá",
        "svg": "<path d=\"M100,132 L84,118 M200,132 L216,118 M182,196 L188,222 M118,196 L112,222 M150,95 L150,80\"/>"
      }
    ]
  },
  {
    "id": "tuyet",
    "name": "Bông tuyết",
    "emoji": "❄️",
    "audio": "step_tuyet",
    "steps": [
      {
        "t": "Bước 1: Vẽ ba đường chéo",
        "svg": "<path d=\"M150,60 L150,240 M72,105 L228,195 M228,105 L72,195\"/>"
      },
      {
        "t": "Bước 2: Vẽ nhánh trên dưới",
        "svg": "<path d=\"M150,60 L132,84 M150,60 L168,84 M150,240 L132,216 M150,240 L168,216\"/>"
      },
      {
        "t": "Bước 3: Vẽ nhánh hai bên",
        "svg": "<path d=\"M72,105 L96,104 M72,105 L84,128 M228,195 L204,196 M228,195 L216,172 M228,105 L204,104 M228,105 L216,128 M72,195 L96,196 M72,195 L84,172\"/>"
      },
      {
        "t": "Bước 4: Vẽ chấm tròn giữa",
        "svg": "<circle cx=\"150\" cy=\"150\" r=\"12\"/>"
      }
    ]
  },
  {
    "id": "mu",
    "name": "Cái mũ",
    "emoji": "🎩",
    "audio": "step_mu",
    "steps": [
      {
        "t": "Bước 1: Vẽ vành mũ",
        "svg": "<ellipse cx=\"150\" cy=\"195\" rx=\"95\" ry=\"28\"/>"
      },
      {
        "t": "Bước 2: Vẽ chóp mũ",
        "svg": "<path d=\"M105,195 L105,110 Q150,95 195,110 L195,195\"/>"
      },
      {
        "t": "Bước 3: Vẽ nắp mũ",
        "svg": "<ellipse cx=\"150\" cy=\"110\" rx=\"45\" ry=\"12\"/>"
      },
      {
        "t": "Bước 4: Vẽ dải ruy băng",
        "svg": "<path d=\"M105,168 Q150,185 195,168 L195,188 Q150,205 105,188 Z\"/>"
      },
      {
        "t": "Bước 5: Vẽ cái nơ xinh",
        "svg": "<circle cx=\"150\" cy=\"186\" r=\"10\"/><path d=\"M140,186 L120,176 L122,196 Z\"/><path d=\"M160,186 L180,176 L178,196 Z\"/>"
      }
    ]
  },
  {
    "id": "sau",
    "name": "Con sâu",
    "emoji": "🐛",
    "audio": "step_sau",
    "steps": [
      {
        "t": "Bước 1: Vẽ các đốt tròn",
        "svg": "<circle cx=\"90\" cy=\"180\" r=\"28\"/><circle cx=\"140\" cy=\"165\" r=\"30\"/><circle cx=\"190\" cy=\"165\" r=\"30\"/><circle cx=\"238\" cy=\"180\" r=\"28\"/>"
      },
      {
        "t": "Bước 2: Vẽ đôi râu",
        "svg": "<path d=\"M230,154 Q224,134 212,130 M246,154 Q252,134 264,130\"/><circle cx=\"210\" cy=\"128\" r=\"6\"/><circle cx=\"266\" cy=\"128\" r=\"6\"/>"
      },
      {
        "t": "Bước 3: Vẽ mắt cười",
        "svg": "<circle cx=\"244\" cy=\"172\" r=\"6\"/><path d=\"M238,196 Q248,202 258,196\"/>"
      },
      {
        "t": "Bước 4: Vẽ chân nhỏ",
        "svg": "<path d=\"M90,206 L90,226 M140,194 L140,216 M190,194 L190,216 M238,206 L238,226\"/>"
      },
      {
        "t": "Bước 5: Vẽ chiếc lá",
        "svg": "<path d=\"M60,240 Q150,220 240,250 Q150,265 60,240 Z\"/>"
      }
    ]
  },
  {
    "id": "dua",
    "name": "Quả dứa",
    "emoji": "🍍",
    "audio": "step_dua",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân dứa",
        "svg": "<ellipse cx=\"150\" cy=\"180\" rx=\"60\" ry=\"70\"/>"
      },
      {
        "t": "Bước 2: Vẽ chùm lá",
        "svg": "<path d=\"M150,110 Q130,70 110,60 M150,110 Q150,66 150,52 M150,110 Q170,70 190,60 M150,110 Q135,80 125,78 M150,110 Q165,80 175,78\"/>"
      },
      {
        "t": "Bước 3: Vẽ mắt dứa",
        "svg": "<path d=\"M105,135 L195,225 M105,225 L195,135 M100,180 L200,180\"/>"
      },
      {
        "t": "Bước 4: Vẽ chấm giữa",
        "svg": "<circle cx=\"150\" cy=\"180\" r=\"4\"/>"
      }
    ]
  },
  {
    "id": "thuyenbuom",
    "name": "Thuyền buồm",
    "emoji": "⛵",
    "audio": "step_thuyenbuom",
    "steps": [
      {
        "t": "Bước 1: Vẽ thân thuyền",
        "svg": "<path d=\"M70,200 L230,200 L200,248 L100,248 Z\"/>"
      },
      {
        "t": "Bước 2: Vẽ cột buồm",
        "svg": "<rect x=\"146\" y=\"70\" width=\"8\" height=\"132\"/>"
      },
      {
        "t": "Bước 3: Vẽ buồm lớn",
        "svg": "<path d=\"M158,195 L158,80 L215,195 Z\"/>"
      },
      {
        "t": "Bước 4: Vẽ buồm nhỏ",
        "svg": "<path d=\"M142,195 L142,110 L95,195 Z\"/>"
      },
      {
        "t": "Bước 5: Vẽ cờ và sóng",
        "svg": "<path d=\"M154,70 L182,78 L154,88 Z\"/><path d=\"M50,268 q25,-16 50,0 t50,0 t50,0 t50,0\"/>"
      }
    ]
  },
  {
    "id": "mattroimu",
    "name": "Ông mặt trời đội mũ",
    "emoji": "🌞",
    "audio": "step_mattroimu",
    "steps": [
      {
        "t": "Bước 1: Vẽ mặt tròn",
        "svg": "<circle cx=\"150\" cy=\"155\" r=\"60\"/>"
      },
      {
        "t": "Bước 2: Vẽ tia nắng",
        "svg": "<path d=\"M150,73 L150,50 M150,260 L150,237 M68,155 L45,155 M255,155 L232,155 M93,98 L77,82 M223,228 L207,212 M207,98 L223,82 M77,228 L93,212\"/>"
      },
      {
        "t": "Bước 3: Vẽ cái mũ rơm",
        "svg": "<ellipse cx=\"150\" cy=\"80\" rx=\"70\" ry=\"18\"/><path d=\"M115,80 Q118,40 150,40 Q182,40 185,80\"/>"
      },
      {
        "t": "Bước 4: Vẽ mặt cười",
        "svg": "<circle cx=\"132\" cy=\"148\" r=\"8\"/><circle cx=\"168\" cy=\"148\" r=\"8\"/><path d=\"M130,175 Q150,190 170,175\"/>"
      }
    ]
  }
]);
COLORING_PAGES = COLORING_PAGES.concat([
  {
    "id": "cho",
    "name": "Con chó",
    "emoji": "🐶",
    "svg": "<circle cx=\"150\" cy=\"125\" r=\"55\" data-r=\"dau\"/><path d=\"M108,85 Q70,92 66,136 Q96,128 110,104 Z\" data-r=\"tai\"/><path d=\"M192,85 Q230,92 234,136 Q204,128 190,104 Z\" data-r=\"tai\"/><ellipse cx=\"150\" cy=\"240\" rx=\"42\" ry=\"38\" data-r=\"than\"/><ellipse cx=\"150\" cy=\"145\" rx=\"22\" ry=\"16\" data-r=\"mom\"/><path d=\"M190,242 Q232,236 230,198 L222,200 Q224,232 188,234 Z\" data-r=\"duoi\"/>"
  },
  {
    "id": "vit",
    "name": "Con vịt",
    "emoji": "🦆",
    "svg": "<ellipse cx=\"140\" cy=\"180\" rx=\"65\" ry=\"46\" data-r=\"than\"/><circle cx=\"205\" cy=\"100\" r=\"32\" data-r=\"dau\"/><path d=\"M232,94 L258,103 L232,114 Z\" data-r=\"mo\"/><path d=\"M108,168 Q145,146 178,168 Q145,190 108,168 Z\" data-r=\"canh\"/><path d=\"M78,168 L46,152 L50,188 Z\" data-r=\"duoi\"/><path d=\"M40,262 q26,-18 52,0 t52,0 t52,0 t52,0 L248,288 L40,288 Z\" data-r=\"nuoc\"/>"
  },
  {
    "id": "cay",
    "name": "Cái cây",
    "emoji": "🌳",
    "svg": "<path d=\"M140,292 L143,170 L157,170 L160,292 Z\" data-r=\"than\"/><circle cx=\"150\" cy=\"108\" r=\"55\" data-r=\"tan\"/><circle cx=\"103\" cy=\"140\" r=\"36\" data-r=\"tan\"/><circle cx=\"197\" cy=\"140\" r=\"36\" data-r=\"tan\"/><circle cx=\"128\" cy=\"102\" r=\"10\" data-r=\"qua\"/><circle cx=\"172\" cy=\"118\" r=\"10\" data-r=\"qua\"/><circle cx=\"150\" cy=\"140\" r=\"10\" data-r=\"qua\"/><path d=\"M70,292 L230,292 L230,280 Q150,268 70,280 Z\" data-r=\"dat\"/>"
  },
  {
    "id": "duahau",
    "name": "Quả dưa hấu",
    "emoji": "🍉",
    "svg": "<path d=\"M60,145 A95,95 0 0,0 240,145 Z\" data-r=\"ruot\"/><path d=\"M60,145 A95,95 0 0,0 240,145 L226,145 A81,81 0 0,1 74,145 Z\" data-r=\"vo\"/><ellipse cx=\"120\" cy=\"100\" rx=\"5\" ry=\"8\" data-r=\"hat\"/><ellipse cx=\"150\" cy=\"118\" rx=\"5\" ry=\"8\" data-r=\"hat\"/><ellipse cx=\"180\" cy=\"100\" rx=\"5\" ry=\"8\" data-r=\"hat\"/><ellipse cx=\"135\" cy=\"80\" rx=\"5\" ry=\"8\" data-r=\"hat\"/><ellipse cx=\"165\" cy=\"80\" rx=\"5\" ry=\"8\" data-r=\"hat\"/>"
  },
  {
    "id": "thuyenbuom",
    "name": "Thuyền buồm",
    "emoji": "⛵",
    "svg": "<path d=\"M60,205 L240,205 L208,248 L92,248 Z\" data-r=\"thuyen\"/><rect x=\"146\" y=\"95\" width=\"8\" height=\"112\" data-r=\"cot\"/><path d=\"M158,198 L158,108 L216,198 Z\" data-r=\"buomlon\"/><path d=\"M142,198 L142,120 L88,198 Z\" data-r=\"buomnho\"/><path d=\"M154,95 L184,103 L154,113 Z\" data-r=\"co\"/><path d=\"M28,264 q26,-20 52,0 t52,0 t52,0 t52,0 t52,0 L288,290 L28,290 Z\" data-r=\"song\"/>"
  },
  {
    "id": "saobien",
    "name": "Ngôi sao biển",
    "emoji": "⭐",
    "svg": "<path d=\"M150,58 L166,114 L224,114 L177,149 L193,206 L150,171 L107,206 L123,149 L76,114 L134,114 Z\" data-r=\"sao\"/><circle cx=\"150\" cy=\"92\" r=\"6\" data-r=\"cham\"/><circle cx=\"186\" cy=\"132\" r=\"6\" data-r=\"cham\"/><circle cx=\"170\" cy=\"180\" r=\"6\" data-r=\"cham\"/><circle cx=\"130\" cy=\"180\" r=\"6\" data-r=\"cham\"/><circle cx=\"114\" cy=\"132\" r=\"6\" data-r=\"cham\"/><path d=\"M50,266 L250,266 L250,282 L50,282 Z\" data-r=\"cat\"/>"
  },
  {
    "id": "cam",
    "name": "Quả cam",
    "emoji": "🍊",
    "svg": "<circle cx=\"150\" cy=\"160\" r=\"70\" data-r=\"cam\"/><path d=\"M150,90 L150,66 L160,66 L160,90 Z\" data-r=\"cuong\"/><path d=\"M162,70 Q190,58 206,70 Q190,88 162,70 Z\" data-r=\"la\"/>"
  },
  {
    "id": "buomdem",
    "name": "Con bướm đêm",
    "emoji": "🦋",
    "svg": "<ellipse cx=\"150\" cy=\"160\" rx=\"14\" ry=\"50\" data-r=\"than\"/><circle cx=\"150\" cy=\"104\" r=\"14\" data-r=\"dau\"/><path d=\"M136,130 Q80,80 60,130 Q85,185 136,168 Z\" data-r=\"canhtren\"/><path d=\"M164,130 Q220,80 240,130 Q215,185 164,168 Z\" data-r=\"canhtren\"/><path d=\"M136,175 Q90,190 95,230 Q130,235 140,200 Z\" data-r=\"canhduoi\"/><path d=\"M164,175 Q210,190 205,230 Q170,235 160,200 Z\" data-r=\"canhduoi\"/><circle cx=\"112\" cy=\"140\" r=\"10\" data-r=\"matgia\"/>"
  },
  {
    "id": "o",
    "name": "Cái ô",
    "emoji": "☂️",
    "svg": "<path d=\"M55,165 C70,95 110,60 150,60 C190,60 230,95 245,165 Q205,145 180,160 Q155,145 130,160 Q105,145 80,160 Q68,158 55,165 Z\" data-r=\"tan\"/><rect x=\"147\" y=\"60\" width=\"6\" height=\"105\" data-r=\"nan\"/><path d=\"M143,165 L143,238 Q143,258 126,258 Q110,258 110,244 L122,244 Q122,248 128,248 Q136,248 136,238 L136,165 Z\" data-r=\"can\"/><circle cx=\"150\" cy=\"52\" r=\"8\" data-r=\"dinh\"/>"
  },
  {
    "id": "bongbay",
    "name": "Quả bóng bay",
    "emoji": "🎈",
    "svg": "<ellipse cx=\"150\" cy=\"120\" rx=\"60\" ry=\"72\" data-r=\"bong\"/><path d=\"M142,192 L158,192 L150,208 Z\" data-r=\"nut\"/><path d=\"M150,208 Q130,240 150,270 Q170,240 150,208 Z\" data-r=\"day\"/>"
  },
  {
    "id": "ngua",
    "name": "Con ngựa",
    "emoji": "🐴",
    "svg": "<ellipse cx=\"140\" cy=\"175\" rx=\"62\" ry=\"42\" data-r=\"than\"/><path d=\"M190,150 Q205,110 195,80 Q215,85 220,110 Q225,140 205,158 Z\" data-r=\"dau\"/><path d=\"M195,80 Q175,95 170,125 L185,130 Q190,105 205,92 Z\" data-r=\"bom\"/><rect x=\"100\" y=\"205\" width=\"18\" height=\"60\" data-r=\"chan\"/><rect x=\"160\" y=\"205\" width=\"18\" height=\"60\" data-r=\"chan\"/><path d=\"M82,165 Q55,180 58,215 Q70,200 88,195 Z\" data-r=\"duoi\"/>"
  },
  {
    "id": "huongduong",
    "name": "Bông hoa hướng dương",
    "emoji": "🌻",
    "svg": "<circle cx=\"150\" cy=\"30\" r=\"20\" data-r=\"canh\"/><circle cx=\"200\" cy=\"60\" r=\"20\" data-r=\"canh\"/><circle cx=\"200\" cy=\"120\" r=\"20\" data-r=\"canh\"/><circle cx=\"150\" cy=\"150\" r=\"20\" data-r=\"canh\"/><circle cx=\"100\" cy=\"120\" r=\"20\" data-r=\"canh\"/><circle cx=\"100\" cy=\"60\" r=\"20\" data-r=\"canh\"/><circle cx=\"150\" cy=\"90\" r=\"45\" data-r=\"nhuy\"/><path d=\"M144,140 L144,290 L156,290 L156,140 Z\" data-r=\"than\"/><path d=\"M150,230 Q118,222 104,196 Q134,194 150,230 Z\" data-r=\"la\"/><path d=\"M150,230 Q182,222 196,196 Q166,194 150,230 Z\" data-r=\"la\"/>"
  },
  {
    "id": "banh",
    "name": "Cái bánh",
    "emoji": "🍰",
    "svg": "<ellipse cx=\"150\" cy=\"252\" rx=\"95\" ry=\"18\" data-r=\"dia\"/><rect x=\"85\" y=\"180\" width=\"130\" height=\"65\" rx=\"10\" data-r=\"tangduoi\"/><rect x=\"105\" y=\"125\" width=\"90\" height=\"55\" rx=\"10\" data-r=\"tangtren\"/><rect x=\"128\" y=\"88\" width=\"10\" height=\"40\" data-r=\"nen\"/><rect x=\"162\" y=\"88\" width=\"10\" height=\"40\" data-r=\"nen\"/><ellipse cx=\"133\" cy=\"78\" rx=\"7\" ry=\"11\" data-r=\"lua\"/><ellipse cx=\"167\" cy=\"78\" rx=\"7\" ry=\"11\" data-r=\"lua\"/>"
  },
  {
    "id": "ech",
    "name": "Con ếch",
    "emoji": "🐸",
    "svg": "<ellipse cx=\"150\" cy=\"170\" rx=\"65\" ry=\"50\" data-r=\"than\"/><circle cx=\"118\" cy=\"105\" r=\"28\" data-r=\"mat\"/><circle cx=\"182\" cy=\"105\" r=\"28\" data-r=\"mat\"/><circle cx=\"118\" cy=\"105\" r=\"10\" data-r=\"trongmat\"/><circle cx=\"182\" cy=\"105\" r=\"10\" data-r=\"trongmat\"/><ellipse cx=\"85\" cy=\"225\" rx=\"28\" ry=\"16\" data-r=\"chan\"/><ellipse cx=\"215\" cy=\"225\" rx=\"28\" ry=\"16\" data-r=\"chan\"/><ellipse cx=\"150\" cy=\"195\" rx=\"30\" ry=\"18\" data-r=\"bung\"/>"
  },
  {
    "id": "nonla",
    "name": "Cái nón lá",
    "emoji": "👒",
    "svg": "<path d=\"M60,200 L150,80 L240,200 Z\" data-r=\"non\"/><path d=\"M100,160 L200,160 L210,180 L90,180 Z\" data-r=\"van\"/><circle cx=\"150\" cy=\"80\" r=\"8\" data-r=\"dinh\"/><path d=\"M105,200 Q150,235 195,200 L195,214 Q150,249 105,214 Z\" data-r=\"quai\"/>"
  },
  {
    "id": "nho",
    "name": "Quả nho",
    "emoji": "🍇",
    "svg": "<circle cx=\"120\" cy=\"150\" r=\"18\" data-r=\"nho\"/><circle cx=\"150\" cy=\"150\" r=\"18\" data-r=\"nho\"/><circle cx=\"180\" cy=\"150\" r=\"18\" data-r=\"nho\"/><circle cx=\"135\" cy=\"180\" r=\"18\" data-r=\"nho\"/><circle cx=\"165\" cy=\"180\" r=\"18\" data-r=\"nho\"/><circle cx=\"120\" cy=\"210\" r=\"18\" data-r=\"nho\"/><circle cx=\"150\" cy=\"210\" r=\"18\" data-r=\"nho\"/><circle cx=\"180\" cy=\"210\" r=\"18\" data-r=\"nho\"/><circle cx=\"135\" cy=\"240\" r=\"18\" data-r=\"nho\"/><circle cx=\"165\" cy=\"240\" r=\"18\" data-r=\"nho\"/><path d=\"M150,132 L150,100 L162,100 L162,132 Z\" data-r=\"cuong\"/><path d=\"M164,104 Q194,92 210,104 Q194,124 164,104 Z\" data-r=\"la\"/>"
  },
  {
    "id": "tom",
    "name": "Con tôm",
    "emoji": "🦐",
    "svg": "<path d=\"M90,170 Q130,140 170,150 Q210,160 215,195 Q170,190 140,200 Q110,205 90,170 Z\" data-r=\"than\"/><path d=\"M90,170 Q70,160 58,168 Q70,180 88,182 Z\" data-r=\"duoi\"/><path d=\"M215,195 Q230,185 240,190 Q232,200 218,202 Z\" data-r=\"dau\"/><path d=\"M218,188 Q245,172 262,156 L258,150 Q240,168 214,182 Z\" data-r=\"rau\"/><ellipse cx=\"118\" cy=\"214\" rx=\"7\" ry=\"12\" data-r=\"chan\"/><ellipse cx=\"144\" cy=\"216\" rx=\"7\" ry=\"12\" data-r=\"chan\"/><ellipse cx=\"170\" cy=\"214\" rx=\"7\" ry=\"12\" data-r=\"chan\"/>"
  },
  {
    "id": "dan",
    "name": "Cái đàn",
    "emoji": "🎸",
    "svg": "<ellipse cx=\"130\" cy=\"195\" rx=\"55\" ry=\"48\" data-r=\"thung\"/><circle cx=\"130\" cy=\"195\" r=\"20\" data-r=\"lo\"/><path d=\"M172,150 L196,96 L212,104 L188,158 Z\" data-r=\"can\"/><circle cx=\"208\" cy=\"92\" r=\"14\" data-r=\"dau\"/>"
  },
  {
    "id": "ngoisao",
    "name": "Ngôi sao",
    "emoji": "⭐",
    "svg": "<path d=\"M150,55 L168,115 L230,115 L180,152 L198,214 L150,176 L102,214 L120,152 L70,115 L132,115 Z\" data-r=\"sao\"/><path d=\"M150,100 L158,128 L187,128 L164,145 L172,174 L150,156 L128,174 L136,145 L113,128 L142,128 Z\" data-r=\"sao2\"/><circle cx=\"80\" cy=\"240\" r=\"10\" data-r=\"sao3\"/><circle cx=\"220\" cy=\"240\" r=\"10\" data-r=\"sao3\"/>"
  },
  {
    "id": "keomut",
    "name": "Cái kẹo mút",
    "emoji": "🍭",
    "svg": "<circle cx=\"150\" cy=\"110\" r=\"60\" data-r=\"keo\"/><circle cx=\"150\" cy=\"110\" r=\"28\" data-r=\"nhan\"/><rect x=\"144\" y=\"168\" width=\"12\" height=\"110\" data-r=\"que\"/><path d=\"M144,220 L120,210 L124,232 Z\" data-r=\"no\"/><path d=\"M156,220 L180,210 L176,232 Z\" data-r=\"no\"/>"
  },
  {
    "id": "sua",
    "name": "Con sứa",
    "emoji": "🪼",
    "svg": "<path d=\"M80,150 C80,90 120,60 150,60 C180,60 220,90 220,150 L80,150 Z\" data-r=\"mu\"/><path d=\"M100,150 Q95,190 105,225 Q115,190 110,150 Z\" data-r=\"xuc\"/><path d=\"M135,150 Q130,195 140,235 Q150,195 145,150 Z\" data-r=\"xuc\"/><path d=\"M170,150 Q165,195 175,235 Q185,195 180,150 Z\" data-r=\"xuc\"/><path d=\"M200,150 Q195,190 205,225 Q215,190 210,150 Z\" data-r=\"xuc\"/><circle cx=\"130\" cy=\"115\" r=\"7\" data-r=\"mat\"/><circle cx=\"170\" cy=\"115\" r=\"7\" data-r=\"mat\"/>"
  },
  {
    "id": "leu",
    "name": "Cái lều",
    "emoji": "⛺",
    "svg": "<path d=\"M50,220 L150,90 L250,220 Z\" data-r=\"leu\"/><path d=\"M125,220 L150,160 L175,220 Z\" data-r=\"cua\"/><path d=\"M146,90 L146,60 L154,60 L154,90 Z\" data-r=\"cot\"/><path d=\"M154,60 L182,68 L154,78 Z\" data-r=\"co\"/><path d=\"M40,220 L260,220 L260,238 L40,238 Z\" data-r=\"dat\"/>"
  }
]);
ART_QUIZ = ART_QUIZ.concat([
  {
    "id": "art_q13",
    "audio": "art_q13",
    "q": "Cỏ cây có màu gì?",
    "choices": [
      "Xanh lá",
      "Màu đỏ",
      "Màu tím"
    ],
    "answer": 0
  },
  {
    "id": "art_q14",
    "audio": "art_q14",
    "q": "Quả nho chín có màu gì?",
    "choices": [
      "Màu đỏ",
      "Màu tím",
      "Màu vàng"
    ],
    "answer": 1
  },
  {
    "id": "art_q15",
    "audio": "art_q15",
    "q": "Bé pha màu đỏ với màu trắng thì được màu gì?",
    "choices": [
      "Màu hồng",
      "Màu nâu",
      "Màu xanh lá"
    ],
    "answer": 0
  },
  {
    "id": "art_q16",
    "audio": "art_q16",
    "q": "Bút chì màu giúp bé vẽ gì?",
    "choices": [
      "Vẽ tranh",
      "Nấu cơm",
      "Đá bóng"
    ],
    "answer": 0
  },
  {
    "id": "art_q17",
    "audio": "art_q17",
    "q": "Vỏ quả dưa hấu có màu gì?",
    "choices": [
      "Màu xanh lá",
      "Màu cam",
      "Màu hồng"
    ],
    "answer": 0
  },
  {
    "id": "art_q18",
    "audio": "art_q18",
    "q": "Bé tô bầu trời ban ngày bằng màu gì?",
    "choices": [
      "Màu xanh dương",
      "Màu nâu",
      "Màu đen"
    ],
    "answer": 0
  },
  {
    "id": "art_q19",
    "audio": "art_q19",
    "q": "Quả cam có màu gì?",
    "choices": [
      "Màu vàng",
      "Màu cam",
      "Màu đỏ"
    ],
    "answer": 1
  },
  {
    "id": "art_q20",
    "audio": "art_q20",
    "q": "Khi vẽ ông mặt trời, bé dùng màu gì?",
    "choices": [
      "Màu vàng",
      "Màu tím",
      "Màu xanh dương"
    ],
    "answer": 0
  },
  {
    "id": "art_q21",
    "audio": "art_q21",
    "q": "Tuyết có màu gì?",
    "choices": [
      "Màu trắng",
      "Màu đen",
      "Màu nâu"
    ],
    "answer": 0
  },
  {
    "id": "art_q22",
    "audio": "art_q22",
    "q": "Bé pha màu vàng với màu đỏ thì được màu gì?",
    "choices": [
      "Màu tím",
      "Màu cam",
      "Màu hồng"
    ],
    "answer": 1
  },
  {
    "id": "art_q23",
    "audio": "art_q23",
    "q": "Lá cờ đỏ sao vàng có hai màu gì?",
    "choices": [
      "Đỏ và vàng",
      "Xanh và trắng",
      "Tím và hồng"
    ],
    "answer": 0
  },
  {
    "id": "art_q24",
    "audio": "art_q24",
    "q": "Quả chuối chín có màu gì?",
    "choices": [
      "Màu vàng",
      "Màu xanh dương",
      "Màu tím"
    ],
    "answer": 0
  },
  {
    "id": "art_q25",
    "audio": "art_q25",
    "q": "Bé vẽ con cá đang bơi ở đâu?",
    "choices": [
      "Dưới nước",
      "Trên trời",
      "Trong rừng"
    ],
    "answer": 0
  },
  {
    "id": "art_q26",
    "audio": "art_q26",
    "q": "Đất có màu gì?",
    "choices": [
      "Màu nâu",
      "Màu trắng",
      "Màu xanh dương"
    ],
    "answer": 0
  },
  {
    "id": "art_q27",
    "audio": "art_q27",
    "q": "Sau cơn mưa có nắng, trên trời hiện ra gì?",
    "choices": [
      "Cầu vồng",
      "Đám mây đen",
      "Ông trăng"
    ],
    "answer": 0
  },
  {
    "id": "art_q28",
    "audio": "art_q28",
    "q": "Bé pha màu xanh dương với màu trắng thì được màu gì?",
    "choices": [
      "Màu xanh da trời",
      "Màu tím than",
      "Màu nâu"
    ],
    "answer": 0
  },
  {
    "id": "art_q29",
    "audio": "art_q29",
    "q": "Lông con vẹt thường có màu gì?",
    "choices": [
      "Xanh lá cây",
      "Trắng tinh",
      "Đen nhánh"
    ],
    "answer": 0
  },
  {
    "id": "art_q30",
    "audio": "art_q30",
    "q": "Bé dùng cọ vẽ để làm gì?",
    "choices": [
      "Quét màu lên giấy",
      "Cắt giấy",
      "Dán tranh"
    ],
    "answer": 0
  },
  {
    "id": "art_q31",
    "audio": "art_q31",
    "q": "Quả táo xanh có màu gì?",
    "choices": [
      "Màu xanh lá",
      "Màu đỏ",
      "Màu vàng"
    ],
    "answer": 0
  },
  {
    "id": "art_q32",
    "audio": "art_q32",
    "q": "Bé pha màu tím với màu trắng thì được màu gì?",
    "choices": [
      "Màu hồng phấn",
      "Màu cam",
      "Màu đen"
    ],
    "answer": 0
  },
  {
    "id": "art_q33",
    "audio": "art_q33",
    "q": "Màu xám là do pha hai màu nào với nhau?",
    "choices": [
      "Đen và trắng",
      "Đỏ và vàng",
      "Xanh và đỏ"
    ],
    "answer": 0
  },
  {
    "id": "art_q34",
    "audio": "art_q34",
    "q": "Quả dâu tây chín có màu gì?",
    "choices": [
      "Màu đỏ",
      "Màu xanh lá",
      "Màu vàng"
    ],
    "answer": 0
  },
  {
    "id": "art_q35",
    "audio": "art_q35",
    "q": "Bé vẽ tranh thật đẹp để tặng ai?",
    "choices": [
      "Tặng ông bà",
      "Giữ một mình",
      "Xé bỏ đi"
    ],
    "answer": 0
  },
  {
    "id": "art_q36",
    "audio": "art_q36",
    "q": "Khi tô màu, bé nên tô như thế nào?",
    "choices": [
      "Cẩn thận, gọn gàng",
      "Thật nhanh, ẩu",
      "Tô ra ngoài"
    ],
    "answer": 0
  }
]);
COLORS = COLORS.concat([
  {
    "id": "xanhdatroi",
    "name": "Xanh da trời",
    "hex": "#29B6F6",
    "audio": "col_xanhdatroi"
  },
  {
    "id": "xanhreu",
    "name": "Xanh rêu",
    "hex": "#7CB342",
    "audio": "col_xanhreu"
  },
  {
    "id": "vangchanh",
    "name": "Vàng chanh",
    "hex": "#EEFF41",
    "audio": "col_vangchanh"
  },
  {
    "id": "hongphan",
    "name": "Hồng phấn",
    "hex": "#F8BBD0",
    "audio": "col_hongphan"
  },
  {
    "id": "timthan",
    "name": "Tím than",
    "hex": "#303F9F",
    "audio": "col_timthan"
  },
  {
    "id": "camdat",
    "name": "Cam đất",
    "hex": "#A65A1E",
    "audio": "col_camdat"
  },
  {
    "id": "maube",
    "name": "Màu be",
    "hex": "#F5E6C4",
    "audio": "col_maube"
  },
  {
    "id": "cham",
    "name": "Chàm",
    "hex": "#1A237E",
    "audio": "col_cham"
  }
]);
SHAPES = SHAPES.concat([
  {
    "id": "hinhthang",
    "name": "Hình thang",
    "ex": "Mái nhà, cái thang nằm",
    "audio": "shp_hinhthang",
    "svg": "<path d=\"M20,78 L34,22 L66,22 L80,78 Z\"/>"
  },
  {
    "id": "ngugiac",
    "name": "Hình ngũ giác",
    "ex": "Tổ ong năm cạnh, ngôi nhà",
    "audio": "shp_ngugiac",
    "svg": "<path d=\"M50,12 L93,42 L77,88 L23,88 L7,42 Z\"/>"
  },
  {
    "id": "lucgiac",
    "name": "Hình lục giác",
    "ex": "Tổ ong, đai ốc",
    "audio": "shp_lucgiac",
    "svg": "<path d=\"M50,10 L85,30 L85,70 L50,90 L15,70 L15,30 Z\"/>"
  },
  {
    "id": "elip",
    "name": "Hình bầu dục",
    "ex": "Quả trứng, cái gương bầu dục",
    "audio": "shp_elip",
    "svg": "<ellipse cx=\"50\" cy=\"50\" rx=\"38\" ry=\"26\"/>"
  }
]);
MIX_COMBOS = MIX_COMBOS.concat([
  {
    "a": "do",
    "b": "trang",
    "r": "hongphan",
    "audio": "mix_dotrang",
    "sAudio": "mixs_dotrang"
  },
  {
    "a": "xanhduong",
    "b": "trang",
    "r": "xanhdatroi",
    "audio": "mix_xanhdutrang",
    "sAudio": "mixs_xanhdutrang"
  },
  {
    "a": "vang",
    "b": "hong",
    "r": "camdat",
    "audio": "mix_vanghong",
    "sAudio": "mixs_vanghong"
  },
  {
    "a": "tim",
    "b": "trang",
    "r": "hongphan",
    "audio": "mix_timtrang",
    "sAudio": "mixs_timtrang"
  },
  {
    "a": "xanhla",
    "b": "trang",
    "r": "xanhreu",
    "audio": "mix_xanhlatrang",
    "sAudio": "mixs_xanhlatrang"
  },
  {
    "a": "vang",
    "b": "trang",
    "r": "vangchanh",
    "audio": "mix_vangtrang",
    "sAudio": "mixs_vangtrang"
  }
]);

// 76 key audio mới -> nối vào map UI_AUDIO
UI_AUDIO_KEYS = UI_AUDIO_KEYS.concat([
  "step_cua",
  "step_ong",
  "step_tulip",
  "step_thong",
  "step_chuoi",
  "step_keo",
  "step_rua",
  "step_ga",
  "step_dieu",
  "step_bong",
  "step_tuyet",
  "step_mu",
  "step_sau",
  "step_dua",
  "step_thuyenbuom",
  "step_mattroimu",
  "chu_i",
  "chu_j",
  "chu_k",
  "chu_l",
  "chu_m",
  "chu_n",
  "chu_o",
  "chu_p",
  "chu_q",
  "chu_r",
  "chu_s",
  "chu_t",
  "chu_u",
  "chu_v",
  "chu_w",
  "chu_x",
  "chu_y",
  "chu_z",
  "col_xanhdatroi",
  "col_xanhreu",
  "col_vangchanh",
  "col_hongphan",
  "col_timthan",
  "col_camdat",
  "col_maube",
  "col_cham",
  "shp_hinhthang",
  "shp_ngugiac",
  "shp_lucgiac",
  "shp_elip",
  "mix_dotrang",
  "mix_xanhdutrang",
  "mix_vanghong",
  "mix_timtrang",
  "mix_xanhlatrang",
  "mix_vangtrang",
  "mixs_dovang", "mixs_xanhvang", "mixs_doxanh", "mixs_dentrang", "mixs_dotrang",
  "mixs_xanhdutrang", "mixs_vanghong", "mixs_timtrang", "mixs_xanhlatrang", "mixs_vangtrang",
  "art_q13",
  "art_q14",
  "art_q15",
  "art_q16",
  "art_q17",
  "art_q18",
  "art_q19",
  "art_q20",
  "art_q21",
  "art_q22",
  "art_q23",
  "art_q24",
  "art_q25",
  "art_q26",
  "art_q27",
  "art_q28",
  "art_q29",
  "art_q30",
  "art_q31",
  "art_q32",
  "art_q33",
  "art_q34",
  "art_q35",
  "art_q36"
]);
(function () {
  for (var i = 0; i < UI_AUDIO_KEYS.length; i++) {
    if (!UI_AUDIO[UI_AUDIO_KEYS[i]]) UI_AUDIO[UI_AUDIO_KEYS[i]] = "audio/" + UI_AUDIO_KEYS[i] + ".mp3";
  }
})();

// ============================================================
// BẢN CẬP NHẬT v1.3b: +12 bài học vẽ từng bước (32 -> 44)
// ============================================================
STEP_LESSONS = STEP_LESSONS.concat([
  {
    "id": "ngua",
    "name": "Con ngựa",
    "emoji": "🐴",
    "audio": "s13_ngua",
    "steps": [
      { "t": "Bước 1: Vẽ mình ngựa thon dài", "svg": "<ellipse cx=\"150\" cy=\"175\" rx=\"68\" ry=\"44\"/>" },
      { "t": "Bước 2: Vẽ cổ và đầu ngựa", "svg": "<path d=\"M196,158 Q206,118 198,88\"/><ellipse cx=\"204\" cy=\"68\" rx=\"22\" ry=\"28\"/>" },
      { "t": "Bước 3: Vẽ bờm và hai tai nhọn", "svg": "<path d=\"M190,84 Q172,98 168,128 L184,132 Q188,104 200,94 Z\"/><path d=\"M186,48 L180,26 L196,40 Z M214,44 L222,24 L228,46 Z\"/>" },
      { "t": "Bước 4: Vẽ bốn cái chân dài", "svg": "<path d=\"M108,214 L108,266 M126,214 L126,266 M174,214 L174,266 M192,214 L192,266\"/>" },
      { "t": "Bước 5: Vẽ đuôi và mắt cười", "svg": "<path d=\"M84,162 Q58,176 62,212\"/><circle cx=\"210\" cy=\"62\" r=\"5\"/><path d=\"M196,74 Q200,78 206,76\"/>" }
    ]
  },
  {
    "id": "ech",
    "name": "Con ếch",
    "emoji": "🐸",
    "audio": "s13_ech",
    "steps": [
      { "t": "Bước 1: Vẽ mình ếch tròn xoe", "svg": "<ellipse cx=\"150\" cy=\"188\" rx=\"62\" ry=\"50\"/>" },
      { "t": "Bước 2: Vẽ hai mắt lồi to", "svg": "<circle cx=\"118\" cy=\"142\" r=\"19\"/><circle cx=\"182\" cy=\"142\" r=\"19\"/>" },
      { "t": "Bước 3: Vẽ con ngươi và miệng cười", "svg": "<circle cx=\"118\" cy=\"144\" r=\"7\"/><circle cx=\"182\" cy=\"144\" r=\"7\"/><path d=\"M116,202 Q150,218 184,202\"/>" },
      { "t": "Bước 4: Vẽ bốn cái chân ngắn", "svg": "<path d=\"M102,224 L78,252 M122,230 L112,260 M178,230 L188,260 M198,224 L222,252\"/>" },
      { "t": "Bước 5: Vẽ lá sen dưới chân ếch", "svg": "<path d=\"M84,276 Q150,254 216,276 Q150,288 84,276 Z\"/>" }
    ]
  },
  {
    "id": "o",
    "name": "Cái ô",
    "emoji": "☂️",
    "audio": "s13_o",
    "steps": [
      { "t": "Bước 1: Vẽ tán ô cong cong", "svg": "<path d=\"M58,168 C72,96 110,62 150,62 C190,62 228,96 242,168 Q212,150 186,164 Q160,148 134,164 Q108,148 82,164 Q70,161 58,168 Z\"/>" },
      { "t": "Bước 2: Vẽ nan ô ở giữa", "svg": "<path d=\"M150,62 L150,168\"/>" },
      { "t": "Bước 3: Vẽ cán ô cong", "svg": "<path d=\"M146,168 L146,240 Q146,260 128,260 Q112,260 112,246\"/>" },
      { "t": "Bước 4: Vẽ đỉnh nhọn trên tán ô", "svg": "<path d=\"M142,64 L150,44 L158,64 Z\"/>" }
    ]
  },
  {
    "id": "cam",
    "name": "Quả cam",
    "emoji": "🍊",
    "audio": "s13_cam",
    "steps": [
      { "t": "Bước 1: Vẽ quả cam tròn căng", "svg": "<circle cx=\"150\" cy=\"168\" r=\"68\"/>" },
      { "t": "Bước 2: Vẽ cuống cam nhỏ", "svg": "<path d=\"M150,100 L150,74\"/>" },
      { "t": "Bước 3: Vẽ chiếc lá xanh", "svg": "<path d=\"M154,76 Q184,62 202,74 Q184,92 154,76 Z\"/>" },
      { "t": "Bước 4: Vẽ chấm nhỏ trên vỏ cam", "svg": "<circle cx=\"120\" cy=\"152\" r=\"3\"/><circle cx=\"182\" cy=\"172\" r=\"3\"/><circle cx=\"148\" cy=\"204\" r=\"3\"/>" }
    ]
  },
  {
    "id": "banh",
    "name": "Cái bánh",
    "emoji": "🍰",
    "audio": "s13_banh",
    "steps": [
      { "t": "Bước 1: Vẽ thân bánh hình thang", "svg": "<path d=\"M104,190 L196,190 L182,262 L118,262 Z\"/>" },
      { "t": "Bước 2: Vẽ lớp kem bồng bềnh", "svg": "<path d=\"M94,190 Q98,150 124,150 Q130,120 156,126 Q186,118 190,150 Q216,150 206,190 Z\"/>" },
      { "t": "Bước 3: Vẽ quả dâu trên kem", "svg": "<circle cx=\"156\" cy=\"102\" r=\"14\"/>" },
      { "t": "Bước 4: Vẽ sọc giấy gói bánh", "svg": "<path d=\"M122,200 L126,252 M150,200 L150,252 M178,200 L174,252\"/>" },
      { "t": "Bước 5: Vẽ cây nến sinh nhật", "svg": "<rect x=\"150\" y=\"58\" width=\"9\" height=\"34\"/><path d=\"M154,58 Q146,46 154,34 Q162,46 154,58 Z\"/>" }
    ]
  },
  {
    "id": "sen",
    "name": "Con sên",
    "emoji": "🐌",
    "audio": "s13_sen",
    "steps": [
      { "t": "Bước 1: Vẽ cái vỏ xoắn ốc", "svg": "<circle cx=\"148\" cy=\"148\" r=\"56\"/><path d=\"M148,148 m-36,0 a36,36 0 1,0 72,0 a27,27 0 1,1 -54,0 a17,17 0 1,0 34,0\"/>" },
      { "t": "Bước 2: Vẽ mình sên dài", "svg": "<path d=\"M98,196 Q150,216 214,200 Q230,216 214,228 Q150,242 94,226 Z\"/>" },
      { "t": "Bước 3: Vẽ đầu và hai cái râu", "svg": "<circle cx=\"222\" cy=\"194\" r=\"17\"/><path d=\"M214,180 L204,148 M230,180 L240,148\"/>" },
      { "t": "Bước 4: Vẽ mắt tròn trên râu", "svg": "<circle cx=\"202\" cy=\"144\" r=\"7\"/><circle cx=\"242\" cy=\"144\" r=\"7\"/>" },
      { "t": "Bước 5: Vẽ vệt đường sên bò", "svg": "<path d=\"M52,236 Q120,246 190,238\"/>" }
    ]
  },
  {
    "id": "hoacuc",
    "name": "Bông hoa cúc",
    "emoji": "🌼",
    "audio": "s13_hoacuc",
    "steps": [
      { "t": "Bước 1: Vẽ thân hoa cong cong", "svg": "<path d=\"M150,286 Q140,230 150,182\"/>" },
      { "t": "Bước 2: Vẽ nhụy hoa tròn", "svg": "<circle cx=\"150\" cy=\"118\" r=\"22\"/>" },
      { "t": "Bước 3: Vẽ cánh hoa dài xung quanh", "svg": "<ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(45 150 118)\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(90 150 118)\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(135 150 118)\"/>" },
      { "t": "Bước 4: Vẽ hai chiếc lá", "svg": "<path d=\"M148,236 Q116,228 100,200 Q132,198 148,236 Z M152,236 Q184,228 200,200 Q168,198 152,236 Z\"/>" },
      { "t": "Bước 5: Vẽ chấm nhỏ trên nhụy hoa", "svg": "<circle cx=\"142\" cy=\"114\" r=\"3\"/><circle cx=\"158\" cy=\"114\" r=\"3\"/><circle cx=\"150\" cy=\"126\" r=\"3\"/>" }
    ]
  },
  {
    "id": "xedap",
    "name": "Cái xe đạp",
    "emoji": "🚲",
    "audio": "s13_xedap",
    "steps": [
      { "t": "Bước 1: Vẽ hai bánh xe tròn", "svg": "<circle cx=\"95\" cy=\"215\" r=\"42\"/><circle cx=\"205\" cy=\"215\" r=\"42\"/>" },
      { "t": "Bước 2: Vẽ khung xe chắc chắn", "svg": "<path d=\"M95,215 L145,145 L205,215 M145,145 L118,215\"/>" },
      { "t": "Bước 3: Vẽ ghi đông và yên xe", "svg": "<path d=\"M145,145 L145,116 L168,116\"/><path d=\"M118,106 L142,106\"/>" },
      { "t": "Bước 4: Vẽ bàn đạp xinh", "svg": "<circle cx=\"132\" cy=\"215\" r=\"10\"/><path d=\"M132,215 L118,234 M132,215 L146,196\"/>" }
    ]
  },
  {
    "id": "lon",
    "name": "Con lợn",
    "emoji": "🐷",
    "audio": "s13_lon",
    "steps": [
      { "t": "Bước 1: Vẽ mình lợn tròn mũm mĩm", "svg": "<ellipse cx=\"150\" cy=\"178\" rx=\"68\" ry=\"52\"/>" },
      { "t": "Bước 2: Vẽ đầu lợn tròn", "svg": "<circle cx=\"150\" cy=\"108\" r=\"38\"/>" },
      { "t": "Bước 3: Vẽ tai và mõm lợn", "svg": "<path d=\"M120,80 L110,52 L136,68 Z M180,80 L190,52 L164,68 Z\"/><ellipse cx=\"150\" cy=\"120\" rx=\"16\" ry=\"12\"/>" },
      { "t": "Bước 4: Vẽ mắt và lỗ mũi", "svg": "<circle cx=\"132\" cy=\"102\" r=\"5\"/><circle cx=\"168\" cy=\"102\" r=\"5\"/><circle cx=\"144\" cy=\"120\" r=\"2.5\"/><circle cx=\"156\" cy=\"120\" r=\"2.5\"/>" },
      { "t": "Bước 5: Vẽ chân và đuôi xoắn", "svg": "<path d=\"M100,224 L100,260 M120,224 L120,260 M180,224 L180,260 M200,224 L200,260 M214,172 Q244,170 240,194 Q237,212 224,206\"/>" }
    ]
  },
  {
    "id": "leu",
    "name": "Cái lều",
    "emoji": "⛺",
    "audio": "s13_leu",
    "steps": [
      { "t": "Bước 1: Vẽ khung lều tam giác", "svg": "<path d=\"M60,250 L150,80 L240,250 Z\"/>" },
      { "t": "Bước 2: Vẽ cửa lều", "svg": "<path d=\"M120,250 L150,160 L180,250 Z\"/>" },
      { "t": "Bước 3: Vẽ dây neo hai bên", "svg": "<path d=\"M60,250 L38,274 M240,250 L262,274\"/>" },
      { "t": "Bước 4: Vẽ lá cờ trên đỉnh lều", "svg": "<path d=\"M150,80 L150,50\"/><path d=\"M150,50 L178,58 L150,66 Z\"/>" }
    ]
  },
  {
    "id": "le",
    "name": "Quả lê",
    "emoji": "🍐",
    "audio": "s13_le",
    "steps": [
      { "t": "Bước 1: Vẽ quả lê bầu bĩnh", "svg": "<path d=\"M150,95 C120,105 105,140 100,180 C95,225 120,256 150,256 C180,256 205,225 200,180 C195,140 180,105 150,95 Z\"/>" },
      { "t": "Bước 2: Vẽ cuống lê", "svg": "<path d=\"M150,95 Q150,75 158,65\"/>" },
      { "t": "Bước 3: Vẽ chiếc lá", "svg": "<path d=\"M160,70 Q188,58 204,70 Q188,88 160,70 Z\"/>" },
      { "t": "Bước 4: Vẽ vệt sáng bóng", "svg": "<path d=\"M122,172 Q128,200 145,212\"/>" }
    ]
  },
  {
    "id": "he",
    "name": "Chú hề",
    "emoji": "🤡",
    "audio": "s13_he",
    "steps": [
      { "t": "Bước 1: Vẽ mặt hề tròn xoe", "svg": "<circle cx=\"150\" cy=\"152\" r=\"56\"/>" },
      { "t": "Bước 2: Vẽ tóc xù hai bên", "svg": "<circle cx=\"94\" cy=\"152\" r=\"21\"/><circle cx=\"206\" cy=\"152\" r=\"21\"/>" },
      { "t": "Bước 3: Vẽ mắt và mũi đỏ", "svg": "<circle cx=\"130\" cy=\"142\" r=\"8\"/><circle cx=\"170\" cy=\"142\" r=\"8\"/><circle cx=\"150\" cy=\"164\" r=\"12\"/>" },
      { "t": "Bước 4: Vẽ miệng cười thật tươi", "svg": "<path d=\"M114,198 Q150,228 186,198\"/>" },
      { "t": "Bước 5: Vẽ mũ hề và quả bông", "svg": "<path d=\"M108,110 L150,40 L192,110 Z\"/><circle cx=\"150\" cy=\"36\" r=\"10\"/>" }
    ]
  }
]);

// ============================================================
// BẢN CẬP NHẬT v1.3b: +12 tranh tô màu (38 -> 50)
// ============================================================
COLORING_PAGES = COLORING_PAGES.concat([
  {
    "id": "banhmi",
    "name": "Cái bánh mì",
    "emoji": "🥖",
    "audio": "c13_banhmi",
    "svg": "<path d=\"M40,165 Q150,105 260,165 Q150,225 40,165 Z\" data-r=\"than\"/><path d=\"M110,148 L132,180\" data-r=\"vet\"/><path d=\"M148,140 L170,172\" data-r=\"vet\"/><path d=\"M186,148 L208,180\" data-r=\"vet\"/>"
  },
  {
    "id": "sen",
    "name": "Con sên",
    "emoji": "🐌",
    "audio": "c13_sen",
    "svg": "<circle cx=\"140\" cy=\"150\" r=\"58\" data-r=\"vo\"/><circle cx=\"140\" cy=\"150\" r=\"30\" data-r=\"xoan\"/><path d=\"M86,200 Q150,220 218,202 Q232,218 214,230 Q150,244 82,230 Z\" data-r=\"than\"/><circle cx=\"224\" cy=\"196\" r=\"17\" data-r=\"dau\"/><circle cx=\"216\" cy=\"180\" r=\"6\" data-r=\"mat\"/><circle cx=\"232\" cy=\"180\" r=\"6\" data-r=\"mat\"/>"
  },
  {
    "id": "xedap",
    "name": "Cái xe đạp",
    "emoji": "🚲",
    "audio": "c13_xedap",
    "svg": "<circle cx=\"95\" cy=\"215\" r=\"42\" data-r=\"banh1\"/><circle cx=\"205\" cy=\"215\" r=\"42\" data-r=\"banh2\"/><path d=\"M95,215 L145,145 L205,215 M145,145 L118,215\" data-r=\"khung\"/><rect x=\"108\" y=\"98\" width=\"38\" height=\"12\" rx=\"6\" data-r=\"yen\"/><path d=\"M145,145 L145,116 L168,116\" data-r=\"gidong\"/>"
  },
  {
    "id": "he",
    "name": "Chú hề",
    "emoji": "🤡",
    "audio": "c13_he",
    "svg": "<circle cx=\"150\" cy=\"152\" r=\"56\" data-r=\"mat\"/><circle cx=\"94\" cy=\"152\" r=\"21\" data-r=\"toc\"/><circle cx=\"206\" cy=\"152\" r=\"21\" data-r=\"toc\"/><circle cx=\"150\" cy=\"164\" r=\"12\" data-r=\"mui\"/><path d=\"M114,198 Q150,228 186,198 Q150,214 114,198 Z\" data-r=\"mieng\"/><path d=\"M108,110 L150,40 L192,110 Z\" data-r=\"mu\"/><circle cx=\"150\" cy=\"36\" r=\"10\" data-r=\"bong\"/>"
  },
  {
    "id": "lon",
    "name": "Con lợn",
    "emoji": "🐷",
    "audio": "c13_lon",
    "svg": "<ellipse cx=\"150\" cy=\"178\" rx=\"68\" ry=\"52\" data-r=\"than\"/><circle cx=\"150\" cy=\"108\" r=\"38\" data-r=\"dau\"/><ellipse cx=\"150\" cy=\"120\" rx=\"16\" ry=\"12\" data-r=\"mom\"/><path d=\"M120,80 L110,52 L136,68 Z\" data-r=\"tai\"/><path d=\"M180,80 L190,52 L164,68 Z\" data-r=\"tai\"/><path d=\"M214,172 Q244,170 240,194 Q237,212 224,206\" data-r=\"duoi\"/>"
  },
  {
    "id": "hoacuc",
    "name": "Bông hoa cúc",
    "emoji": "🌼",
    "audio": "c13_hoacuc",
    "svg": "<ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" data-r=\"canh\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(45 150 118)\" data-r=\"canh\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(90 150 118)\" data-r=\"canh\"/><ellipse cx=\"150\" cy=\"64\" rx=\"14\" ry=\"32\" transform=\"rotate(135 150 118)\" data-r=\"canh\"/><circle cx=\"150\" cy=\"118\" r=\"22\" data-r=\"nhuy\"/><path d=\"M150,286 Q140,230 150,182\" data-r=\"than\"/><path d=\"M148,236 Q116,228 100,200 Q132,198 148,236 Z\" data-r=\"la\"/><path d=\"M152,236 Q184,228 200,200 Q168,198 152,236 Z\" data-r=\"la\"/>"
  },
  {
    "id": "le",
    "name": "Quả lê",
    "emoji": "🍐",
    "audio": "c13_le",
    "svg": "<path d=\"M150,95 C120,105 105,140 100,180 C95,225 120,256 150,256 C180,256 205,225 200,180 C195,140 180,105 150,95 Z\" data-r=\"le\"/><path d=\"M150,95 Q150,75 158,65\" data-r=\"cuong\"/><path d=\"M160,70 Q188,58 204,70 Q188,88 160,70 Z\" data-r=\"la\"/>"
  },
  {
    "id": "nam",
    "name": "Cây nấm",
    "emoji": "🍄",
    "audio": "c13_nam",
    "svg": "<path d=\"M70,150 Q150,60 230,150 Q150,170 70,150 Z\" data-r=\"mu\"/><path d=\"M130,165 L125,240 Q150,250 175,240 L170,165 Z\" data-r=\"than\"/><circle cx=\"120\" cy=\"118\" r=\"9\" data-r=\"cham\"/><circle cx=\"160\" cy=\"104\" r=\"9\" data-r=\"cham\"/><circle cx=\"192\" cy=\"126\" r=\"9\" data-r=\"cham\"/>"
  },
  {
    "id": "tachtra",
    "name": "Tách trà",
    "emoji": "🍵",
    "audio": "c13_tachtra",
    "svg": "<path d=\"M90,150 L210,150 L195,235 Q150,248 105,235 Z\" data-r=\"than\"/><path d=\"M210,160 Q250,165 242,208 Q235,235 202,226 L208,214 Q228,220 230,205 Q234,178 210,176 Z\" data-r=\"quai\"/><ellipse cx=\"150\" cy=\"150\" rx=\"60\" ry=\"14\" data-r=\"tra\"/><ellipse cx=\"150\" cy=\"262\" rx=\"70\" ry=\"12\" data-r=\"dia\"/>"
  },
  {
    "id": "gaubong",
    "name": "Con gấu bông",
    "emoji": "🧸",
    "audio": "c13_gaubong",
    "svg": "<circle cx=\"150\" cy=\"115\" r=\"45\" data-r=\"dau\"/><circle cx=\"112\" cy=\"80\" r=\"16\" data-r=\"tai\"/><circle cx=\"188\" cy=\"80\" r=\"16\" data-r=\"tai\"/><ellipse cx=\"150\" cy=\"215\" rx=\"55\" ry=\"55\" data-r=\"than\"/><ellipse cx=\"92\" cy=\"200\" rx=\"18\" ry=\"30\" data-r=\"tay\"/><ellipse cx=\"208\" cy=\"200\" rx=\"18\" ry=\"30\" data-r=\"tay\"/><ellipse cx=\"120\" cy=\"270\" rx=\"20\" ry=\"18\" data-r=\"chan\"/><ellipse cx=\"180\" cy=\"270\" rx=\"20\" ry=\"18\" data-r=\"chan\"/>"
  },
  {
    "id": "maybay",
    "name": "Máy bay",
    "emoji": "✈️",
    "audio": "c13_maybay",
    "svg": "<path d=\"M60,170 Q150,140 245,165 Q150,195 60,170 Z\" data-r=\"than\"/><path d=\"M140,165 L110,230 L170,175 Z\" data-r=\"canh\"/><path d=\"M225,160 L250,120 L258,158 Z\" data-r=\"duoi\"/><ellipse cx=\"195\" cy=\"158\" rx=\"18\" ry=\"10\" data-r=\"kinh\"/>"
  },
  {
    "id": "banghe",
    "name": "Bộ bàn ghế",
    "emoji": "🪑",
    "audio": "c13_banghe",
    "svg": "<rect x=\"70\" y=\"120\" width=\"160\" height=\"16\" rx=\"8\" data-r=\"matban\"/><rect x=\"85\" y=\"136\" width=\"12\" height=\"90\" data-r=\"chanban\"/><rect x=\"203\" y=\"136\" width=\"12\" height=\"90\" data-r=\"chanban\"/><rect x=\"60\" y=\"200\" width=\"70\" height=\"14\" rx=\"7\" data-r=\"matghe\"/><rect x=\"60\" y=\"140\" width=\"14\" height=\"70\" rx=\"7\" data-r=\"lungghe\"/><rect x=\"64\" y=\"214\" width=\"10\" height=\"60\" data-r=\"changhe\"/><rect x=\"116\" y=\"214\" width=\"10\" height=\"60\" data-r=\"changhe\"/>"
  }
]);

// 27 key audio mới (12 bài vẽ + 12 tranh tô + 3 tính năng) -> nối vào map UI_AUDIO
UI_AUDIO_KEYS = UI_AUDIO_KEYS.concat([
  "s13_ngua",
  "s13_ech",
  "s13_o",
  "s13_cam",
  "s13_banh",
  "s13_sen",
  "s13_hoacuc",
  "s13_xedap",
  "s13_lon",
  "s13_leu",
  "s13_le",
  "s13_he",
  "c13_banhmi",
  "c13_sen",
  "c13_xedap",
  "c13_he",
  "c13_lon",
  "c13_hoacuc",
  "c13_le",
  "c13_nam",
  "c13_tachtra",
  "c13_gaubong",
  "c13_maybay",
  "c13_banghe",
  "dr_mirror",
  "dr_stamp",
  "dr_bg"
]);
(function () {
  for (var i = 0; i < UI_AUDIO_KEYS.length; i++) {
    if (!UI_AUDIO[UI_AUDIO_KEYS[i]]) UI_AUDIO[UI_AUDIO_KEYS[i]] = "audio/" + UI_AUDIO_KEYS[i] + ".mp3";
  }
})();

// Export cho node (QA)
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    UI_AUDIO: UI_AUDIO, UI_AUDIO_KEYS: UI_AUDIO_KEYS, COLORS: COLORS, SHAPES: SHAPES,
    STEP_LESSONS: STEP_LESSONS, COLORING_PAGES: COLORING_PAGES, TRACE_ITEMS: TRACE_ITEMS,
    MIX_COMBOS: MIX_COMBOS, TF_ITEMS: TF_ITEMS, ART_QUIZ: ART_QUIZ,
    colorById: colorById, shapeById: shapeById, lessonById: lessonById,
    coloringById: coloringById, traceById: traceById, artQuizById: artQuizById
  };
}
