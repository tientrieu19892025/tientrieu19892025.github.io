# MatteGlass 2.1

Nhám màn hình, e-ink, lật trang Home kiểu iPhone Duo.

**Credit: Jinken Nguyen - 1989**  
**Donate: MB Bank 0345140889 — Nguyễn Tiến Triều**  
Nội dung chuyển khoản: `Donate Jinken Nguyen 1989`

## Cài

| Jailbreak | File |
| --- | --- |
| Dopamine / palera1n rootless | `iphoneos-arm64.deb` |
| unc0ver / checkra1n | `iphoneos-arm.deb` |
| Dopamine RootHide / Bootstrap | `iphoneos-arm64e.deb` |

Cài một file rồi **Respring**. Sileo trên repo Jinken tự chọn đúng bản.

## Dùng

Cài đặt → MatteGlass. Chọn **Nhám mịn** để thấy hạt trên nền sáng. Kéo cường độ nếu muốn đậm hơn.

E-ink / giấy: trắng-đen như máy đọc sách. Các kiểu khác giữ đủ màu.

Lật Duo: vuốt trang Home. Tắt Giảm chuyển động nếu không thấy hiệu ứng.

## Tắt khẩn cấp

Tạo tệp rỗng `/var/mobile/Library/Preferences/.matteglass-disable` rồi Respring.
