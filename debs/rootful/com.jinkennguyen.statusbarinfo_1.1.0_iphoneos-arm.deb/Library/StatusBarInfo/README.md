# StatusBarInfo

Tweak iOS đa năng giúp hiển thị bảng điều khiển nổi bật với hơn **68 thông số chi tiết hệ thống**, thời gian, âm lịch Can Chi, pin, sức khoẻ pin, nhà mạng, Wi-Fi, thời tiết, thiết bị, RAM, CPU khi chạm vào thanh Status Bar. Tương thích iOS 10 - 18.

---

## 👨‍💻 Thông tin Tác giả & Credit

- **Author / Developer:** Jinken Nguyen - 1989
- **Phiên bản:** 1.1.0
- **Tương thích:** iOS 10.0 – iOS 18.x
- **Kiến trúc hỗ trợ:**
  - `iphoneos-arm` (Rootful: unc0ver, checkra1n, Taurine, palera1n rootful)
  - `iphoneos-arm64` (Rootless: Dopamine, palera1n rootless)
  - `iphoneos-arm64e` (RootHide: Dopamine RootHide)

---

## 💖 Donate / Ủng hộ Tác giả

Nếu bạn thấy tweak hữu ích, hãy donate giúp tác giả duy trì và phát triển nhiều tweak hay cho cộng đồng:

- **Ngân hàng:** MB Bank (Ngân hàng TMCP Quân Đội)
- **Số tài khoản:** `0345140889`
- **Chủ tài khoản:** Nguyễn Tiến Triều
- **Nội dung chuyển khoản:** `Donate StatusBarInfo`

---

## ✨ 10 Nhóm Thông Số với hơn 68 Mục Chi Tiết

Mọi mục đều có thể **bật hoặc tắt độc lập trong Cài đặt (Settings)**:

1. ⏰ **Thời Gian & Lịch (10 mục):** Giờ:phút:giây, ngày dương, thứ, múi giờ GMT, ngày thứ mấy trong năm, tuần trong năm, ngày còn lại, quý, năm nhuận, Uptime.
2. 🌙 **Âm Lịch & Can Chi (6 mục):** Ngày âm lịch, Can Chi ngày, tháng, năm, con giáp, tiết khí 24 mùa, giờ hoàng đạo.
3. 🔋 **Pin & Sức Khoẻ Pin (10 mục):** Mức pin, trạng thái sạc, sức khoẻ pin (dung lượng tối đa %), chu kỳ sạc, LPM, nhiệt độ pin, điện áp, dòng điện mA, công suất Watts, dung lượng thiết kế.
4. 📶 **Nhà Mạng & Di Động (6 mục):** Tên nhà mạng (Viettel, Vina...), MCC, MNC, quốc gia SIM, công nghệ sóng (5G, LTE, 3G), chuyển vùng.
5. 🌐 **Mạng & Kết Nối (7 mục):** Wi-Fi SSID, BSSID, IP nội bộ (IPv4), IP công cộng, VPN, Hotspot, Bluetooth.
6. 🌤 **Thời Tiết & Môi Trường (6 mục):** Nhiệt độ, điều kiện khí hậu, vị trí, độ ẩm, tốc độ gió, cảm nhận nhiệt độ.
7. 📱 **Thiết Bị & Màn Hình (7 mục):** Tên thương mại iPhone, mã phần cứng, tên máy, độ phân giải màn hình, Retina scale, độ sáng, tần số quét (ProMotion).
8. 🍎 **Hệ Thống & Jailbreak (6 mục):** Phiên bản iOS, bản dựng (Build Number), Darwin Kernel, kiểu Jailbreak, bootstrap, pagefile.
9. 💾 **Bộ Nhớ & Lưu Trữ (6 mục):** RAM đã dùng, RAM trống, tổng RAM, ổ cứng đã dùng, còn trống, tổng dung lượng.
10. 🔥 **Hiệu Năng & CPU (4 mục):** Mức tải CPU %, số nhân hoạt động, kiến trúc ARM64e, trạng thái nhiệt độ.

---

## 🚀 Thao tác & Tính năng nổi bật

- 👆 **Chạm để sao chép:** Chạm vào bất kỳ dòng nào để sao chép giá trị trực tiếp vào bộ nhớ tạm.
- 📋 **Sao chép tất cả:** Nút chép toàn bộ 68 mục thành bản báo cáo văn bản chỉ với 1 chạm.
- ⚙️ **Cài đặt chuyên sâu:** Hỗ trợ nút "Bật tất cả 68 mục" và "Tắt tất cả" cùng từng trang phân nhóm riêng biệt.
- 📳 **Haptic Feedback:** Rung phản hồi nhẹ khi tương tác.
- 👆 **Bảo toàn cử chỉ gốc:** Không làm mất tính năng cuộn lên đầu trang (Scroll to Top).
- 💎 **Giao diện kính mờ (Blur Glass):** Thiết kế Floating Card hiện đại, sắc nét.

---

## 📦 Hướng dẫn cài đặt

1. Tải file `.deb` tương ứng trong thư mục `packages/`:
   - `StatusBarInfo-rootless.deb` cho Dopamine / palera1n rootless
   - `StatusBarInfo-roothide.deb` cho Dopamine RootHide
   - `StatusBarInfo-rootful.deb` cho jailbreak truyền thống
2. Cài đặt qua Sileo / Zebra / Filza.
3. Respring thiết bị và mở **Cài đặt → StatusBarInfo**.
