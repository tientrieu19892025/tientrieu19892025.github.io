// 50 Toggles definitions
const SETTINGS_SECTIONS = [
  {
    title: "1. HIỂN THỊ LƯỚI & NGHỆ THUẬT ẢNH",
    items: [
      { id: "enhancedGrid", name: "Bo góc lưới ảnh mượt mà (18pt)", desc: "Góc ảnh cong mềm tự nhiên", default: true },
      { id: "gridGlowBorder", name: "Viền sáng ngọc trai (Glow Outline)", desc: "Đường viền kính phản chiếu đa sắc", default: true },
      { id: "aspectFitGrid", name: "Xem tỉ lệ ảnh gốc không cắt xén", desc: "Ảnh giữ trọn vẹn khung hình", default: false },
      { id: "perspective3D", name: "Hiệu ứng thị sai nghiêng 3D", desc: "Ảnh nghiêng chuyển động nhẹ", default: true },
      { id: "glassCardGrid", name: "Khung thẻ kính nổi sang trọng", desc: "Đổ bóng đa lớp nổi bật", default: true },
      { id: "dynamicMesh", name: "Nền cực quang Ambient Aurora", desc: "Chuyển sắc mượt mà không chói", default: true },
      { id: "microZoom", name: "Phóng to lướt nhẹ khi chạm", desc: "Cảm giác chạm trực quan chân thực", default: true },
      { id: "assetBadge", name: "Hiện thời lượng video trên ảnh", desc: "Thời gian video rõ ràng", default: true },
      { id: "cleanGrid", name: "Ẩn các nhãn thông tin phụ", desc: "Tập trung tối đa vào bức ảnh", default: false },
      { id: "oledDark", name: "Chế độ OLED Đen sâu thẳm", desc: "Tiết kiệm pin màn hình OLED", default: false }
    ]
  },
  {
    title: "2. BỘ LỌC & NHÓM ẢNH THÔNG MINH",
    items: [
      { id: "separateVideos", name: "Tách riêng bộ sưu tập Video", desc: "Xem nhanh các clip trong máy", default: true },
      { id: "groupScreenshots", name: "Nhóm ảnh chụp màn hình", desc: "Tự động phân loại screenshot", default: true },
      { id: "groupPortraits", name: "Nhóm ảnh chân dung xoá phông", desc: "Lọc ảnh Portrait chất lượng", default: true },
      { id: "groupRAW", name: "Nhóm ảnh RAW chuyên nghiệp", desc: "Dành cho nhiếp ảnh gia", default: false },
      { id: "groupBursts", name: "Nhóm ảnh chụp liên tục", desc: "Quản lý chùm ảnh gọn gàng", default: false },
      { id: "groupAnimated", name: "Nhóm ảnh động GIF", desc: "Duyệt nhanh ảnh chuyển động", default: false },
      { id: "groupSelfies", name: "Nhóm ảnh selfie mặt trước", desc: "Tập hợp các bức ảnh tự chụp", default: false },
      { id: "groupLivePhotos", name: "Nhóm ảnh Live Photos", desc: "Xem riêng bộ sưu tập Live", default: true },
      { id: "smartDuplicate", name: "Lọc ảnh tương tự nhau", desc: "Gợi ý dọn dẹp dung lượng", default: false },
      { id: "hideHiddenAlbum", name: "Khoá ẩn hoàn toàn Album ẩn", desc: "Bảo vệ riêng tư tối đa", default: false }
    ]
  },
  {
    title: "3. TRÌNH XEM ẢNH FULLSCREEN",
    items: [
      { id: "infiniteZoom", name: "Thu phóng vô hạn (Infinite Zoom)", desc: "Zoom ảnh siêu nét căng", default: true },
      { id: "quickFav", name: "Thả tim 1 chạm ❤️", desc: "Thêm vào danh sách yêu thích", default: true },
      { id: "quickCopy", name: "Sao chép ảnh vào Clipboard", desc: "Dán nhanh qua Zalo, Messenger", default: true },
      { id: "showExif", name: "Xem thông số máy ảnh & kích thước", desc: "Hiện pixel, ngày chụp", default: true },
      { id: "quickFlip", name: "Lật ảnh đối xứng ngang", desc: "Đổi hướng ảnh lập tức", default: false },
      { id: "quickRotate", name: "Xoay ảnh 90 độ tức thì", desc: "Xoay chiều trực quan", default: true },
      { id: "fastDelete", name: "Xoá ảnh nhanh khỏi máy", desc: "Thao tác dọn dẹp tiện lợi", default: true },
      { id: "showFileSize", name: "Hiện kích thước ảnh", desc: "Biết ngay thông số ảnh", default: true },
      { id: "swipeDownDismiss", name: "Vuốt xuống để đóng ảnh", desc: "Thao tác cử chỉ mượt mà", default: true },
      { id: "protectWithLock", name: "Bảo mật riêng tư khi xem", desc: "Chống nhìn trộm", default: false }
    ]
  },
  {
    title: "4. TRÌNH PHÁT VIDEO THẾ HỆ MỚI",
    items: [
      { id: "autoLoop", name: "Tự động phát lại video (Loop)", desc: "Lặp lại vô hạn mượt mà", default: true },
      { id: "autoUnmute", name: "Tự động bật âm thanh khi xem", desc: "Không cần nhấn nút loa", default: false },
      { id: "doubleTapSeek", name: "Chạm 2 lần để tua video", desc: "Điều hướng video nhanh", default: true },
      { id: "saveFrame", name: "Trích xuất khung hình video sắc nét", desc: "Lưu frame đẹp thành ảnh tĩnh", default: true },
      { id: "hold2X", name: "Nhấn giữ màn hình tua 2X", desc: "Tăng tốc độ phát video", default: true },
      { id: "smooth60fps", name: "Chuyển động video mượt mà 60/120fps", desc: "Tối ưu hóa GPU ProMotion", default: true },
      { id: "pipMode", name: "Xem video dạng cửa sổ nổi", desc: "Vừa xem vừa lướt ảnh khác", default: false },
      { id: "videoMuteDefault", name: "Tắt tiếng video xem trước", desc: "Tránh ồn nơi công cộng", default: true },
      { id: "rememberPlayback", name: "Ghi nhớ đoạn đang phát dở", desc: "Tiếp tục xem khi mở lại", default: true },
      { id: "volumeGesture", name: "Vuốt dọc chỉnh âm lượng", desc: "Cử chỉ âm thanh tiện dụng", default: true }
    ]
  },
  {
    title: "5. HỆ THỐNG & TRẢI NGHIỆM ĐỈNH CAO",
    items: [
      { id: "hapticFeedback", name: "Rung phản hồi xúc giác (Haptic)", desc: "Cảm giác chạm phím sắc sảo", default: true },
      { id: "gpuMetalAccel", name: "Tăng tốc phần cứng Metal Engine", desc: "Cuộn 120Hz không giật lag", default: true },
      { id: "cacheFastThumb", name: "Bộ nhớ đệm ảnh thumbnail tức thì", desc: "Mở app hiển thị ngay lập tức", default: true },
      { id: "hideHomeBar", name: "Tự ẩn thanh Home Bar khi ngắm ảnh", desc: "Mở rộng không gian hiển thị", default: false },
      { id: "preventDimming", name: "Giữ màn hình luôn sáng rõ", desc: "Không tự khoá khi xem album", default: true },
      { id: "trashProtection", name: "Bảo vệ thùng rác an toàn", desc: "Chống bấm nhầm xoá vĩnh viễn", default: true },
      { id: "neonDockGlow", name: "Hiệu ứng viền phát sáng thanh Dock", desc: "Kính lỏng tương lai iOS 27", default: true },
      { id: "autoOrientation", name: "Tự xoay theo chiều ảnh gốc", desc: "Không cần tắt khoá xoay", default: false },
      { id: "lowDataMode", name: "Chế độ tải ảnh tiết kiệm", desc: "Tối ưu cho máy dung lượng thấp", default: false },
      { id: "aboutCredits", name: "Giới thiệu tác giả & Donate", desc: "Credit: Jinken Nguyen - 1989", default: true }
    ]
  }
];

let appState = {
  currentTab: 'library',
  currentFilter: 'all',
  layoutCol: 3,
  photos: [],
  currentPhoto: null,
  currentRotation: 0,
  settings: {}
};

// Initialize Settings
function initSettings() {
  const saved = localStorage.getItem('photos27_settings');
  if (saved) {
    try { appState.settings = JSON.parse(saved); } catch(e) {}
  }
  SETTINGS_SECTIONS.forEach(sec => {
    sec.items.forEach(item => {
      if (appState.settings[item.id] === undefined) {
        appState.settings[item.id] = item.default;
      }
    });
  });
}

function saveSetting(id, val) {
  appState.settings[id] = val;
  localStorage.setItem('photos27_settings', JSON.stringify(appState.settings));
  applySettingsEffects();
}

function applySettingsEffects() {
  const grid = document.getElementById('photo-grid');
  if (!grid) return;
  
  // Aspect Fit
  if (appState.settings.aspectFitGrid) {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.add('aspect-fit'));
  } else {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.remove('aspect-fit'));
  }
  
  // 3D Card
  if (appState.settings.perspective3D) {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.add('card-3d'));
  } else {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.remove('card-3d'));
  }

  // Glow Border
  if (appState.settings.gridGlowBorder) {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.add('glow-border'));
  } else {
    grid.querySelectorAll('.photo-item').forEach(el => el.classList.remove('glow-border'));
  }

  // OLED Dark
  if (appState.settings.oledDark) {
    document.body.style.background = '#000000';
    document.body.style.backgroundImage = 'none';
  } else {
    document.body.style.background = 'var(--bg-deep)';
    document.body.style.backgroundImage = 'var(--bg-gradient)';
  }
}

function triggerHaptic() {
  if (appState.settings.hapticFeedback !== false && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.haptic) {
    window.webkit.messageHandlers.haptic.postMessage({ type: 'light' });
  }
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (t) {
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
  }
}
window.showToast = showToast;

function copySTK() {
  triggerHaptic();
  if (navigator.clipboard) {
    navigator.clipboard.writeText('0345140889');
  }
  showToast("Đã sao chép STK: 0345140889 (MB Bank)");
}

// Native Bridge Callbacks
window.receiveNativePhotos = function(photosJson) {
  try {
    const list = typeof photosJson === 'string' ? JSON.parse(photosJson) : photosJson;
    if (Array.isArray(list)) {
      appState.photos = list;
      
      // Update hero memory banner with the first favorite or first photo
      const heroPhoto = list.find(p => p.isFav) || list[0];
      if (heroPhoto) {
        const heroImg = document.getElementById('hero-img');
        if (heroImg) heroImg.src = heroPhoto.thumb;
      }
      
      renderGallery();
    }
  } catch(e) {
    console.error("Error parsing photos:", e);
  }
};

window.receiveFullMedia = function(localId, mediaData, isVideo) {
  if (appState.currentPhoto && appState.currentPhoto.id === localId) {
    const imgEl = document.getElementById('viewer-img');
    const vidEl = document.getElementById('viewer-video');
    if (isVideo) {
      if (imgEl) imgEl.style.display = 'none';
      if (vidEl) {
        vidEl.src = mediaData;
        vidEl.style.display = 'block';
        vidEl.play();
      }
    } else {
      if (vidEl) {
        vidEl.pause();
        vidEl.style.display = 'none';
      }
      if (imgEl) {
        imgEl.src = mediaData;
        imgEl.style.display = 'block';
      }
    }
  }
};

window.onFavoriteUpdated = function(localId, isFav) {
  const p = appState.photos.find(x => x.id === localId);
  if (p) p.isFav = isFav;
  if (appState.currentPhoto && appState.currentPhoto.id === localId) {
    appState.currentPhoto.isFav = isFav;
    updateViewerFavButton(isFav);
  }
  renderGallery();
  showToast(isFav ? "Đã thêm vào Yêu thích ❤️" : "Đã bỏ Yêu thích 💔");
};

window.onPhotoDeleted = function(localId) {
  appState.photos = appState.photos.filter(x => x.id !== localId);
  closeViewer();
  renderGallery();
  showToast("Đã xoá ảnh khỏi thư viện 🗑️");
};

// Fullscreen Photo Viewer Logic
function openFullscreenPhoto(photo) {
  triggerHaptic();
  appState.currentPhoto = photo;
  appState.currentRotation = 0;
  
  const modal = document.getElementById('modal-viewer');
  const imgEl = document.getElementById('viewer-img');
  const vidEl = document.getElementById('viewer-video');
  const titleEl = document.getElementById('viewer-title');
  const subEl = document.getElementById('viewer-sub');
  
  if (titleEl) {
    titleEl.textContent = photo.isVideo ? 'Video' : (photo.isScreenshot ? 'Ảnh chụp màn hình' : (photo.isPortrait ? 'Chân dung' : 'Ảnh'));
  }
  if (subEl) {
    const dim = (photo.width && photo.height) ? `${photo.width} × ${photo.height}` : '';
    subEl.textContent = `${photo.date || ''} ${dim ? '• ' + dim : ''}`;
  }
  
  updateViewerFavButton(photo.isFav);
  
  if (photo.isVideo) {
    if (imgEl) imgEl.style.display = 'none';
    if (vidEl) {
      vidEl.style.display = 'block';
      vidEl.style.transform = 'none';
    }
  } else {
    if (vidEl) {
      vidEl.pause();
      vidEl.style.display = 'none';
    }
    if (imgEl) {
      imgEl.src = photo.thumb; // Show fast thumbnail immediately
      imgEl.style.display = 'block';
      imgEl.style.transform = 'none';
    }
  }
  
  modal.classList.add('active');
  
  // Request full resolution image or video asset from native
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.getFullPhoto) {
    window.webkit.messageHandlers.getFullPhoto.postMessage({ id: photo.id });
  }
}

function closeViewer() {
  triggerHaptic();
  const modal = document.getElementById('modal-viewer');
  const vidEl = document.getElementById('viewer-video');
  if (vidEl) {
    vidEl.pause();
    vidEl.src = '';
  }
  if (modal) modal.classList.remove('active');
  appState.currentPhoto = null;
}

function updateViewerFavButton(isFav) {
  const btn = document.getElementById('btn-viewer-fav');
  if (btn) {
    btn.textContent = isFav ? '❤️' : '🤍';
  }
}

// Render Gallery
function renderGallery() {
  const grid = document.getElementById('photo-grid');
  const countLbl = document.getElementById('section-count');
  if (!grid) return;
  grid.innerHTML = '';
  
  let filtered = appState.photos;
  if (appState.currentFilter === 'videos') {
    filtered = filtered.filter(p => p.isVideo);
  } else if (appState.currentFilter === 'favs') {
    filtered = filtered.filter(p => p.isFav);
  } else if (appState.currentFilter === 'screenshots') {
    filtered = filtered.filter(p => p.isScreenshot);
  } else if (appState.currentFilter === 'portraits') {
    filtered = filtered.filter(p => p.isPortrait);
  } else if (appState.currentFilter === 'live') {
    filtered = filtered.filter(p => p.isLive);
  }
  
  if (countLbl) {
    countLbl.textContent = `${filtered.length} mục`;
  }
  
  filtered.forEach(p => {
    const item = document.createElement('div');
    let classes = 'photo-item';
    if (appState.settings.aspectFitGrid) classes += ' aspect-fit';
    if (appState.settings.perspective3D) classes += ' card-3d';
    if (appState.settings.gridGlowBorder) classes += ' glow-border';
    item.className = classes;
    
    let html = `<img src="${p.thumb || p.url}" alt="" loading="lazy">`;
    if (p.isVideo) {
      html += `<div class="item-badge">▶ ${p.duration || '0:15'}</div>`;
    }
    if (p.isFav) {
      html += `<div class="fav-badge">❤️</div>`;
    }
    item.innerHTML = html;
    
    // Tapping photo opens Fullscreen Viewer directly!
    item.onclick = () => openFullscreenPhoto(p);
    grid.appendChild(item);
  });
}

// Render Settings Sheet
function renderSettings() {
  const container = document.getElementById('settings-list');
  if (!container) return;
  container.innerHTML = '';
  
  SETTINGS_SECTIONS.forEach(sec => {
    const title = document.createElement('div');
    title.className = 'setting-group-title';
    title.textContent = sec.title;
    container.appendChild(title);
    
    const card = document.createElement('div');
    card.className = 'setting-card';
    
    sec.items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'setting-row';
      const isChecked = appState.settings[item.id] !== false;
      
      row.innerHTML = `
        <div class="setting-info">
          <div class="setting-name">${item.name}</div>
          <div class="setting-desc">${item.desc}</div>
        </div>
        <label class="switch">
          <input type="checkbox" id="set_${item.id}" ${isChecked ? 'checked' : ''}>
          <span class="slider"></span>
        </label>
      `;
      
      const chk = row.querySelector('input');
      chk.onchange = (e) => {
        triggerHaptic();
        saveSetting(item.id, e.target.checked);
      };
      card.appendChild(row);
    });
    
    container.appendChild(card);
  });
  
  // Donate Box
  const donate = document.createElement('div');
  donate.className = 'donate-box';
  donate.innerHTML = `
    <div style="font-weight:700; font-size:15px; margin-bottom:4px;">☕ Donate Tác Giả</div>
    <div style="font-size:12px; color:var(--text-sub); line-height:1.5;">
      Credit: Jinken Nguyen - 1989<br>
      MB Bank · 0345140889 · Nguyễn Tiến Triều
    </div>
    <button class="donate-btn" onclick="copySTK()">📋 Sao chép STK MB Bank</button>
  `;
  container.appendChild(donate);
}

// DOM Ready & Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  initSettings();
  renderSettings();
  applySettingsEffects();
  
  // Category Chips
  document.querySelectorAll('.cat-chip').forEach(chip => {
    chip.onclick = () => {
      triggerHaptic();
      document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      appState.currentFilter = chip.getAttribute('data-filter');
      renderGallery();
    };
  });
  
  // Grid Column Toggle
  const colBtn = document.getElementById('btn-grid-col');
  if (colBtn) {
    colBtn.onclick = () => {
      triggerHaptic();
      const grid = document.getElementById('photo-grid');
      if (appState.layoutCol === 3) {
        appState.layoutCol = 2;
        grid.className = 'photo-grid col-2';
        colBtn.textContent = '📰';
      } else if (appState.layoutCol === 2) {
        appState.layoutCol = 4;
        grid.className = 'photo-grid col-4';
        colBtn.textContent = '📱';
      } else {
        appState.layoutCol = 3;
        grid.className = 'photo-grid';
        colBtn.textContent = '📐';
      }
    };
  }
  
  // Aspect Fit Toggle
  const aspectBtn = document.getElementById('btn-aspect-fit');
  if (aspectBtn) {
    aspectBtn.onclick = () => {
      triggerHaptic();
      appState.settings.aspectFitGrid = !appState.settings.aspectFitGrid;
      saveSetting('aspectFitGrid', appState.settings.aspectFitGrid);
    };
  }
  
  // Settings Sheet Toggle
  const openSet = document.getElementById('btn-open-settings');
  const closeSet = document.getElementById('btn-close-settings');
  const sheet = document.getElementById('settings-sheet');
  if (openSet && sheet) {
    openSet.onclick = () => {
      triggerHaptic();
      sheet.classList.add('active');
    };
  }
  if (closeSet && sheet) {
    closeSet.onclick = () => {
      triggerHaptic();
      sheet.classList.remove('active');
    };
  }

  // Fullscreen Viewer Controls
  const closeViewerBtn = document.getElementById('btn-viewer-close');
  if (closeViewerBtn) {
    closeViewerBtn.onclick = closeViewer;
  }

  const moreViewerBtn = document.getElementById('btn-viewer-more');
  if (moreViewerBtn) {
    moreViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.openActionMenu) {
        triggerHaptic();
        window.webkit.messageHandlers.openActionMenu.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const favViewerBtn = document.getElementById('btn-viewer-fav');
  if (favViewerBtn) {
    favViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.toggleFavorite) {
        triggerHaptic();
        window.webkit.messageHandlers.toggleFavorite.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const copyViewerBtn = document.getElementById('btn-viewer-copy');
  if (copyViewerBtn) {
    copyViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.copyPhoto) {
        triggerHaptic();
        window.webkit.messageHandlers.copyPhoto.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  const rotateViewerBtn = document.getElementById('btn-viewer-rotate');
  if (rotateViewerBtn) {
    rotateViewerBtn.onclick = () => {
      triggerHaptic();
      appState.currentRotation = (appState.currentRotation + 90) % 360;
      const img = document.getElementById('viewer-img');
      if (img) img.style.transform = `rotate(${appState.currentRotation}deg)`;
    };
  }

  const deleteViewerBtn = document.getElementById('btn-viewer-delete');
  if (deleteViewerBtn) {
    deleteViewerBtn.onclick = () => {
      if (appState.currentPhoto && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.deletePhoto) {
        triggerHaptic();
        window.webkit.messageHandlers.deletePhoto.postMessage({ id: appState.currentPhoto.id });
      }
    };
  }

  // Swipe Down to Dismiss Fullscreen Viewer
  let touchStartY = 0;
  const viewerBody = document.getElementById('viewer-body');
  if (viewerBody) {
    viewerBody.addEventListener('touchstart', (e) => {
      touchStartY = e.touches[0].clientY;
    }, { passive: true });

    viewerBody.addEventListener('touchend', (e) => {
      const touchEndY = e.changedTouches[0].clientY;
      if (touchEndY - touchStartY > 120) {
        closeViewer();
      }
    }, { passive: true });
  }
  
  // Request Native Photos
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.loadLibrary) {
    window.webkit.messageHandlers.loadLibrary.postMessage({});
  }
});
