# DuoFrame

iOS 27 Home Screen for jailbroken iPhone. Three independent liquid-glass frames — **status bar**, **icon grid**, **dock** — and the **iPhone Duo** combined status glyph (battery arc + centre Wi-Fi + four cellular dots).

**Credit: Jinken Nguyen - 1989**

Donate: MB Bank `0345140889` — Nguyễn Tiến Triều

> Not affiliated with Apple. The combined glyph follows the public iPhone Duo status-bar design (outer battery ring, Wi-Fi in the middle, signal dots in the bottom gap).

## What it does

DuoFrame injects into SpringBoard only and:

1. **Status capsule** — glass bar on Home with time on the left and the Duo trio on the far right. Pick a default by phone size (SE → Pro Max, notch → Dynamic Island) or a style (pill, two equal wings, Island hug, slim, stacked). Device/style presets do not move the icon grid or dock.
2. **Icon card** — the Home Screen icon grid sits in its own framed glass, separate from the status bar and the dock.
3. **Dock frame** — the dock is a floating glass platter with a hairline rim. Icons stay centered in the tray even with 4–6 columns.
3b. **App Library** — Swipe right uses a full-page glass. Swipe left (Today / Search) stays stock — no DuoFrame frame. Pick a frame look for Home and Library. Optional tilt fade.
4. **iPhone Duo glyph** — cellular, Wi-Fi and battery collapse into one circular icon:
   - outer arc = battery (green while charging, yellow in Low Power Mode, red under 20%)
   - centre = Wi-Fi fans
   - four dots = cellular bars
5. **Control Center** — pulling CC expands the trio back into the stock system icons (same behaviour as iPhone Duo).
6. **Does not inject into other apps.** Safe Mode does not load it.

## Install

Three packages are built:

| File | Jailbreak |
| --- | --- |
| `com.jinkennguyen.duoframe_*_iphoneos-arm64.deb` | Rootless (Dopamine, palera1n rootless) |
| `com.jinkennguyen.duoframe_*_iphoneos-arm.deb` | Rootful (unc0ver, checkra1n, palera1n rootful) |
| `com.jinkennguyen.duoframe_*_iphoneos-arm64e.deb` | RootHide (Dopamine-roothide / RootHide Bootstrap) |

Aliases: `DuoFrame-rootless.deb` / `DuoFrame-rootful.deb` / `DuoFrame-roothide.deb`.

Install **one** matching file with Sileo, Zebra or Filza, then **Respring**. Do not mix rootless on a rootful device.

If SpringBoard hangs or Safe Mode: create `/var/mobile/Library/Preferences/.duoframe-disable` and Respring.

Open **Settings → DuoFrame**. Tap **Safe reset** if the layout looks wrong.

## Requirements

- iOS 14 and later (written to keep working through iOS 15–18 and 26/27 SpringBoard class names)
- arm64 / arm64e
- Cydia Substrate / Substitute / ElleKit (MobileSubstrate)
- PreferenceLoader

## Options

- Enabled
- Frame status bar / icon grid / dock independently
- Floating dock
- Duo glyph, hide stock cellular/Wi-Fi/battery, expand in Control Center
- Optional battery percentage inside the glyph
- Glyph on Lock Screen and inside apps
- Hide icon labels / page dots
- Liquid glass, specular highlight, quality, opacity, corner radius, padding, gap
- Language: Auto / Tiếng Việt / English
- Donate: MB Bank 0345140889 — Nguyễn Tiến Triều
- Respring, kill-switch help

## Safety

- Kill file: `/var/mobile/Library/Preferences/.duoframe-disable` then Respring
- Safe Mode does not load the tweak
- SpringBoard only

## Build

```sh
export THEOS=$HOME/theos
./scripts/build.sh
```

Packages land in `packages/`.
