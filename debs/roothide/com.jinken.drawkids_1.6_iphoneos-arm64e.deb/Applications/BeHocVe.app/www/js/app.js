// ============================================================
// Bé học Vẽ - logic chính
// Thứ tự script: js/data.js -> js/app.js
// QUY TẮC BẮT BUỘC: chỉ dùng cú pháp ES5 (var, function, nối chuỗi
// bằng +). CẤM: async/await, arrow function, template literal,
// padStart, destructuring, let/const, spread, class, optional chaining.
// Vẽ canvas bằng Pointer Events (chạy cả chuột + cảm ứng).
// ============================================================
"use strict";
function $(s) { return document.querySelector(s); }
function $$(s) {
  var n = document.querySelectorAll(s), a = [];
  for (var i = 0; i < n.length; i++) a.push(n[i]);
  return a;
}
function shuffle(a) {
  a = a.slice();
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function rint(lo, hi) { return lo + Math.floor(Math.random() * (hi - lo + 1)); }
// Thoát ký tự HTML cho chuỗi do người dùng nhập (tên bé) trước khi ghép vào innerHTML.
// Không thoát -> tên chứa < > sẽ vỡ layout hoặc chèn thẻ lạ.
function escHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;";
  });
}

// ---------- Lớp phòng thủ cho data.js ----------
var UA = (typeof UI_AUDIO !== "undefined" && UI_AUDIO) ? UI_AUDIO : {};

// ---------- Tiến trình (lưu trên máy) ----------
var PKEY = "drawkids_progress_v1";
var store = {
  data: { stars: 0, gameBest: {}, gameScores: {}, gamePlays: 0, streak: null,
    childName: "", childAvatar: "", uiPrefs: null, gallery: [],
    lessonsDone: {}, traceDone: {}, dailyBest: {} },
  load: function () {
    try {
      var raw = localStorage.getItem(PKEY);
      if (raw) {
        var d = JSON.parse(raw), k;
        for (k in d) this.data[k] = d[k];
      }
    } catch (e) {}
    // Vá kiểu dữ liệu hỏng (localStorage bị sửa tay / bản cũ):
    // sai kiểu mà không vá -> push/cong chuỗi vỡ chức năng.
    var D = this.data;
    if (typeof D.stars !== "number" || isNaN(D.stars)) D.stars = 0;
    if (!D.gameBest || typeof D.gameBest !== "object") D.gameBest = {};
    if (!D.gameScores || typeof D.gameScores !== "object") D.gameScores = {};
    if (typeof D.gamePlays !== "number" || isNaN(D.gamePlays)) D.gamePlays = 0;
    if (typeof D.childName !== "string") D.childName = "";
    if (typeof D.childAvatar !== "string") D.childAvatar = "";
    if (!D.gallery || Object.prototype.toString.call(D.gallery) !== "[object Array]") D.gallery = [];
    if (!D.photos || Object.prototype.toString.call(D.photos) !== "[object Array]") D.photos = [];
    if (!D.lessonsDone || typeof D.lessonsDone !== "object") D.lessonsDone = {};
    if (!D.traceDone || typeof D.traceDone !== "object") D.traceDone = {};
    if (!D.dailyBest || typeof D.dailyBest !== "object") D.dailyBest = {};
    if (D.streak !== null && (typeof D.streak !== "object")) D.streak = null;
  },
  // Trả về true/false để nơi gọi biết khi bộ nhớ đầy (quota) mà xử lý.
  save: function () { try { localStorage.setItem(PKEY, JSON.stringify(this.data)); return true; } catch (e) { return false; } },
  reset: function () {
    this.data = { stars: 0, gameBest: {}, gameScores: {}, gamePlays: 0, streak: null,
      childName: this.data.childName, childAvatar: this.data.childAvatar,
      uiPrefs: this.data.uiPrefs, gallery: [], photos: [],
      lessonsDone: {}, traceDone: {}, dailyBest: {} };
    this.save();
  }
};
function addStars(n) { store.data.stars += n; store.save(); refreshStarPill(); }
function refreshStarPill() { $("#stars-total").textContent = store.data.stars; }

// ---------- Âm thanh: phát 1 clip, lỗi thì bỏ qua êm ----------
var currentAudio = null;
// Watchdog chống treo: WebView cũ play() không trả Promise, sự kiện onended/onerror
// của thẻ audio đôi khi không bao giờ tới (đặc biệt với file local) -> callback onend
// treo, tiến trình đứng yên, màn hình trắng (vd: startDaily chờ intro phát xong mới
// render câu hỏi đầu). Watchdog đảm bảo onend luôn được gọi TỐI ĐA 1 lần trong vòng
// AUDIO_WATCHDOG_MS, kể cả khi WebView nuốt mất sự kiện media.
var AUDIO_WATCHDOG_MS = 8000; // lưới an toàn cuối: render không bao giờ chờ audio nữa nên
// chỉ còn làm nhiệm vụ dự phòng cho callback audio nền
var audioWatchdog = null;
function clearAudioWatchdog() {
  if (audioWatchdog) { clearTimeout(audioWatchdog); audioWatchdog = null; }
}
function playAudio(src, onend) {
  if (!src) { if (onend) onend(); return; }
  clearAudioWatchdog();
  var done = false;
  function fireEnd() {
    if (done) return;
    done = true; clearAudioWatchdog();
    if (onend) onend();
  }
  try {
    if (currentAudio) {
      try { currentAudio.pause(); } catch (e2) {}
      try { currentAudio.onended = null; currentAudio.onerror = null; } catch (e3) {}
    }
    currentAudio = new Audio(src);
    if (onend) {
      currentAudio.onended = fireEnd;
      // Dự phòng WebView cũ: sự kiện media không tới -> vẫn tiến tiếp, không trắng trang.
      audioWatchdog = setTimeout(fireEnd, AUDIO_WATCHDOG_MS);
    }
    currentAudio.onerror = fireEnd;
    var pr = currentAudio.play();
    if (pr && pr.catch) pr.catch(fireEnd);
  } catch (e) { fireEnd(); }
}

// ---------- Kênh thuyết minh: chuyển mục là ngắt ngay cái cũ ----------
var narrTimers = [];
function stopNarration() {
  for (var i = 0; i < narrTimers.length; i++) clearTimeout(narrTimers[i]);
  narrTimers = [];
  // Xóa watchdog của clip đang phát dở: kẻo nó nổ sau khi đã chuyển màn hình
  // (vd: render câu hỏi daily lên nhầm màn hình trang chủ).
  clearAudioWatchdog();
  if (currentAudio) { try { currentAudio.pause(); } catch (e) {} currentAudio = null; }
}
function narrate(src, ms, onend) {
  narrTimers.push(setTimeout(function () { playAudio(src, onend); }, ms == null ? 0 : ms));
}

// ---------- Điều hướng ----------
var TITLES = {
  "screen-home": "Bé học Vẽ", "screen-free": "🎨 Vẽ tự do",
  "screen-steps-list": "✏️ Vẽ từng bước", "screen-steps": "✏️ Vẽ từng bước",
  "screen-coloring-list": "🖍️ Tô màu", "screen-coloring": "🖍️ Tô màu",
  "screen-trace-list": "〰️ Tô nét", "screen-trace": "〰️ Tô nét",
  "screen-colors": "🌈 Màu sắc", "screen-shapes": "⬛ Hình khối",
  "screen-games": "🎮 Trò chơi", "screen-game-play": "🎮 Trò chơi",
  "screen-result": "🏆 Kết quả", "screen-progress": "🏆 Thành tích",
  "screen-gallery": "🖼️ Bộ sưu tập", "screen-settings": "⚙️ Cài đặt",
  "screen-welcome": "👋 Chào bé",
  "screen-donate": "❤️ Ủng hộ", "screen-photos": "📤 Ảnh của bé",
  "screen-photo-learn": "📸 Học từ ảnh"
};
var NARRATE = {
  "screen-home": "nav_home", "screen-free": "nav_free",
  "screen-steps-list": "nav_steps", "screen-coloring-list": "nav_coloring",
  "screen-trace-list": "nav_trace", "screen-colors": "nav_colors",
  "screen-shapes": "nav_shapes", "screen-games": "nav_games",
  "screen-progress": "nav_progress", "screen-gallery": "nav_gallery",
  "screen-settings": "nav_settings",
  "screen-donate": "dn_nav", "screen-photos": "ph_intro",
  "screen-photo-learn": "ph_learn_guide"
};
var navHistory = [];
var galViewOpen = false;
function showScreen(id, push, afterNarr) {
  stopNarration();
  var screens = $$(".screen"), i;
  for (i = 0; i < screens.length; i++) screens[i].classList.remove("active");
  $("#" + id).classList.add("active");
  $("#title").textContent = TITLES[id] || "Bé học Vẽ";
  $("#btn-back").classList.toggle("show", id !== "screen-home");
  if (id === "screen-home") refreshHome();
  if (push !== false && navHistory[navHistory.length - 1] !== id) navHistory.push(id);
  var mn = $("main"); if (mn) mn.scrollTop = 0;
  // TÁCH RENDER KHỎI NARRATION: màn hình chuyển đồng bộ ở trên, KHÔNG chờ audio.
  // Có afterNarr -> chạy NGAY đồng bộ và bỏ qua NARRATE[id] tự động (caller tự
  // chuỗi audio của mình, tránh chồng tiếng). Không có -> NARRATE[id] phát nền
  // fire-and-forget (không callback), không bao giờ chặn render.
  if (afterNarr) { afterNarr(); return; }
  var nk = NARRATE[id];
  var ns = nk && UA[nk];
  if (ns) narrate(ns, 350);
}
function goBack() {
  if (galViewOpen) { closeGalView(); return; }
  navHistory.pop();
  var prev = navHistory.pop() || "screen-home";
  showScreen(prev);
}
function replayPush(id) {
  if (navHistory[navHistory.length - 1] === "screen-result") navHistory.pop();
  if (navHistory[navHistory.length - 1] !== id) navHistory.push(id);
}
$("#btn-back").addEventListener("click", goBack);
window.__systemBack = function () {
  if (galViewOpen) { closeGalView(); return true; }
  if (navHistory.length <= 1) return false;
  goBack();
  return true;
};
function wireMenu() {
  var btns = $$("[data-go]"), i;
  for (i = 0; i < btns.length; i++) {
    (function (b) {
      b.addEventListener("click", function () {
        var t = b.getAttribute("data-go");
        if (t === "steps-list") renderStepsList();
        else if (t === "coloring-list") renderColoringList();
        else if (t === "trace-list") renderTraceList();
        else if (t === "colors") renderColors();
        else if (t === "shapes") renderShapes();
        else if (t === "games") renderGames();
        else if (t === "progress") renderProgress();
        else if (t === "gallery") renderGallery();
        else if (t === "settings") renderSettings();
        else if (t === "photos") renderPhotos();
        else if (t === "free") initFree();
        else if (t === "daily") { startDaily(); return; }
        showScreen("screen-" + t);
      });
    })(btns[i]);
  }
}

// ---------- Trang chủ: chào tên, cấp bậc, streak ----------
function todayStr(d) { return new Date(d).toISOString().slice(0, 10); }
function streakCount() { return (store.data.streak && store.data.streak.count) || 0; }
function bumpStreak() {
  var today = todayStr(Date.now());
  var yest = todayStr(Date.now() - 864e5);
  var st = store.data.streak || { count: 0, last: "" };
  if (st.last !== today) {
    st.count = (st.last === yest) ? st.count + 1 : 1;
    st.last = today;
    store.data.streak = st; store.save();
  }
  return st.count;
}
function kidRank() {
  var s = store.data.stars || 0;
  if (s >= 500) return "🏆 Huyền thoại nhí";
  if (s >= 200) return "🚀 Cao thủ nhí";
  if (s >= 100) return "🌟 Ngôi sao nhí";
  if (s >= 50) return "💪 Chiến binh nhí";
  if (s >= 20) return "🌱 Bé chăm học";
  return "🐣 Bé mới bắt đầu";
}
function refreshHome() {
  var n = streakCount();
  var sub = $("#card-daily-sub");
  if (sub) sub.textContent = n > 0 ? "🔥 " + n + " ngày liên tiếp!" : "12 câu hỏi mỗi ngày";
  var rk = kidRank();
  var hre = $("#hero-rank");
  if (hre) hre.textContent = rk + " · " + store.data.stars + " ⭐";
  var hello = $("#hero-hello");
  if (hello) {
    hello.innerHTML = "";
    hello.appendChild(document.createTextNode("Chào "));
    var hb = document.createElement("b");
    hb.textContent = kidName();
    hello.appendChild(hb);
    hello.appendChild(document.createTextNode(" " + kidAvatar() + "! Chạm Momo để chào nhé! 🎉"));
  }
  var pill = $("#streak-pill");
  if (pill) {
    if (n > 0) { $("#streak-text").textContent = "🔥 " + n + " ngày học liên tiếp!"; pill.style.display = "inline-flex"; }
    else pill.style.display = "none";
  }
}

// ---------- Confetti / toast / sao bay ----------
function confetti() {
  var icons = ["🎉", "⭐", "🎊", "✨", "🌟"], i;
  for (i = 0; i < 45; i++) {
    var c = document.createElement("div");
    c.className = "confetti";
    c.textContent = icons[i % icons.length];
    c.style.left = (Math.random() * 100) + "vw";
    c.style.animationDelay = (Math.random() * 0.9).toFixed(2) + "s";
    c.style.fontSize = (20 + Math.random() * 18) + "px";
    document.body.appendChild(c);
    (function (el) { setTimeout(function () { el.remove(); }, 4200); })(c);
  }
}
var toastTimer = null;
function toast(msg) {
  var el = $("#toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove("show"); }, 1600);
}
function starBurst(x, y) {
  for (var i = 0; i < 6; i++) {
    var s = document.createElement("div");
    s.className = "burst"; s.textContent = "⭐";
    s.style.left = (x + (Math.random() * 80 - 40)) + "px";
    s.style.top = (y + (Math.random() * 30 - 15)) + "px";
    document.body.appendChild(s);
    (function (el) { setTimeout(function () { el.remove(); }, 1000); })(s);
  }
}

// ============================================================
// CỔ VŨ KIỂU MONKEY STORIES: Momo nhảy múa, combo, khen đa dạng
// ============================================================
var PRAISE_KEYS = ["praise1", "praise2", "praise3", "praise4", "praise5", "praise6"];
var PRAISE_TEXTS = ["Tuyệt vời! 🎉", "Giỏi quá! ⭐", "Hoan hô! 🎊", "Đẹp quá đi! 🌟", "Đúng rồi! 💛", "Hay quá! 🎈"];
var TRY_TEXTS = ["Chưa đúng, thử lại nhé! 💪", "Gần đúng rồi! 🌱"];
var combo = 0, lastPraiseIdx = -1, gameMistakes = 0;
function pickPraise() {
  var i, guard = 0;
  do { i = Math.floor(Math.random() * PRAISE_KEYS.length); guard++; } while (i === lastPraiseIdx && guard < 10);
  lastPraiseIdx = i;
  return { audio: UA[PRAISE_KEYS[i]] || UA.great, text: PRAISE_TEXTS[i] };
}
function praiseCorrect(x, y, sayFirst) {
  combo++;
  var p = pickPraise();
  if (sayFirst) playAudio(UA[sayFirst] || sayFirst, function () { playAudio(p.audio); });
  else playAudio(p.audio);
  mascotCheer();
  praisePop(p.text + (combo >= 2 ? "   🔥x" + combo : ""));
  updateComboBadge();
  if (x != null) starBurst(x, y == null ? 200 : y);
  if (combo >= 3) miniConfetti();
}
function encourageWrong() {
  combo = 0; updateComboBadge();
  gameMistakes++;
  playAudio(Math.random() < 0.6 ? (Math.random() < 0.5 ? UA.vitry1 : UA.vitry2) : UA.tryagain);
  praisePop(TRY_TEXTS[Math.floor(Math.random() * TRY_TEXTS.length)], true);
}
function mascotCheer() {
  var m = $("#game-cheer");
  if (!m) return;
  m.classList.add("show");
  var img = m.querySelector("img");
  if (img) { img.classList.remove("dance"); void img.offsetWidth; img.classList.add("dance"); }
  clearTimeout(m._t);
  m._t = setTimeout(function () { m.classList.remove("show"); }, 2300);
}
function praisePop(text, gentle) {
  var el = $("#praise-pop");
  if (!el) { el = document.createElement("div"); el.id = "praise-pop"; document.body.appendChild(el); }
  el.textContent = text;
  el.classList.toggle("gentle", !!gentle);
  el.classList.remove("show"); void el.offsetWidth; el.classList.add("show");
}
function updateComboBadge() {
  var b = $("#combo-badge");
  if (!b) return;
  if (combo >= 2) { b.textContent = "🔥 LIÊN TIẾP x" + combo; b.classList.add("show"); }
  else b.classList.remove("show");
}
function miniConfetti() {
  var icons = ["⭐", "✨", "🌟"], i;
  for (i = 0; i < 12; i++) {
    var c = document.createElement("div");
    c.className = "confetti"; c.textContent = icons[i % 3];
    c.style.left = (Math.random() * 100) + "vw";
    c.style.fontSize = (16 + Math.random() * 14) + "px";
    c.style.animationDuration = (1.6 + Math.random()) + "s";
    document.body.appendChild(c);
    (function (el) { setTimeout(function () { el.remove(); }, 2800); })(c);
  }
}
function resetCombo() { combo = 0; updateComboBadge(); }

// ---------- Chấm điểm /10 + xếp loại ----------
function gradeOf(s10) {
  if (s10 >= 9) return { t: "Xuất sắc", e: "🏆" };
  if (s10 >= 7) return { t: "Giỏi", e: "🌟" };
  if (s10 >= 5) return { t: "Khá", e: "👍" };
  if (s10 >= 3) return { t: "Cần cố gắng", e: "💪" };
  return { t: "Đừng nản chí", e: "🌱" };
}
function saveGameScore(gid, score10) {
  var k = "score:" + gid;
  if ((store.data.gameScores[k] || 0) < score10) { store.data.gameScores[k] = score10; store.save(); }
}

// ============================================================
// ĐỘNG CƠ VẼ CHUNG: Pointer Events + undo stack
// ============================================================
// WebView cổ (Chrome < 41) KHÔNG có Pointer Events -> pointerdown/move/up không
// bao giờ chạy, bé chạm vào canvas vẽ không ăn. attachDraw bên dưới tự gắn thêm
// bộ nghe touch/mouse dự phòng khi thiếu Pointer Events (pattern như cụm photo),
// tái dùng đúng logic vẽ. Chỉ gắn khi thiếu -> máy mới không vẽ đúp nét.
var HAS_POINTER = ("onpointerdown" in window) && (typeof window.PointerEvent !== "undefined");
function attachDraw(cv, getStyle, onStrokeStart, extra) {
  var ctx = cv.getContext("2d");
  if (!ctx) return null;
  var drawing = false, lx = 0, ly = 0;
  function pos(e) {
    // touch event: lấy ngón chạm đầu tiên; pointer/mouse giữ nguyên clientX/Y
    var cx = e.clientX, cy = e.clientY;
    var t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]);
    if (t) { cx = t.clientX; cy = t.clientY; }
    var r = cv.getBoundingClientRect();
    var w = r.width || 1, h = r.height || 1;
    return [(cx - r.left) * cv.width / w, (cy - r.top) * cv.height / h];
  }
  function applyStyle() {
    var st = getStyle();
    ctx.strokeStyle = st.color; ctx.lineWidth = st.width;
    ctx.lineCap = "round"; ctx.lineJoin = "round";
  }
  // extra: hàm tùy chọn trả về { mirror:bool, stampCanvas:canvas|null }
  // (màn Vẽ tự do dùng cho chế độ đối xứng + cọ hình; các màn khác không truyền -> vẽ thường)
  function fx() { return (typeof extra === "function") ? (extra() || {}) : {}; }
  function strokeSeg(x1, y1, x2, y2) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    if (fx().mirror) {
      var W = cv.width;
      ctx.beginPath(); ctx.moveTo(W - x1, y1); ctx.lineTo(W - x2, y2); ctx.stroke();
    }
  }
  function stampAt(x, y) {
    var f = fx(), im = f.stampCanvas;
    if (!im) return;
    var hw = im.width / 2, hh = im.height / 2;
    ctx.drawImage(im, x - hw, y - hh);
    if (f.mirror) ctx.drawImage(im, (cv.width - x) - hw, y - hh);
  }
  // Logic vẽ dùng chung cho pointer, touch và mouse: không viết lại, chỉ gọi lại
  // (nét vẽ, đối xứng, cọ hình y hệt nhau ở mọi màn hình dùng attachDraw)
  function downAt(p) {
    drawing = true; lx = p[0]; ly = p[1];
    if (onStrokeStart) onStrokeStart();
    applyStyle();
    if (fx().stampCanvas) stampAt(lx, ly);
    else strokeSeg(lx, ly, lx + 0.1, ly + 0.1);
  }
  function moveAt(p) {
    if (!drawing) return;
    applyStyle();
    var f = fx();
    if (f.stampCanvas) {
      // chế độ cọ hình: đóng dấu cách nhau ~24px dọc đường rê tay
      var dx = p[0] - lx, dy = p[1] - ly;
      var dist = Math.sqrt(dx * dx + dy * dy), step = 24, d = step;
      while (d <= dist) {
        stampAt(lx + dx * d / dist, ly + dy * d / dist);
        d += step;
      }
      lx = p[0]; ly = p[1];
    } else {
      strokeSeg(lx, ly, p[0], p[1]);
      lx = p[0]; ly = p[1];
    }
  }
  function end() { drawing = false; }
  cv.addEventListener("pointerdown", function (e) {
    if (e.preventDefault) e.preventDefault();
    try { cv.setPointerCapture(e.pointerId); } catch (err) {}
    downAt(pos(e));
  });
  cv.addEventListener("pointermove", function (e) {
    if (e.preventDefault) e.preventDefault();
    moveAt(pos(e));
  });
  cv.addEventListener("pointerup", end);
  cv.addEventListener("pointercancel", end);
  if (!HAS_POINTER) {
    // Dự phòng WebView cổ: touchstart/move/end + mousedown/move/up (cho chuột).
    // touchmove chặn cuộn trang; addEventListener dạng thường (không options
    // {passive}) để WebView cổ parse được. Máy mới có Pointer Events nên
    // nhánh này không chạy -> không vẽ đúp nét.
    cv.addEventListener("touchstart", function (e) {
      if (e.preventDefault) e.preventDefault();
      downAt(pos(e));
    });
    cv.addEventListener("touchmove", function (e) {
      if (e.preventDefault) e.preventDefault();
      moveAt(pos(e));
    });
    cv.addEventListener("touchend", end);
    cv.addEventListener("touchcancel", end);
    cv.addEventListener("mousedown", function (e) { downAt(pos(e)); });
    cv.addEventListener("mousemove", function (e) { moveAt(pos(e)); });
    cv.addEventListener("mouseup", end);
  }
  return ctx;
}
// Undo stack: chụp nhanh canvas trước mỗi nét vẽ
function makeUndo(cv, max) {
  var stack = [];
  return {
    push: function () {
      try { stack.push(cv.toDataURL()); } catch (e) {}
      if (stack.length > (max || 12)) stack.shift();
    },
    undo: function () {
      var ctx = cv.getContext("2d");
      if (!ctx) return false;
      if (!stack.length) return false;
      var url = stack.pop();
      var img = new Image();
      img.onload = function () {
        ctx.clearRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0);
      };
      img.onerror = function () {};
      img.src = url;
      return true;
    },
    clear: function () { stack = []; },
    size: function () { return stack.length; }
  };
}

// ============================================================
// VẼ TỰ DO
// ============================================================
var freeColor = "#E53935", freeWidth = 10, freeEraser = false, freeUndo = null;
// --- v1.3b: vẽ đối xứng / cọ hình / nền màu (chỉ màn Vẽ tự do) ---
var freeMirror = false, freeStampMode = false, freeStampShape = 0, freeBg = "#FFFFFF";
var stampCanvases = [];
function freeStyle() {
  return { color: freeEraser ? freeBg : freeColor, width: freeEraser ? freeWidth * 2.2 : freeWidth };
}
// Vẽ trước mỗi hình stamp ra offscreen canvas 64x64 với màu hiện tại (gọi lại khi đổi màu)
function paintStamp(i, color) {
  var c = document.createElement("canvas"); c.width = 64; c.height = 64;
  var x = c.getContext("2d");
  if (!x) return c;
  x.fillStyle = color;
  if (i === 0) { // ngôi sao
    x.beginPath();
    x.moveTo(32, 8); x.lineTo(39, 25); x.lineTo(57, 25); x.lineTo(42, 36);
    x.lineTo(47, 53); x.lineTo(32, 43); x.lineTo(17, 53); x.lineTo(22, 36);
    x.lineTo(7, 25); x.lineTo(25, 25);
    x.closePath(); x.fill();
  } else if (i === 1) { // trái tim: 2 hình tròn + tam giác (không dùng bezier cho chắc)
    x.beginPath(); x.arc(23, 25, 11, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.arc(41, 25, 11, 0, Math.PI * 2); x.fill();
    x.beginPath();
    x.moveTo(13, 30); x.lineTo(51, 30); x.lineTo(32, 56);
    x.closePath(); x.fill();
  } else if (i === 2) { // bông hoa
    var a, ang;
    for (a = 0; a < 5; a++) {
      ang = a * Math.PI * 2 / 5 - Math.PI / 2;
      x.beginPath(); x.arc(32 + 14 * Math.cos(ang), 32 + 14 * Math.sin(ang), 10, 0, Math.PI * 2); x.fill();
    }
    x.beginPath(); x.arc(32, 32, 9, 0, Math.PI * 2); x.fill();
  } else { // chấm bi
    x.beginPath(); x.arc(32, 32, 15, 0, Math.PI * 2); x.fill();
  }
  return c;
}
function renderStamps() {
  var col = freeEraser ? freeBg : freeColor, i;
  stampCanvases = [];
  for (i = 0; i < 4; i++) stampCanvases.push(paintStamp(i, col));
}
function freeExtra() {
  return { mirror: freeMirror, stampCanvas: freeStampMode ? stampCanvases[freeStampShape] : null };
}
// Ẩn/hiện ảnh mẫu phía trên canvas Vẽ tự do (giữ lại cho initFree;
// tính năng "Mẫu vẽ từ link ảnh" đã gỡ, nên hàm này giờ chỉ dùng để ẩn ảnh)
function setFreeRef(url) {
  var im = $("#free-ref"); if (!im) return;
  if (url) { im.src = url; im.style.display = "block"; }
  else { im.removeAttribute("src"); im.style.display = "none"; }
}
function initFree() {
  setFreeRef(null); // mở từ trang chủ: không hiện ảnh mẫu cũ
  var cv = $("#free-canvas");
  var ctx = cv.getContext("2d");
  if (ctx) { ctx.fillStyle = freeBg; ctx.fillRect(0, 0, cv.width, cv.height); }
  freeUndo = makeUndo(cv, 12);
  // Chỉ gắn listener vẽ ĐÚNG 1 lần: initFree chạy mỗi lần mở màn hình,
  // gắn lại sẽ cộng dồn handler -> mỗi nét vẽ kích hoạt N lần
  // (nét đậm dần, undo phải bấm N lần mới xóa 1 nét).
  if (!cv._drawWired) { attachDraw(cv, freeStyle, function () { freeUndo.push(); }, freeExtra); cv._drawWired = true; }
  renderStamps();
  // bảng màu
  var pal = $("#free-palette"); pal.innerHTML = "";
  for (var i = 0; i < COLORS.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "swatch" + (c.hex === freeColor && !freeEraser ? " sel" : "");
      b.style.background = c.hex;
      b.setAttribute("aria-label", c.name);
      b.addEventListener("click", function () {
        freeColor = c.hex; freeEraser = false;
        var ss = pal.querySelectorAll(".swatch"), k;
        for (k = 0; k < ss.length; k++) ss[k].classList.remove("sel");
        b.classList.add("sel");
        $("#free-eraser").classList.remove("sel");
        renderStamps(); // v1.3b: cọ hình theo màu mới
        playAudio(UA.dr_palette);
      });
      pal.appendChild(b);
    })(COLORS[i]);
  }
  // cỡ cọ
  var sizes = [6, 10, 16, 24], szw = $("#free-sizes");
  szw.innerHTML = "";
  for (var s = 0; s < sizes.length; s++) {
    (function (w) {
      var b = document.createElement("button");
      b.className = "brush-size" + (w === freeWidth ? " sel" : "");
      b.innerHTML = '<span class="dot" style="width:' + w + 'px;height:' + w + 'px"></span>';
      b.setAttribute("aria-label", "Cỡ cọ");
      b.addEventListener("click", function () {
        freeWidth = w;
        var bs = szw.querySelectorAll(".brush-size"), k;
        for (k = 0; k < bs.length; k++) bs[k].classList.remove("sel");
        b.classList.add("sel");
        playAudio(UA.dr_brush);
      });
      szw.appendChild(b);
    })(sizes[s]);
  }
  $("#free-eraser").classList.toggle("sel", freeEraser);
}
$("#free-eraser").addEventListener("click", function () {
  freeEraser = !freeEraser;
  $("#free-eraser").classList.toggle("sel", freeEraser);
  renderStamps(); // v1.3b: cọ hình tẩy theo màu nền
  playAudio(UA.dr_eraser);
});
$("#free-undo").addEventListener("click", function () {
  if (freeUndo && freeUndo.undo()) { playAudio(UA.dr_undo); }
  else toast("Hết bước để quay lại rồi! 🙂");
});
$("#free-clear").addEventListener("click", function () {
  var cv = $("#free-canvas"), ctx = cv.getContext("2d");
  if (ctx) { ctx.fillStyle = freeBg; ctx.fillRect(0, 0, cv.width, cv.height); }
  if (freeUndo) freeUndo.clear();
  playAudio(UA.dr_clear, function () { playAudio(UA.dr_cleared_ok); });
  toast("Đã xóa sạch! 🧹");
});
$("#free-guide").addEventListener("click", function () { playAudio(UA.guide_free); });
$("#free-save").addEventListener("click", function () {
  playAudio(UA.dr_save);
  var url = canvasThumb($("#free-canvas"), 240);
  var it = url && addGalleryItem(url);
  if (it) {
    playAudio(UA.dr_saved_ok);
    askGalleryName(it); // v1.1: cho bé đặt tên tranh
  } else toast("Chưa lưu được, bé thử lại nhé! 😢");
});
// ---- v1.3b: Vẽ đối xứng / Cọ hình / Nền màu ----
$("#free-mirror").addEventListener("click", function () {
  freeMirror = !freeMirror;
  $("#free-mirror").classList.toggle("sel", freeMirror);
  if (freeMirror) playAudio(UA.dr_mirror);
});
$("#free-stamp").addEventListener("click", function () {
  freeStampMode = !freeStampMode;
  $("#free-stamp").classList.toggle("sel", freeStampMode);
  var row = $("#free-stamp-shapes");
  if (row) row.style.display = freeStampMode ? "flex" : "none";
  if (freeStampMode) { renderStamps(); playAudio(UA.dr_stamp); }
});
(function () {
  var btns = document.querySelectorAll("#free-stamp-shapes .shape-btn"), i;
  for (i = 0; i < btns.length; i++) {
    (function (b) {
      b.addEventListener("click", function () {
        freeStampShape = parseInt(b.getAttribute("data-shape"), 10) || 0;
        for (var k = 0; k < btns.length; k++) btns[k].classList.remove("sel");
        b.classList.add("sel");
      });
    })(btns[i]);
  }
  var bgs = document.querySelectorAll("#free-bg-row .bg-swatch"), j;
  for (j = 0; j < bgs.length; j++) {
    (function (b) {
      b.addEventListener("click", function () {
        var hex = b.getAttribute("data-bg") || "#FFFFFF";
        freeBg = hex;
        for (var k = 0; k < bgs.length; k++) bgs[k].classList.remove("sel");
        b.classList.add("sel");
        var cv = $("#free-canvas"), ctx = cv.getContext("2d");
        if (ctx) { ctx.fillStyle = hex; ctx.fillRect(0, 0, cv.width, cv.height); }
        // reset undo: nền mới là điểm xuất phát (tránh undo ra nền cũ gây nhầm)
        if (freeUndo) { freeUndo.clear(); freeUndo.push(); }
        renderStamps(); // tẩy theo màu nền mới
        playAudio(UA.dr_bg);
      });
    })(bgs[j]);
  }
})();
// thumbnail JPEG ~240px, nền trắng
function canvasThumb(cv, w) {
  try {
    var th = document.createElement("canvas");
    th.width = w; th.height = Math.round(w * cv.height / cv.width) || w;
    var tctx = th.getContext("2d");
    if (!tctx) return null;
    tctx.fillStyle = "#FFFFFF"; tctx.fillRect(0, 0, th.width, th.height);
    tctx.drawImage(cv, 0, 0, th.width, th.height);
    return th.toDataURL("image/jpeg", 0.72);
  } catch (e) { return null; }
}

// ============================================================
// HỌC VẼ TỪNG BƯỚC
// ============================================================
var curLesson = null, curStep = 0;
function renderStepsList() {
  var box = $("#steps-list"); box.innerHTML = "";
  for (var i = 0; i < STEP_LESSONS.length; i++) {
    (function (L) {
      var done = store.data.lessonsDone[L.id];
      var b = document.createElement("button");
      b.className = "lesson-card";
      b.innerHTML = '<span class="emoji">' + L.emoji + '</span>' +
        '<span class="lname">' + L.name + '</span>' +
        '<span class="lmeta">' + L.steps.length + ' bước' + (done ? ' · ✅' : '') + '</span>';
      b.addEventListener("click", function () { openLesson(L.id); });
      box.appendChild(b);
    })(STEP_LESSONS[i]);
  }
}
function openLesson(id) {
  var L = lessonById(id);
  if (!L) return;
  curLesson = L; curStep = 0;
  renderStep();
  showScreen("screen-steps", true, function () {
    // Render (renderStep) đã xong đồng bộ ở trên -> chuỗi audio chạy nền.
    playAudio(UA.nav_steps, function () {
      playAudio(UA[L.audio], function () { playAudio(UA.buoc_1); });
    });
  });
}
function renderStep() {
  var L = curLesson, n = L.steps.length, i;
  $("#step-title").textContent = L.emoji + " " + L.name;
  var dots = $("#step-dots"); dots.innerHTML = "";
  for (i = 0; i < n; i++) {
    var d = document.createElement("div");
    d.className = "dot" + (i < curStep ? " seen" : "") + (i === curStep ? " now" : "");
    dots.appendChild(d);
  }
  $("#step-desc").textContent = L.steps[curStep].t;
  // SVG: các bước trước vẽ nét liền, bước hiện tại vẽ nét đứt mờ
  var inner = "", k;
  for (k = 0; k < curStep; k++) {
    inner += '<g class="stp-done">' + L.steps[k].svg + "</g>";
  }
  inner += '<g class="stp-now">' + L.steps[curStep].svg + "</g>";
  $("#step-svg").innerHTML = inner;
  var cv = $("#step-canvas");
  var ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
  $("#step-next").textContent = curStep === n - 1 ? "Hoàn thành 🎉" : "Bước tiếp ▶";
}
$("#step-clear").addEventListener("click", function () {
  var cv = $("#step-canvas"), ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
});
$("#step-next").addEventListener("click", function () {
  var L = curLesson; if (!L) return;
  var cv = $("#step-canvas"), ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
  if (curStep < L.steps.length - 1) {
    curStep++;
    renderStep();
    playAudio(UA.step_done, function () {
      var bk = "buoc_" + (curStep + 1);
      if (UA[bk]) playAudio(UA[bk]);
    });
  } else {
    var first = !store.data.lessonsDone[L.id];
    store.data.lessonsDone[L.id] = true;
    if (first) { addStars(1); bumpStreak(); }
    store.save();
    playAudio(UA.lesson_done, function () {
      var p = pickPraise(); playAudio(p.audio);
    });
    confetti();
    toast("🎉 Bé vẽ xong " + L.name + " rồi! +1 ⭐");
    renderStepsList();
    goBack();
  }
});
function initStepCanvas() {
  attachDraw($("#step-canvas"), function () { return { color: "#FF7043", width: 12 }; }, null);
}

// ============================================================
// TÔ MÀU
// ============================================================
var colorPage = null, colorPick = "#E53935";
function renderColoringList() {
  var box = $("#coloring-list"); box.innerHTML = "";
  for (var i = 0; i < COLORING_PAGES.length; i++) {
    (function (P) {
      var b = document.createElement("button");
      b.className = "lesson-card";
      b.innerHTML = '<span class="emoji">' + P.emoji + '</span>' +
        '<span class="lname">' + P.name + '</span>' +
        '<span class="lmeta">Chạm để tô 🖍️</span>';
      b.addEventListener("click", function () { openColoring(P.id); });
      box.appendChild(b);
    })(COLORING_PAGES[i]);
  }
}
function openColoring(id) {
  var P = coloringById(id);
  if (!P) return;
  colorPage = P;
  $("#coloring-title").textContent = P.emoji + " " + P.name;
  var svg = $("#coloring-svg");
  svg.setAttribute("viewBox", "0 0 300 300");
  svg.innerHTML = P.svg;
  var regs = svg.querySelectorAll("[data-r]"), i;
  for (i = 0; i < regs.length; i++) {
    regs[i].setAttribute("fill", "#FFFFFF");
    regs[i].setAttribute("stroke", "#37474F");
    regs[i].setAttribute("stroke-width", "5");
    regs[i].setAttribute("stroke-linejoin", "round");
  }
  var pal = $("#color-palette"); pal.innerHTML = "";
  for (i = 0; i < COLORS.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "swatch" + (c.hex === colorPick ? " sel" : "");
      b.style.background = c.hex;
      b.setAttribute("aria-label", c.name);
      b.addEventListener("click", function () {
        colorPick = c.hex;
        var ss = pal.querySelectorAll(".swatch"), k;
        for (k = 0; k < ss.length; k++) ss[k].classList.remove("sel");
        b.classList.add("sel");
        playAudio(UA[c.audio]);
      });
      pal.appendChild(b);
    })(COLORS[i]);
  }
  showScreen("screen-coloring", true, function () {
    playAudio(UA.nav_coloring, function () {
      playAudio(UA.guide_coloring, function () {
        // v1.1: tranh mới có audio đọc tên tranh (vd "Tranh con ong.")
        if (P.audio && UA[P.audio]) playAudio(UA[P.audio]);
      });
    });
  });
}
$("#coloring-stage").addEventListener("click", function (e) {
  var t = e.target;
  if (!t || !t.getAttribute) return;
  var r = (t.getAttribute("data-r")) ? t : (t.closest ? t.closest("[data-r]") : null);
  if (!r) return;
  var rid = r.getAttribute("data-r");
  var svg = $("#coloring-svg");
  var same = svg.querySelectorAll('[data-r="' + rid + '"]'), i;
  for (i = 0; i < same.length; i++) same[i].setAttribute("fill", colorPick);
});
$("#coloring-clear").addEventListener("click", function () {
  var svg = $("#coloring-svg");
  var regs = svg.querySelectorAll("[data-r]"), i;
  for (i = 0; i < regs.length; i++) regs[i].setAttribute("fill", "#FFFFFF");
  toast("Đã xóa màu! 🧹");
});
$("#coloring-save").addEventListener("click", function () {
  playAudio(UA.dr_save);
  var svg = $("#coloring-svg");
  try {
    var xml = new XMLSerializer().serializeToString(svg);
    // Gắn kích thước cụ thể cho SVG: SVG chỉ có viewBox mà thiếu width/height
    // khi raster qua <img> có thể bị lấy cỡ mặc định rồi kéo méo khi drawImage.
    xml = xml.replace("<svg", '<svg width="600" height="600"');
    var img = new Image();
    img.onload = function () {
      try {
        var cv = document.createElement("canvas");
        cv.width = 600; cv.height = 600;
        var ctx = cv.getContext("2d");
        ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, 0, 600, 600);
        ctx.drawImage(img, 0, 0, 600, 600);
        var url = cv.toDataURL("image/jpeg", 0.72);
        var it = addGalleryItem(url);
        if (it) {
          playAudio(UA.dr_saved_ok);
          askGalleryName(it); // v1.1: cho bé đặt tên tranh
        } else toast("Chưa lưu được, bé thử lại nhé! 😢");
      } catch (e2) { toast("Chưa lưu được, bé thử lại nhé! 😢"); }
    };
    img.onerror = function () { toast("Chưa lưu được, bé thử lại nhé! 😢"); };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
  } catch (e) { toast("Chưa lưu được, bé thử lại nhé! 😢"); }
});

// ============================================================
// TÔ NÉT (đồ theo nét đứt + chấm % phủ nét)
// ============================================================
var curTrace = null;
function renderTraceList() {
  var box = $("#trace-list"); box.innerHTML = "";
  for (var i = 0; i < TRACE_ITEMS.length; i++) {
    (function (T) {
      var done = store.data.traceDone[T.id];
      var b = document.createElement("button");
      b.className = "lesson-card";
      b.innerHTML = '<span class="emoji">' + (T.emoji || "〰️") + '</span>' +
        '<span class="lname">' + T.name + '</span>' +
        '<span class="lmeta">' + (done ? '✅ Đã tô đẹp' : 'Chạm để tô') + '</span>';
      b.addEventListener("click", function () { openTrace(T.id); });
      box.appendChild(b);
    })(TRACE_ITEMS[i]);
  }
}
// dựng path nét đứt từ pts
function tracePathD(T) {
  var d = "", s, p, i, j;
  for (s = 0; s < T.pts.length; s++) {
    p = T.pts[s].slice();
    if (T.closed && p.length > 1) p.push(p[0]);
    for (j = 0; j < p.length; j++) {
      d += (j === 0 ? "M" : "L") + Math.round(p[j][0]) + "," + Math.round(p[j][1]);
    }
  }
  return d;
}
function openTrace(id) {
  var T = traceById(id);
  if (!T) return;
  curTrace = T;
  $("#trace-title").textContent = "〰️ " + T.name;
  var svg = $("#trace-svg");
  svg.setAttribute("viewBox", "0 0 300 300");
  svg.innerHTML = '<path d="' + tracePathD(T) + '" class="trace-guide"/>';
  var cv = $("#trace-canvas");
  var ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
  // Chỉ gắn 1 lần (xem chú thích ở initFree): openTrace chạy mỗi lần mở mẫu.
  if (!cv._drawWired) { attachDraw(cv, function () { return { color: "#FF7043", width: 20 }; }, null); cv._drawWired = true; }
  showScreen("screen-trace", true, function () {
    playAudio(UA.nav_trace, function () {
      playAudio(UA.guide_trace, function () {
        // v1.1: chữ cái mới có audio đọc tên chữ (vd "Chữ a.")
        if (T.audio && UA[T.audio]) playAudio(UA[T.audio]);
      });
    });
  });
}
$("#trace-clear").addEventListener("click", function () {
  var cv = $("#trace-canvas"), ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
});
// nội suy điểm dày dọc các nét để chấm phủ
function traceSamples(T) {
  var out = [], s, p, i, a, b, dx, dy, len, steps, k;
  for (s = 0; s < T.pts.length; s++) {
    p = T.pts[s].slice();
    if (T.closed && p.length > 1) p.push([p[0][0], p[0][1]]);
    for (i = 0; i < p.length - 1; i++) {
      a = p[i]; b = p[i + 1];
      dx = b[0] - a[0]; dy = b[1] - a[1];
      len = Math.sqrt(dx * dx + dy * dy);
      steps = Math.max(1, Math.round(len / 7));
      for (k = 0; k <= steps; k++) out.push([a[0] + dx * k / steps, a[1] + dy * k / steps]);
    }
  }
  return out;
}
// % điểm mẫu có nét vẽ của bé phủ gần (bán kính R px trên canvas 600)
function traceCoverage(cv, T) {
  var ctx = cv.getContext("2d");
  if (!ctx) return 0;
  var W = cv.width, H = cv.height, img;
  try { img = ctx.getImageData(0, 0, W, H); } catch (e) { return 0; }
  var d = img.data, R = 26, R2 = R * R;
  var samples = traceSamples(T), hit = 0, i, sx, sy, dx, dy, x, y, found;
  var sxr, syr;
  for (i = 0; i < samples.length; i++) {
    // điểm mẫu theo viewBox 300 -> canvas W
    sxr = Math.round(samples[i][0] / 300 * W);
    syr = Math.round(samples[i][1] / 300 * H);
    found = false;
    for (dy = -R; dy <= R && !found; dy += 4) {
      for (dx = -R; dx <= R && !found; dx += 4) {
        if (dx * dx + dy * dy > R2) continue;
        x = sxr + dx; y = syr + dy;
        if (x < 0 || y < 0 || x >= W || y >= H) continue;
        if (d[(y * W + x) * 4 + 3] > 40) found = true;
      }
    }
    if (found) hit++;
  }
  return samples.length ? hit / samples.length : 0;
}
$("#trace-check").addEventListener("click", function () {
  if (!curTrace) return;
  var cov = traceCoverage($("#trace-canvas"), curTrace);
  var pct = Math.round(cov * 100);
  if (cov >= 0.8) {
    var first = !store.data.traceDone[curTrace.id];
    store.data.traceDone[curTrace.id] = true;
    if (first) { addStars(1); bumpStreak(); }
    store.save();
    var p = pickPraise();
    playAudio(p.audio);
    mascotCheer(); praisePop("Bé tô đẹp " + pct + "%! " + p.text);
    confetti();
    toast("⭐ +1 Bé tô nét siêu đẹp!");
    renderTraceList();
  } else {
    playAudio(Math.random() < 0.5 ? UA.vitry1 : UA.vitry2);
    praisePop("Bé mới tô được " + pct + "%, tô kín nét đứt nhé! 💪", true);
  }
});
$("#trace-say").addEventListener("click", function () { playAudio(UA.guide_trace); });

// ============================================================
// HỌC MÀU SẮC (chạm nghe tên + pha màu)
// ============================================================
function renderColors() {
  var grid = $("#colors-grid"); grid.innerHTML = "";
  for (var i = 0; i < COLORS.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "color-card";
      b.innerHTML = '<span class="cc-dot" style="background:' + c.hex + '"></span>' +
        '<span class="cc-name">' + c.name + '</span>' +
        '<span class="cc-say">🔊</span>';
      b.addEventListener("click", function () { playAudio(UA[c.audio]); });
      grid.appendChild(b);
    })(COLORS[i]);
  }
  var mix = $("#mix-list"); mix.innerHTML = "";
  for (var m = 0; m < MIX_COMBOS.length; m++) {
    (function (cb) {
      var A = colorById(cb.a), B = colorById(cb.b), R = colorById(cb.r);
      var card = document.createElement("button");
      card.className = "mix-card";
      card.innerHTML =
        '<span class="mix-blob" style="background:' + A.hex + '"></span>' +
        '<span class="mix-plus">+</span>' +
        '<span class="mix-blob" style="background:' + B.hex + '"></span>' +
        '<span class="mix-plus">=</span>' +
        '<span class="mix-blob mix-result" style="background:#FFFFFF">?</span>';
      card.addEventListener("click", function () {
        var res = card.querySelector(".mix-result");
        res.style.background = R.hex;
        res.textContent = "";
        // chạm vào kết quả -> đọc CẢ CÂU pha màu
        playAudio(UA[cb.sAudio] || UA[cb.audio]);
        mascotCheer();
      });
      mix.appendChild(card);
    })(MIX_COMBOS[m]);
  }
}
$("#mix-game-btn").addEventListener("click", function () { startGame("mix"); });

// ============================================================
// HỌC HÌNH KHỐI
// ============================================================
function renderShapes() {
  var grid = $("#shapes-grid"); grid.innerHTML = "";
  for (var i = 0; i < SHAPES.length; i++) {
    (function (S) {
      var b = document.createElement("button");
      b.className = "shape-card";
      b.innerHTML = '<svg viewBox="0 0 100 100" class="shape-svg">' + S.svg + "</svg>" +
        '<span class="cc-name">' + S.name + '</span>' +
        '<span class="cc-ex">💡 ' + S.ex + "</span>" +
        '<span class="cc-say">🔊 Nghe tên</span>';
      b.addEventListener("click", function () { playAudio(UA[S.audio]); });
      grid.appendChild(b);
    })(SHAPES[i]);
  }
}

// ============================================================
// TRÒ CHƠI (7 game)
// ============================================================
var GAMES = [
  { id: "choice",    name: "Nghe và chọn màu", sub: "Nghe tên màu rồi chạm đúng", emoji: "🎨" },
  { id: "oddone",    name: "Hình khác loại",   sub: "Tìm hình không giống các hình kia", emoji: "🔍" },
  { id: "truefalse", name: "Đúng hay Sai",     sub: "Nghe câu nói đúng hay sai", emoji: "✅" },
  { id: "memory",    name: "Trí nhớ",          sub: "Lật thẻ tìm cặp giống nhau", emoji: "🃏" },
  { id: "count",     name: "Đếm hình",         sub: "Đếm rồi chọn số đúng", emoji: "🔢" },
  { id: "mix",       name: "Pha màu",          sub: "Đoán màu khi trộn hai màu", emoji: "🌈" },
  { id: "art",       name: "Đố vui hội họa",   sub: "Trả lời câu hỏi về màu sắc", emoji: "🖌️" }
];
var ROUNDS = 8;
var gameId = null, gameRound = 0, gameScore = 0, gameMax = 8;
var curIntro = null, curGuide = null;
function gameById(id) {
  for (var i = 0; i < GAMES.length; i++) if (GAMES[i].id === id) return GAMES[i];
  return null;
}
function renderGames() {
  var box = $("#game-list"); box.innerHTML = "";
  for (var i = 0; i < GAMES.length; i++) {
    (function (g) {
      var keys = Object.keys(store.data.gameBest).filter(function (k) { return k.indexOf(g.id + ":") === 0; });
      var best = 0, k;
      for (k = 0; k < keys.length; k++) best = Math.max(best, store.data.gameBest[keys[k]]);
      var b = document.createElement("button");
      b.className = "game-card";
      b.innerHTML = '<span class="emoji">' + g.emoji + "</span>" +
        '<span><span class="gname">' + g.name + '</span><br><span class="gsub">' + g.sub + "</span></span>" +
        '<span class="gbest">' + (best ? starStr(best) : "") + "</span>";
      b.addEventListener("click", function () { startGame(g.id); });
      box.appendChild(b);
    })(GAMES[i]);
  }
}
function startGame(id) {
  var g = gameById(id);
  if (!g) return; // id lạ -> không render gì, tránh màn hình câu hỏi trắng
  gameId = id;
  // v1.1: game "art" dùng audio art_intro/art_guide (không có ui_art/guide_art)
  curIntro = UA["ui_" + id] || UA[id + "_intro"] || null;
  curGuide = UA["guide_" + id] || UA[id + "_guide"] || null;
  gameRound = 0; gameMistakes = 0; gameScore = 0;
  gameMax = id === "memory" ? ROUNDS * 4 : ROUNDS;
  resetCombo();
  showScreen("screen-game-play", false);
  replayPush("screen-game-play");
  // Render câu hỏi NGAY đồng bộ, không chờ intro/guide. Audio chạy nền fire-and-forget.
  nextRound();
  if (curIntro) playAudio(curIntro, function () { if (curGuide) playAudio(curGuide); });
  else if (curGuide) playAudio(curGuide);
}
function updateQProgress() {
  if (gameId === "daily") {
    $("#q-progress").textContent = "Thử thách " + (dailyIdx + 1) + "/" + dailyQueue.length + "   •   ⭐ " + gameScore + "   •   🔥" + streakCount();
    return;
  }
  $("#q-progress").textContent = "Câu " + Math.min(gameRound + 1, ROUNDS) + " / " + ROUNDS + "   •   ⭐ " + gameScore;
}
function qEnter() {
  var qa = $("#q-area");
  if (qa) { qa.classList.remove("q-enter"); void qa.offsetWidth; qa.classList.add("q-enter"); }
}
function lockOpts() {
  var os = $$("#q-area .opt"), i;
  for (i = 0; i < os.length; i++) os[i].style.pointerEvents = "none";
}
function promptHTML(bigQ) {
  return '<button class="speaker big" id="q-say">🔊</button><span class="big-q">' + bigQ + "</span>";
}
function renderItemQ(k) {
  updateQProgress();
  qEnter();
  if (k === "choice") gChoice();
  else if (k === "oddone") gOddone();
  else if (k === "truefalse") gTrueFalse();
  else if (k === "memory") gMemory();
  else if (k === "count") gCount();
  else if (k === "mix") gMix();
  else if (k === "art") gArt();
}
function roundAdvance() {
  if (gameId === "daily") { dailyIdx++; nextDaily(); return; }
  gameRound++; nextRound();
}
function nextRound() {
  if (gameRound >= ROUNDS) { showResult(); return; }
  renderItemQ(gameId);
}

// --- Game 1: NGHE VÀ CHỌN MÀU ---
function gChoice() {
  var target = pick(COLORS);
  var opts = shuffle([target].concat(shuffle(COLORS.filter(function (c) { return c.id !== target.id; })).slice(0, 3)));
  $("#q-prompt").innerHTML = promptHTML("Chạm vào màu bé vừa nghe nhé!");
  var area = $("#q-area");
  area.innerHTML = '<div class="opt-grid"></div>';
  var grid = area.querySelector(".opt-grid");
  for (var i = 0; i < opts.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "opt color-opt";
      if (c.id === target.id) b.setAttribute("data-ok", "1");
      b.innerHTML = '<span class="color-blob" style="background:' + c.hex + '"></span>';
      b.addEventListener("click", function (ev) {
        if (c.id === target.id) {
          b.classList.add("correct"); lockOpts(); gameScore++;
          praiseCorrect(ev.clientX, ev.clientY, target.audio);
          setTimeout(roundAdvance, 2300);
        } else {
          b.classList.add("wrong");
          encourageWrong();
          setTimeout(function () { b.classList.remove("wrong"); }, 600);
        }
      });
      grid.appendChild(b);
    })(opts[i]);
  }
  var say = function () { playAudio(UA[target.audio]); };
  $("#q-say").addEventListener("click", say);
  // narrate() nhận CHUỖI đường dẫn audio — truyền function sẽ thành new Audio(fn)
  // (URL rác, im lặng không phát). Sửa: truyền thẳng chuỗi src.
  narrate(UA[target.audio], 700);
}

// --- Game 2: HÌNH KHÁC LOẠI ---
function gOddone() {
  var major = pick(SHAPES);
  var minor = pick(SHAPES.filter(function (s) { return s.id !== major.id; }));
  var oddPos = rint(0, 3);
  $("#q-prompt").innerHTML = promptHTML("Hình nào khác loại?");
  var area = $("#q-area");
  area.innerHTML = '<div class="opt-grid"></div>';
  var grid = area.querySelector(".opt-grid");
  for (var i = 0; i < 4; i++) {
    (function (idx) {
      var S = idx === oddPos ? minor : major;
      var col = pick(COLORS);
      var b = document.createElement("button");
      b.className = "opt shape-opt";
      if (idx === oddPos) b.setAttribute("data-ok", "1");
      b.innerHTML = '<svg viewBox="0 0 100 100" class="shape-svg" style="fill:' + col.hex + '">' + S.svg + "</svg>";
      b.addEventListener("click", function (ev) {
        if (idx === oddPos) {
          b.classList.add("correct"); lockOpts(); gameScore++;
          praiseCorrect(ev.clientX, ev.clientY, minor.audio);
          setTimeout(roundAdvance, 2300);
        } else {
          b.classList.add("wrong");
          encourageWrong();
          setTimeout(function () { b.classList.remove("wrong"); }, 600);
        }
      });
      grid.appendChild(b);
    })(i);
  }
  var say = function () { playAudio(UA.guide_oddone); };
  $("#q-say").addEventListener("click", say);
  narrate(UA.guide_oddone, 700);
}

// --- Game 3: ĐÚNG HAY SAI ---
function gTrueFalse() {
  var tf = pick(TF_ITEMS);
  $("#q-prompt").innerHTML = promptHTML("Câu nói này đúng hay sai?");
  var area = $("#q-area");
  area.innerHTML = '<div class="tf-text">' + tf.text + "</div>" +
    '<div class="tf-row">' +
    '<button class="tf-btn yes" id="tf-yes">✅<span>Đúng</span></button>' +
    '<button class="tf-btn no" id="tf-no">❌<span>Sai</span></button>' +
    "</div>";
  var say = function () { playAudio(UA[tf.id]); };
  $("#q-say").addEventListener("click", say);
  narrate(UA[tf.id], 700);
  var answered = false;
  function answer(yes) {
    // Mỗi câu chỉ tính đúng 1 lần: không chặn, bé chạm lia lịa sẽ +nhiều điểm
    // và nhảy cóc câu. (Khóa bằng cờ JS thay vì CSS pointer-events để chắc chắn
    // chặn được mọi nguồn sự kiện.)
    if (answered) return;
    answered = true;
    if (yes === tf.ok) {
      gameScore++;
      praiseCorrect(window.innerWidth / 2, 200, tf.id);
    } else {
      encourageWrong();
    }
    setTimeout(roundAdvance, 2300);
  }
  $("#tf-yes").addEventListener("click", function () { answer(true); });
  $("#tf-no").addEventListener("click", function () { answer(false); });
}

// --- Game 4: TRÍ NHỚ (8 thẻ, 4 cặp) ---
function gMemory() {
  var items = shuffle(SHAPES).slice(0, 4);
  var deck = [];
  for (var i = 0; i < items.length; i++) { deck.push(items[i]); deck.push(items[i]); }
  deck = shuffle(deck);
  $("#q-prompt").innerHTML = promptHTML("Lật hai thẻ giống nhau nhé!");
  var area = $("#q-area");
  area.innerHTML = '<div class="mem-grid"></div>';
  var grid = area.querySelector(".mem-grid");
  var open = [], lock = false, found = 0;
  for (var c = 0; c < deck.length; c++) {
    (function (S, idx) {
      var col = COLORS[(idx + S.id.length) % COLORS.length];
      var b = document.createElement("button");
      b.className = "mem-card";
      b.setAttribute("data-key", S.id);
      b.innerHTML = '<span class="mem-back">❓</span>' +
        '<span class="mem-front"><svg viewBox="0 0 100 100" class="shape-svg" style="fill:' + col.hex + '">' + S.svg + "</svg></span>";
      b.addEventListener("click", function () {
        if (lock || b.classList.contains("flip") || b.classList.contains("done")) return;
        b.classList.add("flip");
        open.push({ el: b, key: S.id });
        if (open.length === 2) {
          if (open[0].key === open[1].key) {
            var r = b.getBoundingClientRect();
            open[0].el.classList.add("done"); open[1].el.classList.add("done");
            gameScore++; found++;
            praiseCorrect(r.left + r.width / 2, r.top, S.audio);
            open = [];
            updateQProgress();
            if (found === 4) setTimeout(roundAdvance, 2400);
          } else {
            lock = true;
            combo = 0; updateComboBadge();
            var a1 = open[0].el, a2 = open[1].el;
            open = [];
            setTimeout(function () {
              a1.classList.remove("flip"); a2.classList.remove("flip");
              lock = false;
            }, 800);
          }
        }
      });
      grid.appendChild(b);
    })(deck[c], c);
  }
  var say = function () { playAudio(UA.guide_memory); };
  $("#q-say").addEventListener("click", say);
  narrate(UA.guide_memory, 700);
}

// --- Game 5: ĐẾM HÌNH (khen bằng cnt_*) ---
var COUNT_EMOJI = ["⭐", "🌸", "🍎", "🐠", "🦋", "🎈", "🍓", "🐝"];
function gCount() {
  var n = rint(1, 10), em = pick(COUNT_EMOJI), i;
  $("#q-prompt").innerHTML = promptHTML("Đếm xem có bao nhiêu hình?");
  var area = $("#q-area");
  area.innerHTML = '<div class="count-box" id="count-box"></div><div class="chip-row" id="count-opts" style="justify-content:center"></div>';
  var box = area.querySelector("#count-box");
  for (i = 0; i < n; i++) {
    var s = document.createElement("span");
    s.className = "count-item";
    s.innerHTML = '<span style="font-size:44px">' + em + "</span>";
    box.appendChild(s);
  }
  var set = [n], guard = 0;
  while (set.length < 4 && guard++ < 60) {
    var c = n + rint(-3, 3);
    if (c >= 1 && c <= 10 && set.indexOf(c) < 0) set.push(c);
  }
  var row = area.querySelector("#count-opts");
  var opts = shuffle(set);
  for (i = 0; i < opts.length; i++) {
    (function (v) {
      var b = document.createElement("button");
      b.className = "wchip bignum-choice";
      if (v === n) b.setAttribute("data-ok", "1");
      b.textContent = v;
      b.addEventListener("click", function () {
        if (v === n) {
          gameScore++;
          var r = b.getBoundingClientRect();
          praiseCorrect(r.left + r.width / 2, r.top, "cnt_" + n);
          var os = row.querySelectorAll("button"), k;
          for (k = 0; k < os.length; k++) os[k].style.pointerEvents = "none";
          setTimeout(roundAdvance, 2300);
        } else {
          encourageWrong();
          b.classList.add("wrong");
          setTimeout(function () { b.classList.remove("wrong"); }, 600);
        }
      });
      row.appendChild(b);
    })(opts[i]);
  }
  var say = function () { playAudio(UA.guide_count); };
  $("#q-say").addEventListener("click", say);
  narrate(UA.guide_count, 700);
}

// --- Game 6: PHA MÀU ---
function gMix() {
  var cb = pick(MIX_COMBOS);
  var A = colorById(cb.a), B = colorById(cb.b), R = colorById(cb.r);
  var pool = shuffle(COLORS.filter(function (c) { return c.id !== R.id; })).slice(0, 3);
  var opts = shuffle([R].concat(pool));
  $("#q-prompt").innerHTML = promptHTML("Trộn hai màu này được màu gì?");
  var area = $("#q-area");
  area.innerHTML =
    '<div class="mix-q"><span class="mix-blob big" style="background:' + A.hex + '"></span>' +
    '<span class="mix-plus">+</span>' +
    '<span class="mix-blob big" style="background:' + B.hex + '"></span>' +
    '<span class="mix-plus">=</span><span class="mix-plus">?</span></div>' +
    '<div class="opt-grid" id="mix-opts"></div>';
  var grid = area.querySelector("#mix-opts");
  for (var i = 0; i < opts.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "opt color-opt";
      if (c.id === R.id) b.setAttribute("data-ok", "1");
      b.innerHTML = '<span class="color-blob" style="background:' + c.hex + '"></span>';
      b.addEventListener("click", function (ev) {
        if (c.id === R.id) {
          b.classList.add("correct"); lockOpts(); gameScore++;
          // v1.4: chạm vào kết quả đúng -> đọc CẢ CÂU pha màu (vd "Màu đỏ cộng màu trắng ra màu hồng phấn.")
          playAudio(UA[cb.sAudio] || UA[cb.audio], function () {
            var p = pickPraise(); playAudio(p.audio);
            praisePop(p.text);
          });
          combo++;
          updateComboBadge();
          mascotCheer();
          var r = b.getBoundingClientRect();
          starBurst(r.left + r.width / 2, r.top);
          setTimeout(roundAdvance, 2600);
        } else {
          b.classList.add("wrong");
          encourageWrong();
          setTimeout(function () { b.classList.remove("wrong"); }, 600);
        }
      });
      grid.appendChild(b);
    })(opts[i]);
  }
  var say = function () { playAudio(UA.guide_mix); };
  $("#q-say").addEventListener("click", say);
  narrate(UA.guide_mix, 700);
}

// --- Game 7: ĐỐ VUI HỘI HỌA (v1.1) ---
function gArt() {
  var Q = pick(ART_QUIZ);
  if (!Q) { roundAdvance(); return; }
  var order = shuffle([0, 1, 2]);
  $("#q-prompt").innerHTML = promptHTML(escHtml(Q.q));
  var area = $("#q-area");
  var h = '<div class="opt-grid">';
  for (var i = 0; i < 3; i++) {
    h += '<button class="opt" data-i="' + order[i] + '"><span class="word">' +
      escHtml(Q.choices[order[i]]) + "</span></button>";
  }
  h += "</div>";
  area.innerHTML = h;
  var say = function () { playAudio(UA[Q.audio]); };
  $("#q-say").addEventListener("click", say);
  narrate(UA[Q.audio], 700);
  var answered = false;
  var btns = area.querySelectorAll(".opt"), k;
  for (k = 0; k < btns.length; k++) {
    (function (b) {
      b.addEventListener("click", function (ev) {
        // Mỗi câu chỉ tính 1 lần (khóa như game Đúng/Sai)
        if (answered) return;
        answered = true;
        var chosen = parseInt(b.getAttribute("data-i"), 10);
        if (chosen === Q.answer) {
          b.classList.add("correct"); lockOpts(); gameScore++;
          praiseCorrect(ev.clientX || window.innerWidth / 2, ev.clientY || 200, Q.audio);
        } else {
          b.classList.add("wrong");
          encourageWrong();
        }
        setTimeout(roundAdvance, 2300);
      });
    })(btns[k]);
  }
}

// ============================================================
// KẾT QUẢ GAME THƯỜNG
// ============================================================
function showResult() {
  var stars = gameMistakes === 0 ? 3 : gameMistakes <= 2 ? 2 : 1;
  var key = gameId + ":all";
  if ((store.data.gameBest[key] || 0) < stars) store.data.gameBest[key] = stars;
  store.data.gamePlays++;
  addStars(stars);
  bumpStreak();
  $("#result-emoji").textContent = stars === 3 ? "🎉" : stars === 2 ? "😊" : "💪";
  $("#result-title").textContent = stars === 3 ? "Tuyệt vời!" : stars === 2 ? "Giỏi lắm!" : "Cố lên bé nhé!";
  $("#result-stars").innerHTML = starRow(stars);
  var score10 = Math.round(gameScore / Math.max(1, gameMax) * 10);
  var gr = gradeOf(score10);
  saveGameScore(gameId, score10);
  var g = gameById(gameId);
  $("#result-sub").innerHTML = gr.e + " <b>" + gr.t + "</b>!<br>" +
    (g ? g.name + ": " : "") + escHtml(kidName()) + " được <b>" + gameScore + "/" + gameMax + "</b> điểm" +
    " (thang 10: <b>" + score10 + "</b>), nhận " + stars + " ngôi sao!";
  showScreen("screen-result", false);
  navHistory.push("screen-result");
  playAudio(UA.great);
  if (score10 >= 7) confetti();
}
function starRow(stars) {
  var h = "", i;
  for (i = 1; i <= 3; i++) h += '<span class="' + (i <= stars ? "" : "off") + '">⭐</span>';
  return h;
}
// ES5: WebView cũ không có String.prototype.repeat -> TypeError -> trắng trang
// (renderGames, renderProgress). Dùng helper này thay cho "⭐".repeat(n).
function starStr(n) {
  var s = "", i;
  for (i = 0; i < n; i++) s += "⭐";
  return s;
}
$("#result-home").addEventListener("click", function () {
  var i = navHistory.lastIndexOf("screen-home");
  navHistory.length = i >= 0 ? i + 1 : 0;
  showScreen("screen-home");
});
$("#result-again").addEventListener("click", function () {
  if (gameId === "daily") { startDaily(); return; }
  startGame(gameId);
});

// ============================================================
// THỬ THÁCH NGÀY: 12 câu trộn 7 game
// ============================================================
var GAME6 = ["choice", "oddone", "truefalse", "memory", "count", "mix", "art"];
var dailyQueue = [], dailyIdx = 0, dailyMax = 12;
function startDaily() {
  var ks = shuffle(GAME6.concat(GAME6));
  dailyQueue = [];
  for (var i = 0; i < 12; i++) dailyQueue.push({ k: ks[i] });
  // Điểm tối đa THẬT của lượt này: câu memory = 4 điểm (4 cặp thẻ), các câu khác = 1.
  // dailyMax cứng = 18 trước đây sai 2 chỗ: perfect-run 12/12 (không có memory) chỉ
  // được 7/10, và màn hình kết quả hiện nhầm "/18 điểm" trong khi chỉ có 12 câu.
  dailyMax = 0;
  for (var m = 0; m < dailyQueue.length; m++) dailyMax += dailyQueue[m].k === "memory" ? 4 : 1;
  gameId = "daily";
  gameRound = 0; gameMistakes = 0; gameScore = 0; dailyIdx = 0;
  resetCombo();
  showScreen("screen-game-play", false);
  replayPush("screen-game-play");
  var intro = UA.ui_daily || UA.nav_daily;
  // Render câu hỏi 1 NGAY đồng bộ, không chờ intro. Audio chạy nền fire-and-forget.
  nextDaily();
  if (intro) playAudio(intro);
}
function nextDaily() {
  if (dailyIdx >= dailyQueue.length) { finishDaily(); return; }
  updateQProgress();
  qEnter();
  renderItemQ(dailyQueue[dailyIdx].k);
}
function finishDaily() {
  var streak = bumpStreak();
  var score10 = Math.round(gameScore / dailyMax * 10);
  var stars = gameMistakes === 0 ? 3 : gameMistakes <= 3 ? 2 : 1;
  var bonus = 2 + Math.min(streak, 5);
  var key = "daily:all";
  if ((store.data.gameBest[key] || 0) < stars) store.data.gameBest[key] = stars;
  store.data.gamePlays++;
  addStars(stars + bonus);
  var tk = todayStr(Date.now());
  if ((store.data.dailyBest[tk] || 0) < score10) { store.data.dailyBest[tk] = score10; store.save(); }
  $("#result-emoji").textContent = "📅";
  $("#result-title").textContent = "Xong thử thách ngày!";
  $("#result-stars").innerHTML = starRow(stars);
  var gr = gradeOf(score10);
  $("#result-sub").innerHTML = gr.e + " <b>" + gr.t + "</b>!<br>" +
    escHtml(kidName()) + " được <b>" + gameScore + "/" + dailyMax + "</b> điểm" +
    " (thang 10: <b>" + score10 + "</b>), 🔥 " + streak + " ngày liên tiếp, thưởng +" + bonus + " ⭐!";
  showScreen("screen-result", false);
  navHistory.push("screen-result");
  playAudio(UA.daily_done);
  confetti();
}

// ============================================================
// TÊN BÉ + AVATAR
// ============================================================
function kidName() { return (store.data.childName || "").trim() || "Bé"; }
function kidAvatar() { return store.data.childAvatar || "🐵"; }
var AVATARS = ["🐵", "🐱", "🐶", "🐰", "🦊", "🐼"];
function renderWelcome() {
  var grid = $("#welcome-avatars"); grid.innerHTML = "";
  var sel = AVATARS[0], i;
  for (i = 0; i < AVATARS.length; i++) {
    (function (a) {
      var b = document.createElement("button");
      b.className = "avatar-pick" + (a === sel ? " sel" : "");
      b.textContent = a;
      b.addEventListener("click", function () {
        sel = a;
        var ps = grid.querySelectorAll(".avatar-pick"), k;
        for (k = 0; k < ps.length; k++) ps[k].classList.remove("sel");
        b.classList.add("sel");
        playAudio(UA.hello);
      });
      grid.appendChild(b);
    })(AVATARS[i]);
  }
  showScreen("screen-welcome", false);
  navHistory.push("screen-welcome");
  playAudio(UA.welcome, function () { playAudio(UA.ui_name_ask); });
  $("#welcome-start").onclick = function () {
    var name = $("#welcome-name").value.trim().slice(0, 20);
    store.data.childName = name || "Bé";
    store.data.childAvatar = sel;
    store.save();
    refreshHome();
    navHistory.length = 0;
    playAudio(UA.name_saved);
    showScreen("screen-home");
  };
}

// ============================================================
// TÙY CHỈNH GIAO DIỆN
// ============================================================
var UI_THEMES = [
  { id: "rainbow", name: "Cầu vồng", emoji: "🌈" },
  { id: "pink",    name: "Hồng dâu", emoji: "🌸" },
  { id: "ocean",   name: "Biển xanh", emoji: "🌊" },
  { id: "forest",  name: "Rừng xanh", emoji: "🍃" },
  { id: "grape",   name: "Tím mơ",   emoji: "🍇" }
];
function uiPrefs() {
  var d = store.data.uiPrefs || {};
  return { theme: d.theme || "rainbow", fontSize: d.fontSize || "normal", homeGrid: d.homeGrid || "2" };
}
function applyUiPrefs() {
  var p = uiPrefs();
  document.body.dataset.theme = p.theme;
  document.body.dataset.fontsize = p.fontSize;
  document.body.dataset.homegrid = p.homeGrid;
  store.data.uiPrefs = p; store.save();
}
function renderSettings() {
  $("#set-name").value = store.data.childName || "";
  var ag = $("#set-avatars"); ag.innerHTML = "";
  var i;
  for (i = 0; i < AVATARS.length; i++) {
    (function (a) {
      var b = document.createElement("button");
      b.className = "avatar-pick" + (a === kidAvatar() ? " sel" : "");
      b.textContent = a;
      b.addEventListener("click", function () {
        store.data.childAvatar = a; store.save();
        var ps = ag.querySelectorAll(".avatar-pick"), k;
        for (k = 0; k < ps.length; k++) ps[k].classList.remove("sel");
        b.classList.add("sel");
        refreshHome(); toast("Đã đổi hình " + a);
      });
      ag.appendChild(b);
    })(AVATARS[i]);
  }
  var tg = $("#set-themes"); tg.innerHTML = "";
  for (i = 0; i < UI_THEMES.length; i++) {
    (function (t) {
      var b = document.createElement("button");
      b.className = "theme-pick theme-" + t.id + (t.id === uiPrefs().theme ? " sel" : "");
      b.innerHTML = "<span>" + t.emoji + "</span><span>" + t.name + "</span>";
      b.addEventListener("click", function () {
        var p = uiPrefs(); p.theme = t.id; store.data.uiPrefs = p; store.save();
        applyUiPrefs();
        var ps = tg.querySelectorAll(".theme-pick"), k;
        for (k = 0; k < ps.length; k++) ps[k].classList.remove("sel");
        b.classList.add("sel");
        playAudio(UA.ui_theme);
      });
      tg.appendChild(b);
    })(UI_THEMES[i]);
  }
  segWire("#set-fontsize", "fontSize", UA.ui_fontsize);
  segWire("#set-homegrid", "homeGrid", UA.ui_layout);
}
function segWire(sel, key, audioId) {
  var seg = $(sel);
  var btns = seg.querySelectorAll("button"), i;
  for (i = 0; i < btns.length; i++) {
    (function (b) {
      b.classList.toggle("sel", b.getAttribute("data-v") === uiPrefs()[key]);
      b.onclick = function () {
        var p = uiPrefs(); p[key] = b.getAttribute("data-v");
        store.data.uiPrefs = p; store.save();
        applyUiPrefs();
        for (var k = 0; k < btns.length; k++) btns[k].classList.toggle("sel", btns[k] === b);
        if (audioId) playAudio(audioId);
      };
    })(btns[i]);
  }
}
$("#set-name-save").addEventListener("click", function () {
  var name = $("#set-name").value.trim().slice(0, 20);
  if (!name) { toast("Bé gõ tên vào nhé!"); return; }
  store.data.childName = name; store.save();
  refreshHome();
  playAudio(UA.name_saved);
  toast("Đã lưu tên " + name + "! 👋");
});

// ============================================================
// THÀNH TÍCH
// ============================================================
function renderProgress() {
  $("#st-stars").textContent = store.data.stars;
  var lessons = Object.keys(store.data.lessonsDone).length;
  $("#st-lessons").textContent = lessons + "/" + STEP_LESSONS.length;
  $("#st-gallery").textContent = store.data.gallery.length;
  $("#st-games").textContent = store.data.gamePlays;
  var box = $("#progress-rows"); box.innerHTML = "";
  var rk = kidRank();
  var rb = document.createElement("div");
  rb.className = "rank-banner";
  rb.innerHTML = '<span style="font-size:30px">' + rk.split(" ")[0] + "</span><span><b>" +
    rk.slice(rk.indexOf(" ") + 1) + '</b><br><span style="font-size:13px;color:var(--ink-soft)">' +
    store.data.stars + " ⭐ — càng vẽ càng lên hạng!</span></span>";
  box.appendChild(rb);
  var g = document.createElement("div");
  g.className = "prow"; g.style.marginTop = "14px";
  var rows = "", i;
  for (i = 0; i < GAMES.length; i++) {
    var gm = GAMES[i];
    var sc = store.data.gameScores["score:" + gm.id] || 0;
    var gr = sc > 0 ? gradeOf(sc) : null;
    var keys = Object.keys(store.data.gameBest).filter(function (k) { return k.indexOf(gm.id + ":") === 0; });
    var best = 0, k;
    for (k = 0; k < keys.length; k++) best = Math.max(best, store.data.gameBest[keys[k]]);
    rows += '<div class="srow"><span>' + gm.emoji + " " + gm.name + "</span>" +
      "<span>" + (sc > 0 ? "<b>" + sc + "/10</b> " + gr.e + " " + gr.t : "—") +
      (best ? " · " + starStr(best) : "") + "</span></div>";
  }
  var traces = Object.keys(store.data.traceDone).length;
  rows += '<div class="srow"><span>〰️ Tô nét</span><span>' + traces + "/" + TRACE_ITEMS.length + " mẫu đã tô đẹp</span></div>";
  g.innerHTML = '<div class="ph"><span>🏅 Bảng điểm trò chơi</span></div>' + rows;
  box.appendChild(g);
}
$("#btn-reset").addEventListener("click", function () {
  if (confirm("Xóa hết sao và tiến trình học của bé?")) {
    store.reset(); refreshStarPill(); renderProgress(); toast("Đã xóa tiến trình 🗑️");
  }
});

// ============================================================
// BỘ SƯU TẬP (tối đa 30 tranh, FIFO)
// ============================================================
var GAL_MAX = 30;
// Trả về item vừa lưu nếu thành công, false nếu thất bại. Khi localStorage đầy (quota),
// bỏ bớt tranh cũ nhất rồi thử lưu lại thay vì im lặng làm mất tranh mới.
function addGalleryItem(url) {
  // LỖI 5: toDataURL có thể trả rỗng/"data:," trên máy yếu (hết RAM) —
  // không lưu item ảnh trống, nếu không trình chiếu sẽ hiện slide trắng
  // hoặc kết thúc sớm khiến bé chỉ thấy 1 ảnh.
  if (!url || url === "data:,") return false;
  var gal = store.data.gallery || (store.data.gallery = []);
  var item = { img: url, date: Date.now(), name: "" };
  gal.push(item);
  while (gal.length > GAL_MAX) gal.shift();
  while (!store.save() && gal.length > 0) gal.shift();
  if (!gal.length) { toast("Bộ nhớ đầy, chưa lưu được tranh 😢"); return false; }
  return gal[gal.length - 1];
}
function renderGallery() {
  var gal = store.data.gallery || [];
  var grid = $("#gallery-grid"); grid.innerHTML = "";
  var empty = $("#gallery-empty");
  if (!gal.length) {
    empty.style.display = "block";
    playAudio(UA.gal_empty);
    return;
  }
  empty.style.display = "none";
  var slideBtn = $("#gal-slide-btn");
  if (slideBtn) slideBtn.style.display = gal.length ? "inline-block" : "none";
  for (var i = gal.length - 1; i >= 0; i--) {
    (function (idx) {
      var it = gal[idx];
      var b = document.createElement("button");
      b.className = "gal-item";
      // v1.1: hiện tên tranh bé đã đặt (escHtml chống vỡ layout)
      b.innerHTML = '<img src="' + it.img + '" alt="Tranh của bé">' +
        '<span class="gal-name">' + escHtml(it.name || "Tranh của bé") + "</span>";
      b.addEventListener("click", function () { openGalView(idx); });
      grid.appendChild(b);
    })(i);
  }
  $("#gal-count").textContent = "Bé đã lưu " + gal.length + "/" + GAL_MAX + " tranh 🖼️";
}
function openGalView(idx) {
  var gal = store.data.gallery || [];
  var it = gal[idx];
  if (!it) return;
  galViewOpen = true;
  $("#gal-view-img").src = it.img;
  $("#gal-view-name").textContent = it.name || "Tranh của bé";
  $("#gal-view").classList.add("show");
  $("#gal-del").onclick = function () {
    stopSlideshow(); // xóa giữa trình chiếu thì dừng trình chiếu
    playAudio(UA.ui_confirm_del);
    if (confirm("Xóa bức tranh này nhé?")) {
      gal.splice(idx, 1);
      store.save();
      closeGalView();
      renderGallery();
      playAudio(UA.ui_deleted);
      toast("Đã xóa tranh 🗑️");
    }
  };
}
function closeGalView() {
  stopSlideshow();
  galViewOpen = false;
  $("#gal-view").classList.remove("show");
  playAudio(UA.ui_back);
}
$("#gal-close").addEventListener("click", closeGalView);

// ============================================================
// v1.1 — ĐẶT TÊN TRANH + TRÌNH CHIẾU (slideshow)
// ============================================================
var nameTarget = null;
function askGalleryName(item) {
  nameTarget = item;
  var inp = $("#name-input");
  if (inp) inp.value = item.name || "";
  $("#name-dialog").classList.add("show");
  // Đọc lời mời đặt tên sau khi âm báo lưu xong
  setTimeout(function () { playAudio(UA.gal_name); }, 900);
}
function closeNameDialog() {
  $("#name-dialog").classList.remove("show");
  nameTarget = null;
}
$("#name-ok").addEventListener("click", function () {
  var v = $("#name-input").value.trim().slice(0, 30);
  if (nameTarget) {
    nameTarget.name = v || "Tranh của bé";
    store.save();
    playAudio(UA.gal_named_ok);
    toast("Đã đặt tên tranh! 🖼️");
    renderGallery();
  }
  closeNameDialog();
});
$("#name-skip").addEventListener("click", closeNameDialog);

var slideTimer = null;
function stopSlideshow() {
  if (slideTimer) { clearInterval(slideTimer); slideTimer = null; }
}
function startSlideshow() {
  var gal = store.data.gallery || [];
  if (!gal.length) { toast("Bé chưa lưu tranh nào! 🖼️"); return; }
  stopSlideshow();
  galViewOpen = true;
  var idx = gal.length - 1; // mới nhất trước
  $("#gal-view").classList.add("show");
  // Ẩn nút xóa khi đang trình chiếu cho đỡ rối
  var delBtn0 = $("#gal-del");
  if (delBtn0) delBtn0.style.display = "none";
  playAudio(UA.gal_slide);
  function showSlide() {
    // LỖI 5: item hỏng (thiếu ảnh, vd: localStorage cũ / lưu lỗi) thì BỎ QUA
    // chứ không kết thúc sớm cả trình chiếu (bé chỉ thấy 1 ảnh rồi tắt).
    while (idx >= 0 && (!gal[idx] || typeof gal[idx].img !== "string" || !gal[idx].img)) idx--;
    if (idx < 0) { endSlide(); return; }
    var it = gal[idx];
    $("#gal-view-img").src = it.img;
    $("#gal-view-name").textContent = it.name || "Tranh của bé";
  }
  function endSlide() {
    stopSlideshow();
    var delBtn1 = $("#gal-del");
    if (delBtn1) delBtn1.style.display = "";
    playAudio(UA.gal_slide_end);
    setTimeout(closeGalView, 1600);
  }
  showSlide();
  slideTimer = setInterval(function () {
    idx--;
    if (idx < 0) endSlide();
    else showSlide();
  }, 3000);
}
$("#gal-slide-btn").addEventListener("click", startSlideshow);

// ---------- ỦNG HỘ: sao chép số tài khoản (fallback WebView cũ) ----------
function copyDonateAcct() {
  var acct = "0345140889";
  var ta = document.createElement("textarea");
  ta.value = acct;
  ta.setAttribute("readonly", "");
  ta.style.position = "absolute";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  var ok = false;
  try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
  try { document.body.removeChild(ta); } catch (e) {}
  if (ok) {
    toast("Đã sao chép số tài khoản! 🎉");
    playAudio(UA.dn_copied);
  } else {
    toast("Bé nhờ bố mẹ ghi lại số nhé. ✍️");
    playAudio(UA.dn_copyfail);
  }
}
$("#btn-copy-acct").addEventListener("click", copyDonateAcct);

// ============================================================
// THANH CHỮ CHẠY CUỐI APP (nội dung từ notepad.pw/drawkids)
// ============================================================
var TICKER_URL = "https://notepad.pw/fetch/drawkids";
var TICKER_DEFAULT = "Chúc bé vẽ thật đẹp mỗi ngày! 🎨 Made with ❤️ by <b>Jinken Nguyễn</b> · 1989";
function sanitizeTicker(html) {
  var tmp = document.createElement("div");
  tmp.innerHTML = html;
  var bad = tmp.querySelectorAll("script, iframe, object, embed, style, link"), i;
  for (i = 0; i < bad.length; i++) { if (bad[i].parentNode) bad[i].parentNode.removeChild(bad[i]); }
  var all = tmp.querySelectorAll("*"), k, a, j;
  for (i = 0; i < all.length; i++) {
    a = all[i].attributes;
    for (j = a.length - 1; j >= 0; j--) {
      if (/^on/i.test(a[j].name)) all[i].removeAttribute(a[j].name);
    }
  }
  return tmp.innerHTML;
}
// KHÔNG dùng async/await — WebView cũ parse lỗi cả file -> app trắng.
function loadTicker() {
  var finished = false;
  function done(html) {
    if (finished) return; // fetch về trễ sau timeout thì bỏ, tránh ghi đè lung tung
    finished = true;
    if (!html) html = TICKER_DEFAULT;
    else if (!/<[a-z][\s\S]*>/i.test(html)) html = html.replace(/\s*\n+\s*/g, " &nbsp;•&nbsp; ");
    var safe = sanitizeTicker(html);
    $("#ticker-a").innerHTML = safe;
    $("#ticker-b").innerHTML = safe;
    var len = $("#ticker-a").textContent.length;
    $("#ticker-track").style.animationDuration = Math.max(12, Math.round(len * 0.45)) + "s";
  }
  // Chống treo khi mạng chập chờn / offline: quá 15s không xong thì dùng nội dung mặc định.
  setTimeout(function () { done(""); }, 15000);
  try {
    if (typeof fetch !== "function") { done(""); return; }
    fetch(TICKER_URL, { cache: "no-store" }).then(function (r) {
      if (r.ok) return r.text();
      return "";
    }).then(function (t) { done((t || "").trim()); }).catch(function () { done(""); });
  } catch (e) { done(""); }
}

// ============================================================
// TƯƠNG TÁC CHUNG
// ============================================================
$("#mascot").addEventListener("click", function (ev) {
  playAudio(UA.hello);
  var m = $("#mascot");
  m.classList.remove("wiggle"); void m.offsetWidth; m.classList.add("wiggle");
  starBurst(ev.clientX, ev.clientY);
});
function narrateCurrent() {
  var active = document.querySelector(".screen.active");
  var key = active && NARRATE[active.id];
  var src = key && UA[key];
  if (src) playAudio(src);
}
$("#btn-narrate").addEventListener("click", narrateCurrent);
$("#streak-say").addEventListener("click", function () {
  toast("🔥 Bé đã học " + streakCount() + " ngày liên tiếp! Giỏi quá!");
});

// ============================================================
// 📤 ẢNH CỦA BÉ — tải ảnh lên, tô màu tranh nét, vẽ theo nét ảnh
// ============================================================
var PHOTO_MAX = 20;        // tối đa 20 ảnh
var PHOTO_EDGE = 300;      // cạnh xử lý tranh nét / flood fill
var PHOTO_JPEG_Q = 0.7;    // chất lượng nén jpeg khi lưu
var PHOTO_MAXSIDE = 600;   // cạnh dài tối đa sau khi nén
var photoState = { id: null, img: null, edge: null, work: null,
  color: "#E53935", eraser: false };
var photoDrawColor = "#E53935";

function photoById(id) {
  var list = store.data.photos || [];
  for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
  return null;
}

// ---------- Màn hình danh sách ảnh ----------
function renderPhotos() {
  var list = store.data.photos || [];
  var grid = $("#photos-grid"); grid.innerHTML = "";
  var empty = $("#photos-empty");
  if (!list.length) {
    empty.style.display = "block";
    $("#photos-count").textContent = "";
    playAudio(UA.ph_nophoto);
    return;
  }
  empty.style.display = "none";
  $("#photos-count").textContent = "Bé có " + list.length + "/" + PHOTO_MAX + " ảnh 📤";
  for (var i = 0; i < list.length; i++) {
    (function (it) {
      var b = document.createElement("button");
      b.className = "photo-item";
      b.innerHTML = '<img src="' + it.data + '" alt="Ảnh của bé">' +
        '<span class="photo-name">' + escHtml(it.name || "Ảnh của bé") + "</span>";
      b.addEventListener("click", function () { openPhotoLearn(it.id); });
      var del = document.createElement("span");
      del.className = "photo-del"; del.textContent = "✖";
      del.setAttribute("aria-label", "Xóa ảnh");
      del.addEventListener("click", function (ev) {
        ev.stopPropagation();
        playAudio(UA.ph_confirm_del);
        if (confirm("Xóa tấm ảnh này nhé?")) {
          var lst = store.data.photos || [];
          for (var k = 0; k < lst.length; k++) {
            if (lst[k].id === it.id) { lst.splice(k, 1); break; }
          }
          store.save();
          renderPhotos();
          playAudio(UA.ph_deleted);
          toast("Đã xóa ảnh 🗑️");
        }
      });
      b.appendChild(del);
      grid.appendChild(b);
    })(list[i]);
  }
}

// ---------- Đọc + nén ảnh từ máy ----------
function handlePhotoFile(file) {
  try {
    if (!file || !/^image\//.test(file.type || "")) {
      playAudio(UA.ph_readerr);
      toast("Máy đọc không được tấm ảnh này 😢");
      return;
    }
    // Ảnh quá nặng (>25MB) thì từ chối sớm, tránh treo máy yếu
    if (file.size && file.size > 25 * 1024 * 1024) {
      playAudio(UA.ph_toolarge);
      toast("Ảnh quá nặng, bé chọn ảnh nhẹ hơn nhé 😢");
      return;
    }
    var rd = new FileReader();
    rd.onerror = function () {
      playAudio(UA.ph_readerr);
      toast("Máy đọc không được tấm ảnh này 😢");
    };
    rd.onload = function () {
      var img = new Image();
      img.onerror = function () {
        playAudio(UA.ph_readerr);
        toast("Máy đọc không được tấm ảnh này 😢");
      };
      img.onload = function () {
        try {
          var w = img.width || 0, h = img.height || 0;
          if (!w || !h) throw new Error("bad size");
          var s = Math.min(1, PHOTO_MAXSIDE / Math.max(w, h));
          var cw = Math.max(1, Math.round(w * s)), ch = Math.max(1, Math.round(h * s));
          var cv = document.createElement("canvas");
          cv.width = cw; cv.height = ch;
          var cx = cv.getContext("2d");
          cx.drawImage(img, 0, 0, cw, ch);
          var url = cv.toDataURL("image/jpeg", PHOTO_JPEG_Q);
          var list = store.data.photos || [];
          store.data.photos = list;
          var evicted = false;
          if (list.length >= PHOTO_MAX) { list.pop(); evicted = true; } // FIFO: bỏ ảnh cũ nhất
          var item = { id: "ph" + Date.now(), name: file.name || "Ảnh của bé", data: url };
          list.unshift(item);
          if (!store.save()) {
            // Bộ nhớ đầy (quota): hoàn tác, không để mảng lệch với máy
            list.shift();
            playAudio(UA.ph_storage_full);
            toast("Bộ nhớ đầy, không lưu được ảnh 😢");
            return;
          }
          renderPhotos();
          if (evicted) {
            playAudio(UA.ph_full);
            toast("Đã thay ảnh cũ nhất bằng ảnh mới 📤");
          } else {
            playAudio(UA.ph_saved);
            toast("Đã lưu ảnh 📸");
          }
        } catch (e2) {
          playAudio(UA.ph_readerr);
          toast("Máy đọc không được tấm ảnh này 😢");
        }
      };
      img.src = rd.result;
    };
    rd.readAsDataURL(file);
  } catch (e) {
    playAudio(UA.ph_readerr);
    toast("Máy đọc không được tấm ảnh này 😢");
  }
}
$("#photo-pick").addEventListener("click", function () {
  playAudio(UA.ph_guide);
  $("#photo-file").click();
});
$("#photo-file").addEventListener("change", function () {
  var f = this.files && this.files[0];
  this.value = ""; // cho phép chọn lại cùng 1 file
  if (f) handlePhotoFile(f);
});

// ---------- Màn hình học từ ảnh ----------
function photoFind(id) { return photoById(id); }
function openPhotoLearnCore(id) {
  var it = photoFind(id);
  if (!it) { renderPhotos(); return; }
  photoState.id = id;
  photoState.img = new Image();
  photoState.img.onload = function () {
    try {
      photoState.edge = photoBuildEdge(photoState.img);
      photoResetWork();
      photoSetTab("color", true);
      $("#photo-learn-title").textContent = it.name || "Ảnh của bé";
      // Thuyết minh màn hình chạy trước (ph_learn_guide), xong mới tới lời mời (ph_open)
      showScreen("screen-photo-learn", true, function () {
        playAudio(UA.ph_learn_guide, function () { playAudio(UA.ph_open); });
      });
    } catch (e) {
      playAudio(UA.ph_readerr);
      toast("Máy đọc không được tấm ảnh này 😢");
    }
  };
  photoState.img.onerror = function () {
    playAudio(UA.ph_readerr);
    toast("Máy đọc không được tấm ảnh này 😢");
  };
  photoState.img.src = it.data;
}
function photoSetTab(mode, silent) {
  var tabs = $$("#photo-tabs button"), i;
  for (i = 0; i < tabs.length; i++) {
    tabs[i].classList.toggle("sel", tabs[i].getAttribute("data-v") === mode);
  }
  $("#photo-mode-color").style.display = mode === "color" ? "block" : "none";
  $("#photo-mode-draw").style.display = mode === "draw" ? "block" : "none";
  if (mode === "draw") {
    var it = photoFind(photoState.id);
    if (it) $("#photo-draw-img").src = it.data;
  }
  if (!silent) playAudio(mode === "color" ? UA.ph_color_guide : UA.ph_draw_guide);
}
(function () {
  var tabs = $$("#photo-tabs button");
  for (var i = 0; i < tabs.length; i++) {
    (function (b) {
      b.addEventListener("click", function () { photoSetTab(b.getAttribute("data-v")); });
    })(tabs[i]);
  }
})();

// ---------- Tranh nét từ ảnh: grayscale -> Sobel 3x3 -> threshold ----------
function photoBuildEdge(img) {
  var W = PHOTO_EDGE, H = PHOTO_EDGE;
  var off = document.createElement("canvas");
  off.width = W; off.height = H;
  var octx = off.getContext("2d");
  // cover: phủ kín khung vuông, cắt phần thừa
  var sw = img.width, sh = img.height;
  var s = Math.max(W / sw, H / sh);
  var dw = sw * s, dh = sh * s;
  octx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
  var src = octx.getImageData(0, 0, W, H), sd = src.data;
  var gray = new Array(W * H), i, x, y;
  for (i = 0; i < W * H; i++) {
    gray[i] = (sd[i * 4] * 299 + sd[i * 4 + 1] * 587 + sd[i * 4 + 2] * 114) / 1000;
  }
  var out = octx.createImageData(W, H), od = out.data;
  var TH = 100; // ngưỡng nét
  for (y = 1; y < H - 1; y++) {
    for (x = 1; x < W - 1; x++) {
      var gx = -gray[(y - 1) * W + x - 1] - 2 * gray[y * W + x - 1] - gray[(y + 1) * W + x - 1] +
                gray[(y - 1) * W + x + 1] + 2 * gray[y * W + x + 1] + gray[(y + 1) * W + x + 1];
      var gy = -gray[(y - 1) * W + x - 1] - 2 * gray[(y - 1) * W + x] - gray[(y - 1) * W + x + 1] +
                gray[(y + 1) * W + x - 1] + 2 * gray[(y + 1) * W + x] + gray[(y + 1) * W + x + 1];
      var v = (Math.abs(gx) + Math.abs(gy)) > TH ? 0 : 255; // nét đen trên nền trắng
      var o = (y * W + x) * 4;
      od[o] = v; od[o + 1] = v; od[o + 2] = v; od[o + 3] = 255;
    }
  }
  return out;
}
function photoWorkCanvas() {
  if (!photoState.work) {
    photoState.work = document.createElement("canvas");
    photoState.work.width = PHOTO_EDGE; photoState.work.height = PHOTO_EDGE;
  }
  return photoState.work;
}
function photoResetWork() {
  var wc = photoWorkCanvas();
  var wctx = wc.getContext("2d");
  wctx.putImageData(photoState.edge, 0, 0);
  photoBlit();
}
function photoBlit() {
  var wc = photoWorkCanvas();
  var cv = $("#photo-color-canvas");
  var ctx = cv.getContext("2d");
  if (!ctx) return;
  ctx.imageSmoothingEnabled = false; // giữ nét khi phóng 300 -> 600
  ctx.drawImage(wc, 0, 0, cv.width, cv.height);
}
function hexToRgb(hex) {
  var h = String(hex || "").replace("#", "");
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  return [parseInt(h.substr(0, 2), 16) || 0, parseInt(h.substr(2, 2), 16) || 0,
    parseInt(h.substr(4, 2), 16) || 0];
}
// Flood fill scanline trên ImageData 300x300, tolerance 32 theo RGB
function photoFloodFill(imgData, sx, sy, fr, fg, fb) {
  var w = imgData.width, h = imgData.height, d = imgData.data;
  if (sx < 0 || sx >= w || sy < 0 || sy >= h) return false;
  var si = (sy * w + sx) * 4;
  var tr = d[si], tg = d[si + 1], tb = d[si + 2];
  if (tr === fr && tg === fg && tb === fb) return false; // đã đúng màu cần tô
  var TOL = 32;
  function match(i) {
    return Math.abs(d[i] - tr) <= TOL && Math.abs(d[i + 1] - tg) <= TOL && Math.abs(d[i + 2] - tb) <= TOL;
  }
  var stack = [[sx, sy]];
  var filled = 0, MAXF = w * h; // chặn an toàn cho máy yếu
  while (stack.length) {
    var p = stack.pop(), x = p[0], y = p[1];
    if (!match((y * w + x) * 4)) continue;
    var xl = x;
    while (xl >= 0 && match((y * w + xl) * 4)) xl--;
    xl++;
    var xr = x;
    while (xr < w && match((y * w + xr) * 4)) xr++;
    xr--;
    var spanUp = false, spanDown = false, xx, ii;
    for (xx = xl; xx <= xr; xx++) {
      ii = (y * w + xx) * 4;
      d[ii] = fr; d[ii + 1] = fg; d[ii + 2] = fb; d[ii + 3] = 255;
      filled++;
      if (y > 0) {
        var up = match(((y - 1) * w + xx) * 4);
        if (up && !spanUp) { stack.push([xx, y - 1]); spanUp = true; }
        else if (!up) spanUp = false;
      }
      if (y < h - 1) {
        var dn = match(((y + 1) * w + xx) * 4);
        if (dn && !spanDown) { stack.push([xx, y + 1]); spanDown = true; }
        else if (!dn) spanDown = false;
      }
    }
    if (filled > MAXF) break;
  }
  return filled > 0;
}
// WebView cũ không có Pointer Events (thiếu cả String.prototype.repeat):
// chạm màn hình chỉ sinh touchstart/touchmove/touchend, KHÔNG bao giờ sinh
// pointerdown -> mọi chạm lên 2 canvas của màn "Học từ ảnh" đều rơi vào
// khoảng không. click vẫn chạy nên mở màn hình / chuyển tab / Lưu vẫn được.
// -> khi thiếu Pointer Events, gắn thêm bộ nghe touch/mouse dự phòng.
var PHOTO_HAS_POINTER = (typeof window !== "undefined") &&
  ("onpointerdown" in window) && (typeof window.PointerEvent !== "undefined");
// Logic khi chạm để tô màu: tách riêng để dùng chung cho pointerdown (máy mới)
// và touchstart/mousedown (máy cũ). Trả về true nếu đã tô được.
function photoColorTap(clientX, clientY) {
  if (!photoState.work) return false;
  try {
    var cv = $("#photo-color-canvas");
    var r = cv.getBoundingClientRect();
    var sx = Math.floor(((clientX - r.left) / (r.width || 1)) * PHOTO_EDGE);
    var sy = Math.floor(((clientY - r.top) / (r.height || 1)) * PHOTO_EDGE);
    var rgb = photoState.eraser ? [255, 255, 255] : hexToRgb(photoState.color);
    var wc = photoWorkCanvas();
    var wctx = wc.getContext("2d");
    var idata = wctx.getImageData(0, 0, PHOTO_EDGE, PHOTO_EDGE);
    if (photoFloodFill(idata, sx, sy, rgb[0], rgb[1], rgb[2])) {
      wctx.putImageData(idata, 0, 0);
      photoBlit();
      return true;
    }
  } catch (err) {}
  return false;
}
$("#photo-color-canvas").addEventListener("pointerdown", function (e) {
  if (e.preventDefault) e.preventDefault();
  photoColorTap(e.clientX, e.clientY);
});
if (!PHOTO_HAS_POINTER) {
  // Dự phòng cho WebView cũ: touchstart ~ pointerdown; mousedown cho chuột.
  $("#photo-color-canvas").addEventListener("touchstart", function (e) {
    if (e.preventDefault) e.preventDefault();
    var t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]);
    if (t) photoColorTap(t.clientX, t.clientY);
  });
  $("#photo-color-canvas").addEventListener("mousedown", function (e) {
    photoColorTap(e.clientX, e.clientY);
  });
}

// ---------- Bảng màu (tái dùng pattern swatch-row) ----------
function photoBuildPalette(elId, getSel, onPick) {
  var pal = $(elId); pal.innerHTML = "";
  for (var i = 0; i < COLORS.length; i++) {
    (function (c) {
      var b = document.createElement("button");
      b.className = "swatch" + (c.hex === getSel() ? " sel" : "");
      b.style.background = c.hex;
      b.setAttribute("aria-label", c.name);
      b.addEventListener("click", function () {
        onPick(c);
        var ss = pal.querySelectorAll(".swatch"), k;
        for (k = 0; k < ss.length; k++) ss[k].classList.remove("sel");
        b.classList.add("sel");
        playAudio(UA.dr_palette);
      });
      pal.appendChild(b);
    })(COLORS[i]);
  }
}
function photoRefreshColorUI() {
  photoBuildPalette("#photo-palette", function () { return photoState.color; }, function (c) {
    photoState.color = c.hex; photoState.eraser = false;
    $("#photo-eraser").classList.remove("sel");
  });
  photoBuildPalette("#photo-draw-palette", function () { return photoDrawColor; }, function (c) {
    photoDrawColor = c.hex;
  });
  $("#photo-eraser").classList.toggle("sel", photoState.eraser);
}
$("#photo-eraser").addEventListener("click", function () {
  photoState.eraser = !photoState.eraser;
  $("#photo-eraser").classList.toggle("sel", photoState.eraser);
  if (photoState.eraser) playAudio(UA.ph_eraser_guide);
  else playAudio(UA.dr_palette);
});
$("#photo-recolor").addEventListener("click", function () {
  if (!photoState.work) return;
  photoResetWork();
  playAudio(UA.dr_clear);
  toast("Đã vẽ lại tranh nét 🖍️");
});
$("#photo-color-guide").addEventListener("click", function () { playAudio(UA.ph_color_guide); });
$("#photo-color-save").addEventListener("click", function () {
  playAudio(UA.dr_save);
  try {
    var url = $("#photo-color-canvas").toDataURL("image/jpeg", PHOTO_JPEG_Q);
    var it = addGalleryItem(url);
    if (it) {
      playAudio(UA.ph_color_done);
      askGalleryName(it);
    } else toast("Chưa lưu được, bé thử lại nhé! 😢");
  } catch (e) { toast("Chưa lưu được, bé thử lại nhé! 😢"); }
});

// ---------- Chế độ vẽ theo nét ảnh (tái dùng attachDraw) ----------
function photoDrawStyle() { return { color: photoDrawColor, width: 10 }; }
(function () {
  var cv = $("#photo-draw-canvas");
  // attachDraw đã tự gắn fallback touch/mouse khi thiếu Pointer Events
  // (xem HAS_POINTER ở động cơ vẽ chung) nên canvas này vẽ được trên máy cũ.
  if (!cv._drawWired) { attachDraw(cv, photoDrawStyle, null); cv._drawWired = true; }
})();
$("#photo-draw-clear").addEventListener("click", function () {
  var cv = $("#photo-draw-canvas"), ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
  playAudio(UA.dr_clear);
});
$("#photo-draw-guide").addEventListener("click", function () { playAudio(UA.ph_draw_guide); });
$("#photo-draw-done").addEventListener("click", function () {
  addStars(1);
  playAudio(UA.ph_draw_done);
  mascotCheer();
  confetti();
  praisePop("Bé vẽ đẹp quá! +1 ⭐");
  toast("Bé vẽ đẹp quá! +1 ⭐");
});
// Mở màn hình học: dựng lại bảng màu + xóa nét vẽ cũ của chế độ vẽ theo
function openPhotoLearn(id) {
  photoRefreshColorUI();
  var cv = $("#photo-draw-canvas"), ctx = cv.getContext("2d");
  if (ctx) ctx.clearRect(0, 0, cv.width, cv.height);
  openPhotoLearnCore(id);
}

// ---------- Khởi động ----------
store.load();
applyUiPrefs();
wireMenu();
initStepCanvas();
refreshStarPill();
refreshHome();
loadTicker();
setInterval(loadTicker, 5 * 60 * 1000);
if (!store.data.childName) renderWelcome();
else { showScreen("screen-home", false); navHistory.push("screen-home"); }
