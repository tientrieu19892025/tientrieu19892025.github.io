// ============================================================
// English Kids - logic chính (bản mở rộng: 5 cấp độ, học câu, ghép câu)
// Lưu tiến trình trên máy (localStorage), không cần đăng nhập
// ============================================================
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function sample(a, n) { return shuffle(a).slice(0, n); }

// ---------- Tiến trình (lưu trên máy) ----------
const PKEY = "englishkids_progress_v1";
const store = {
  data: { seen: {}, senSeen: {}, stars: 0, gameBest: {}, gameScores: {}, examBest: {}, gamePlays: 0, stories: {} },
  load() {
    try { const raw = localStorage.getItem(PKEY); if (raw) this.data = Object.assign(this.data, JSON.parse(raw)); } catch (e) {}
  },
  save() { try { localStorage.setItem(PKEY, JSON.stringify(this.data)); } catch (e) {} },
  reset() { this.data = { seen: {}, senSeen: {}, stars: 0, gameBest: {}, gameScores: {}, examBest: {}, gamePlays: 0, stories: {} }; this.save(); }
};
function addStars(n) { store.data.stars += n; store.save(); refreshStarPill(); }
function refreshStarPill() { $("#stars-total").textContent = store.data.stars; }

// ---------- Âm thanh ----------
let currentAudio = null;
function playAudio(src, onend) {
  try {
    if (currentAudio) { currentAudio.pause(); currentAudio.currentTime = 0; }
    currentAudio = new Audio(src);
    if (onend) currentAudio.onended = onend;
    currentAudio.play().catch(() => {});
  } catch (e) {}
}
function wordAudio(w) { return "audio/" + w.id + ".mp3"; }

// ---------- Kênh thuyết minh: chuyển mục là ngắt ngay cái cũ ----------
let narrTimers = [];
function stopNarration() {
  narrTimers.forEach(clearTimeout); narrTimers = [];
  if (currentAudio) { try { currentAudio.pause(); } catch (e) {} currentAudio = null; }
}
function narrate(src, ms, onend) {
  if (typeof src === "function") { narrTimers.push(setTimeout(src, ms == null ? 0 : ms)); return; }
  narrTimers.push(setTimeout(() => playAudio(src, onend), ms == null ? 0 : ms));
}

// ---------- Hình minh họa của từ ----------
function visualHTML(w, cls) {
  cls = cls || "";
  if (w.kind === "image") return `<img src="${w.img}" alt="${w.en}" class="${cls}" draggable="false">`;
  if (w.kind === "color") return `<div class="swatch ${cls}" style="background:${w.css}${w.border ? ";border:3px solid #B0BEC5" : ""}"></div>`;
  if (w.kind === "emoji") return `<div class="emoji-big ${cls}">${w.emoji || "⭐"}</div>`;
  return `<div class="bignum ${cls}">${w.num}</div>`;
}
function visualBigHTML(w) {
  if (w.kind === "image") return `<img src="${w.img}" alt="${w.en}" draggable="false">`;
  if (w.kind === "color") return `<div class="swatch-big" style="background:${w.css}${w.border ? ";border:4px solid #B0BEC5" : ""}"></div>`;
  if (w.kind === "emoji") return `<div class="emoji-big big">${w.emoji || "⭐"}</div>`;
  return `<div class="num-big">${w.num}</div>`;
}

// ---------- Điều hướng ----------
const TITLES = {
  "screen-home": "English Kids", "screen-topics": "📚 Học từ vựng",
  "screen-learn": "📚 Học từ", "screen-games": "🎮 Trò chơi",
  "screen-game-setup": "🎮 Trò chơi", "screen-game-play": "🎮 Trò chơi",
  "screen-result": "🏆 Kết quả", "screen-stories": "📖 Truyện",
  "screen-exams": "📝 Thi thử",
  "screen-story-read": "📖 Đọc truyện", "screen-progress": "🏆 Thành tích",
  "screen-sentences": "📝 Học câu", "screen-sentence-learn": "📝 Học câu",
  "screen-songs": "🎵 Bài hát", "screen-song-play": "🎵 Bài hát",
  "screen-abc": "🔤 Bảng chữ cái", "screen-trace": "✏️ Tô chữ",
  "screen-welcome": "👋 Chào bé", "screen-settings": "⚙️ Cài đặt",
};
const history = [];
const NARRATE = {
  "screen-home": "nav_home", "screen-topics": "nav_topics", "screen-learn": "nav_learn",
  "screen-games": "nav_games", "screen-sentences": "nav_sentences", "screen-stories": "nav_stories",
  "screen-songs": "nav_songs", "screen-abc": "nav_abc", "screen-trace": "nav_trace",
  "screen-pet": "nav_pet", "screen-dict": "nav_dict", "screen-progress": "nav_progress",
};
const narratedOnce = new Set(); // giữ để tương thích (không dùng nữa)
let examTimer = null; // bấm giờ thi (định nghĩa sớm để showScreen dùng được)
function showScreen(id, push, afterNarr) {
  stopNarration(); // vào mục khác: lập tức ngắt hướng dẫn đang phát
  // thoát giữa giờ thi -> dừng đồng hồ
  if (examTimer && !(gameId === "exam" && id === "screen-game-play")) {
    clearInterval(examTimer); examTimer = null;
  }
  $$(".screen").forEach(s => s.classList.remove("active"));
  $("#" + id).classList.add("active");
  $("#title").textContent = TITLES[id] || "English Kids";
  $("#btn-back").classList.toggle("show", id !== "screen-home");
  if (id === "screen-home") refreshHome();
  if (push !== false && history[history.length - 1] !== id) history.push(id);
  $("main").scrollTop = 0;
  // ở mục nào -> phát hướng dẫn mục đó (mỗi lần vào đều phát)
  const _nk = NARRATE[id];
  const done = () => { if (afterNarr) { const f = afterNarr; afterNarr = null; f(); } };
  if (_nk && UI_AUDIO[_nk]) narrate(UI_AUDIO[_nk], 350, done);
  else narrTimers.push(setTimeout(done, 350));
}
function goBack() {
  history.pop();
  const prev = history.pop() || "screen-home";
  showScreen(prev);
}
$("#btn-back").addEventListener("click", goBack);
// Nút back / vuốt back của hệ thống Android: quay lại màn hình trước,
// chỉ thoát app khi đang ở màn hình chính.
window.__systemBack = function() {
  if (history.length <= 1) return false;
  goBack();
  return true;
};
$$("[data-go]").forEach(b => b.addEventListener("click", () => {
  const t = b.getAttribute("data-go");
  if (t === "topics") renderTopics();
  if (t === "games") renderGames();
  if (t === "exams") renderExams();
  if (t === "stories") renderStories();
  if (t === "progress") renderProgress();
  if (t === "sentences") renderSentenceThemes();
  if (t === "trace") initTrace();
  if (t === "daily") { startDaily(); return; } // startDaily tự chuyển màn hình
  if (t === "pet") renderPet();
  if (t === "dict") renderDict();
  if (t === "songs") renderSongs();
  if (t === "abc") renderABC();
  if (t === "settings") renderSettings();
  showScreen("screen-" + t);
}));

// Cập nhật thẻ thử thách ngày trên trang chủ (hiển thị streak)
function refreshHome() {
  const n = streakCount();
  $("#card-daily-sub").textContent = n > 0 ? `🔥 ${n} ngày liên tiếp!` : "12 câu hỏi mỗi ngày";
  const rk = kidRank();
  const hre = $("#hero-rank");
  if (hre) hre.textContent = `${rk} · ${store.data.stars} ⭐`;
}
// ---------- Cấp bậc của bé theo tổng sao ----------
function kidRank() {
  const s = store.data.stars || 0;
  if (s >= 500) return "🏆 Huyền thoại nhí";
  if (s >= 200) return "🚀 Cao thủ nhí";
  if (s >= 100) return "🌟 Ngôi sao nhí";
  if (s >= 50) return "💪 Chiến binh nhí";
  if (s >= 20) return "🌱 Bé chăm học";
  return "🐣 Bé mới bắt đầu";
}
// ---------- Confetti ăn mừng ----------
function confetti() {
  const icons = ["🎉", "⭐", "🎊", "✨", "🌟"];
  for (let i = 0; i < 45; i++) {
    const c = document.createElement("div");
    c.className = "confetti";
    c.textContent = icons[i % icons.length];
    c.style.left = (Math.random() * 100) + "vw";
    c.style.animationDelay = (Math.random() * 0.9).toFixed(2) + "s";
    c.style.fontSize = (20 + Math.random() * 18) + "px";
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 4200);
  }
}

// ---------- Toast & hiệu ứng sao ----------
let toastTimer = null;
function toast(msg) {
  const el = $("#toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 1600);
}
function starBurst(x, y) {
  for (let i = 0; i < 6; i++) {
    const s = document.createElement("div");
    s.className = "burst"; s.textContent = "⭐";
    s.style.left = (x + (Math.random() * 80 - 40)) + "px";
    s.style.top = (y + (Math.random() * 30 - 15)) + "px";
    document.body.appendChild(s);
    setTimeout(() => s.remove(), 1000);
  }
}

// ============================================================
// CỔ VŨ KIỂU MONKEY STORIES: linh vật nhảy múa, combo, khen đa dạng
// ============================================================
const PRAISE_KEYS = ["praise1", "praise2", "praise3", "praise4", "praise5", "praise6"];
const PRAISE_VI_KEYS = ["vipraise1", "vipraise2", "vipraise3", "vipraise4"];
const PRAISE_TEXTS = ["Tuyệt vời! 🎉", "Giỏi quá! ⭐", "Hoan hô! 🎊", "Siêu quá đi! 🌟", "Đúng rồi! 💛", "Hay quá! 🎈"];
const TRY_TEXTS = ["Chưa đúng, thử lại nhé! 💪", "Gần đúng rồi! 🌱"];
let combo = 0, lastPraiseIdx = -1;

function pickPraise() {
  let i;
  do { i = Math.floor(Math.random() * PRAISE_KEYS.length); } while (i === lastPraiseIdx);
  lastPraiseIdx = i;
  const useVi = Math.random() < 0.45; // xen kẽ Anh/Việt cho vui tai
  const key = useVi ? PRAISE_VI_KEYS[i % PRAISE_VI_KEYS.length] : PRAISE_KEYS[i];
  return { audio: UI_AUDIO[key] || UI_AUDIO.great, text: PRAISE_TEXTS[i] };
}

// Bé trả lời đúng: combo tăng, Momo nhảy múa, chữ khen bật to, sao bay
// sayFirst: âm thanh phát trước (vd: đọc lại từ), rồi mới khen
function praiseCorrect(x, y, sayFirst) {
  combo++;
  const p = pickPraise();
  if (sayFirst) { playAudio(sayFirst); narrate(p.audio, 900); }
  else playAudio(p.audio);
  mascotCheer();
  praisePop(p.text + (combo >= 2 ? `   🔥x${combo}` : ""));
  updateComboBadge();
  if (x != null) starBurst(x, y == null ? 200 : y);
  if (combo >= 3) miniConfetti();
}

// Bé trả lời sai: động viên dịu dàng, reset combo
function encourageWrong() {
  combo = 0; updateComboBadge();
  gameMistakes++;
  const vi = Math.random() < 0.6;
  playAudio(vi ? UI_AUDIO[Math.random() < 0.5 ? "vitry1" : "vitry2"] : UI_AUDIO.tryagain);
  praisePop(TRY_TEXTS[Math.floor(Math.random() * TRY_TEXTS.length)], true);
}

// Linh vật Momo nhảy múa cổ vũ trong lúc chơi game
function mascotCheer() {
  const m = $("#game-cheer");
  if (!m) return;
  m.classList.add("show");
  const img = m.querySelector("img");
  img.classList.remove("dance"); void img.offsetWidth; img.classList.add("dance");
  clearTimeout(m._t);
  m._t = setTimeout(() => m.classList.remove("show"), 2300);
}

// Chữ khen bật to giữa màn hình rồi mờ dần
function praisePop(text, gentle) {
  let el = $("#praise-pop");
  if (!el) { el = document.createElement("div"); el.id = "praise-pop"; document.body.appendChild(el); }
  el.textContent = text;
  el.classList.toggle("gentle", !!gentle);
  el.classList.remove("show"); void el.offsetWidth; el.classList.add("show");
}

// Huy hiệu combo trên màn chơi
function updateComboBadge() {
  const b = $("#combo-badge");
  if (!b) return;
  if (combo >= 2) { b.textContent = `🔥 COMBO x${combo}`; b.classList.add("show"); }
  else b.classList.remove("show");
}

// Mưa sao mini khi combo cao
function miniConfetti() {
  const icons = ["⭐", "✨", "🌟"];
  for (let i = 0; i < 12; i++) {
    const c = document.createElement("div");
    c.className = "confetti"; c.textContent = icons[i % 3];
    c.style.left = (Math.random() * 100) + "vw";
    c.style.fontSize = (16 + Math.random() * 14) + "px";
    c.style.animationDuration = (1.6 + Math.random()) + "s";
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 2800);
  }
}

function resetCombo() { combo = 0; updateComboBadge(); }

// ---------- Thẻ chủ đề dùng chung ----------
function themeCard(t) {
  const seen = t.words.filter(w => store.data.seen[w.id]).length;
  const pct = Math.round(seen / t.words.length * 100);
  const b = document.createElement("button");
  b.className = "theme-card"; b.style.setProperty("--tc", t.color);
  b.innerHTML = `<span class="emoji">${t.emoji}</span>
    <span><span class="tname">${t.name}</span><br><span class="ten">${t.en}</span></span>
    <span class="meta">${seen}/${t.words.length} từ<div class="pbar"><div style="width:${pct}%"></div></div></span>`;
  return b;
}
function levelHeader(l) {
  const h = document.createElement("div");
  h.className = "level-head";
  h.innerHTML = `<span>${l.emoji} ${l.name}</span>`;
  return h;
}

// ============================================================
// HỌC TỪ VỰNG (flashcard) - theo cấp độ
// ============================================================
let learnTheme = null, learnIdx = 0;
function renderTopics() {
  const box = $("#topic-list"); box.innerHTML = "";
  LEVELS.forEach(l => {
    const themes = themesOfLevel(l.id);
    if (!themes.length) return;
    box.appendChild(levelHeader(l));
    themes.forEach(t => {
      const b = themeCard(t);
      b.addEventListener("click", () => startLearn(t.id));
      box.appendChild(b);
    });
  });
}
function startLearn(themeId) {
  learnTheme = themeById(themeId); learnIdx = 0;
  renderFlash();
  showScreen("screen-learn", true, () => playAudio(wordAudio(learnTheme.words[learnIdx])));
}
function renderFlash() {
  const w = learnTheme.words[learnIdx];
  $("#flash-visual").innerHTML = visualBigHTML(w);
  $("#flash-en").textContent = w.en;
  $("#flash-vi").textContent = w.vi;
  $("#flash-ex").textContent = w.ex;
  $("#flash-prev").disabled = learnIdx === 0;
  $("#flash-next").disabled = learnIdx === learnTheme.words.length - 1;
  const dots = $("#flash-dots"); dots.innerHTML = "";
  learnTheme.words.forEach((ww, i) => {
    const d = document.createElement("div");
    d.className = "dot" + (store.data.seen[ww.id] ? " seen" : "") + (i === learnIdx ? " now" : "");
    dots.appendChild(d);
  });
  if (!store.data.seen[w.id]) { store.data.seen[w.id] = true; store.save(); }
}
$("#flash-prev").addEventListener("click", () => { if (learnIdx > 0) { learnIdx--; renderFlash(); playAudio(wordAudio(learnTheme.words[learnIdx])); } });
$("#flash-next").addEventListener("click", () => { if (learnIdx < learnTheme.words.length - 1) { learnIdx++; renderFlash(); playAudio(wordAudio(learnTheme.words[learnIdx])); } });
$("#flash-say").addEventListener("click", () => playAudio(wordAudio(learnTheme.words[learnIdx])));
$("#flash-word-say").addEventListener("click", () => playAudio(wordAudio(learnTheme.words[learnIdx])));
$("#flash-vi-say").addEventListener("click", () => playAudio(learnTheme.words[learnIdx].audioVi));

// ============================================================
// HỌC CÂU
// ============================================================
let senTheme = null, senIdx = 0;
function renderSentenceThemes() {
  const box = $("#sentence-theme-list"); box.innerHTML = "";
  LEVELS.forEach(l => {
    const themes = themesOfLevel(l.id);
    if (!themes.length) return;
    box.appendChild(levelHeader(l));
    themes.forEach(t => {
      const seen = t.sentences.filter((s, i) => store.data.senSeen[t.id + ":" + i]).length;
      const b = document.createElement("button");
      b.className = "theme-card"; b.style.setProperty("--tc", t.color);
      b.innerHTML = `<span class="emoji">${t.emoji}</span>
        <span><span class="tname">${t.name}</span><br><span class="ten">${t.sentences.length} câu</span></span>
        <span class="meta">${seen}/${t.sentences.length} câu</span>`;
      b.addEventListener("click", () => startSentenceLearn(t.id));
      box.appendChild(b);
    });
  });
}
function startSentenceLearn(themeId) {
  senTheme = themeById(themeId); senIdx = 0;
  renderSen();
  showScreen("screen-sentence-learn", true, () => playAudio(senTheme.sentences[senIdx].audio));
}
function renderSen() {
  const s = senTheme.sentences[senIdx];
  $("#sen-en").textContent = s.en;
  $("#sen-vi").textContent = s.vi;
  // tách từ để bé làm quen mặt chữ
  $("#sen-words").innerHTML = s.en.replace(/[.!?]$/, "").split(" ").map(w =>
    `<span class="wchip-view">${w}</span>`).join("");
  $("#sen-prev").disabled = senIdx === 0;
  $("#sen-next").disabled = senIdx === senTheme.sentences.length - 1;
  const dots = $("#sen-dots"); dots.innerHTML = "";
  senTheme.sentences.forEach((ss, i) => {
    const d = document.createElement("div");
    d.className = "dot" + (store.data.senSeen[senTheme.id + ":" + i] ? " seen" : "") + (i === senIdx ? " now" : "");
    dots.appendChild(d);
  });
  const key = senTheme.id + ":" + senIdx;
  if (!store.data.senSeen[key]) { store.data.senSeen[key] = true; store.save(); }
}
$("#sen-prev").addEventListener("click", () => { if (senIdx > 0) { senIdx--; renderSen(); playAudio(senTheme.sentences[senIdx].audio); } });
$("#sen-next").addEventListener("click", () => { if (senIdx < senTheme.sentences.length - 1) { senIdx++; renderSen(); playAudio(senTheme.sentences[senIdx].audio); } });
$("#sen-say").addEventListener("click", () => playAudio(senTheme.sentences[senIdx].audio));
$("#sen-vi-say").addEventListener("click", () => playAudio(senTheme.sentences[senIdx].audioVi));

// ============================================================
// TRÒ CHƠI
// ============================================================
const GAMES = [
  { id: "listen",   name: "Nghe và chọn hình", sub: "Nghe từ, chạm đúng hình", emoji: "🔊", audio: UI_AUDIO.listen, guide: UI_AUDIO.guide_listen },
  { id: "word",     name: "Nhìn hình đoán từ", sub: "Nhìn hình, chọn đúng từ", emoji: "🖼️", audio: UI_AUDIO.word, guide: UI_AUDIO.guide_word },
  { id: "memory",   name: "Trí nhớ ghép cặp",  sub: "Lật thẻ tìm cặp giống nhau", emoji: "🃏", audio: UI_AUDIO.memory, guide: UI_AUDIO.guide_memory },
  { id: "sentence", name: "Ghép câu",          sub: "Kéo từ vào ô trống trong câu", emoji: "🧩", audio: UI_AUDIO.sentence, guide: UI_AUDIO.guide_sentence },
  { id: "spell",    name: "Đánh vần",          sub: "Nghe và xếp đúng chữ cái", emoji: "🔤", audio: UI_AUDIO.spell, guide: UI_AUDIO.guide_spell },
  { id: "senlisten", name: "Nghe câu chọn hình", sub: "Nghe cả câu, chạm đúng hình", emoji: "🎧", audio: UI_AUDIO.senlisten, guide: UI_AUDIO.guide_senlisten },
  { id: "oddone", name: "Tìm hình khác loại", sub: "3 hình giống, 1 hình khác", emoji: "🔍", audio: UI_AUDIO.oddone, guide: UI_AUDIO.guide_oddone },
  { id: "truefalse", name: "Đúng hay sai", sub: "Nghe rồi chọn đúng/sai", emoji: "✅", audio: UI_AUDIO.truefalse, guide: UI_AUDIO.guide_truefalse },
  { id: "counting", name: "Đếm số", sub: "Đếm rồi chọn số đúng", emoji: "🔢", audio: UI_AUDIO.counting, guide: UI_AUDIO.guide_counting },
];
let gameId = null, gameThemeId = "all", gameWords = [], gameSentences = [], gameRound = 0, gameMistakes = 0, gameScore = 0;
const ROUNDS = 6, SEN_ROUNDS = 4;

function renderGames() {
  const box = $("#game-list"); box.innerHTML = "";
  GAMES.forEach(g => {
    const keys = Object.keys(store.data.gameBest).filter(k => k.startsWith(g.id + ":"));
    const best = keys.length ? Math.max(...keys.map(k => store.data.gameBest[k])) : 0;
    const b = document.createElement("button");
    b.className = "game-card";
    b.innerHTML = `<span class="emoji">${g.emoji}</span>
      <span><span class="gname">${g.name}</span><br><span class="gsub">${g.sub}</span></span>
      <span class="gbest">${best ? "⭐".repeat(best) : ""}</span>`;
    b.addEventListener("click", () => setupGame(g.id));
    box.appendChild(b);
  });
}
function poolWords() {
  return (gameThemeId === "all" || gameThemeId === "daily" || gameThemeId === "exam") ? allWords() : themeById(gameThemeId).words;
}
function poolSentences() {
  const all = allSentences();
  return (gameThemeId === "all" || gameThemeId === "exam") ? all : all.filter(s => s.theme === gameThemeId);
}
function setupGame(id) {
  gameId = id;
  const g = GAMES.find(x => x.id === id);
  $("#setup-title").textContent = g.emoji + " " + g.name;
  const chips = $("#setup-chips"); chips.innerHTML = "";
  gameThemeId = "all";
  const mk = (tid, label) => {
    const c = document.createElement("button");
    c.className = "chip" + (tid === "all" ? " sel" : "");
    c.textContent = label;
    c.addEventListener("click", () => {
      gameThemeId = tid;
      $$("#setup-chips .chip").forEach(x => x.classList.remove("sel"));
      c.classList.add("sel");
    });
    chips.appendChild(c);
  };
  mk("all", "🎲 Trộn tất cả");
  LEVELS.forEach(l => themesOfLevel(l.id).forEach(t => mk(t.id, t.emoji + " " + t.name)));
  showScreen("screen-game-setup");
}
$("#setup-start").addEventListener("click", () => {
  const g = GAMES.find(x => x.id === gameId);
  gameRound = 0; gameMistakes = 0; gameScore = 0; resetCombo();
  if (gameId === "sentence") gameSentences = sample(poolSentences(), SEN_ROUNDS);
  else if (gameId === "counting") gameWords = sample(themeById("numbers").words.slice(0, 10), ROUNDS);
  else gameWords = sample(poolWords(), gameId === "memory" ? 6 : ROUNDS);
  showScreen("screen-game-play", false);
  history.push("screen-game-play");
  narrate(g.audio, 200, () => { if (g.guide) narrate(g.guide, 300); });
  nextRound();
});
function totalRounds() { return gameId === "sentence" ? SEN_ROUNDS : ROUNDS; }
function updateQProgress() {
  if (gameId === "exam") {
    const mm = Math.floor(examTimeLeft / 60), ss = String(examTimeLeft % 60).padStart(2, "0");
    $("#q-progress").textContent = `📝 Đề ${examNum} • ⏱️ ${mm}:${ss} • Câu ${Math.min(examIdx + 1, examQueue.length)}/${examQueue.length} • ⭐ ${gameScore}`;
    return;
  }
  if (gameId === "daily") {
    $("#q-progress").textContent = `Thử thách ${dailyIdx + 1}/${dailyQueue.length}   •   ⭐ ${gameScore}   •   🔥${streakCount()}`;
    return;
  }
  $("#q-progress").textContent = `Câu ${Math.min(gameRound + 1, totalRounds())} / ${totalRounds()}   •   ⭐ ${gameScore}`;
}
function nextRound() {
  if (gameId === "daily") { dailyIdx++; return nextDaily(); }
  if (gameId === "exam") { examIdx++; return nextExamQ(); }
  if (gameRound >= totalRounds() || (gameId === "memory" && gameRound >= 1)) return showResult();
  updateQProgress();
  // hiệu ứng câu hỏi trượt vào
  const qa = $("#q-area");
  if (qa) { qa.classList.remove("q-enter"); void qa.offsetWidth; qa.classList.add("q-enter"); }
  if (gameId === "listen") roundListen();
  else if (gameId === "word") roundWord();
  else if (gameId === "senlisten") roundSenlisten();
  else if (gameId === "oddone") roundOddone();
  else if (gameId === "truefalse") roundTrueFalse();
  else if (gameId === "counting") roundCounting();
  else if (gameId === "sentence") roundSentence();
  else if (gameId === "spell") roundSpell();
  else roundMemory();
}
function lockOpts() { $$("#q-area .opt").forEach(o => o.style.pointerEvents = "none"); }

// --- Game 1: nghe và chọn hình ---
function roundListen() {
  const target = gameWords[gameRound];
  const opts = sample(poolWords().filter(w => w.id !== target.id), 3);
  opts.push(target); const mixed = shuffle(opts);
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Nghe và chọn đúng hình!</span>`;
  const area = $("#q-area");
  area.innerHTML = `<div class="listen-big"><button class="speaker big" id="q-say2">🔊</button>
    <span class="txt">Bé nghe kỹ nhé!</span></div><div class="opt-grid"></div>`;
  const grid = area.querySelector(".opt-grid");
  mixed.forEach(w => {
    const b = document.createElement("button");
    b.className = "opt"; b.innerHTML = visualHTML(w);
    b.addEventListener("click", ev => {
      if (w.id === target.id) {
        b.classList.add("correct"); lockOpts(); gameScore++;
        praiseCorrect(ev.clientX, ev.clientY);
        setTimeout(() => { gameRound++; nextRound(); }, 1300);
      } else {
        b.classList.add("wrong"); noteMistake(target.id);
        encourageWrong();
        setTimeout(() => b.classList.remove("wrong"), 600);
      }
    });
    grid.appendChild(b);
  });
  const say = () => playAudio(wordAudio(target));
  $("#q-say").addEventListener("click", say);
  $("#q-say2").addEventListener("click", say);
  narrate(say, 600);
}

// --- Game 2: nhìn hình đoán từ ---
function roundWord() {
  const target = gameWords[gameRound];
  const opts = sample(poolWords().filter(w => w.id !== target.id), 3);
  opts.push(target); const mixed = shuffle(opts);
  $("#q-prompt").innerHTML = `<span class="big-q">Hình này là từ gì?</span>`;
  const area = $("#q-area");
  area.innerHTML = `<div class="page-img" style="height:200px">${visualBigHTML(target)}</div><div class="opt-grid"></div>`;
  const grid = area.querySelector(".opt-grid");
  mixed.forEach(w => {
    const b = document.createElement("button");
    b.className = "opt"; b.style.minHeight = "90px";
    b.innerHTML = `<span class="word">${w.en}</span>`;
    b.addEventListener("click", ev => {
      if (w.id === target.id) {
        b.classList.add("correct"); lockOpts(); gameScore++;
        praiseCorrect(ev.clientX, ev.clientY, wordAudio(target));
        setTimeout(() => { gameRound++; nextRound(); }, 1900);
      } else {
        b.classList.add("wrong"); noteMistake(target.id);
        encourageWrong();
        setTimeout(() => b.classList.remove("wrong"), 600);
      }
    });
    grid.appendChild(b);
  });
}

// --- Game 3: trí nhớ ghép cặp (hình <-> từ) ---
let memFirst = null, memLock = false, memFound = 0;
function roundMemory() {
  memFirst = null; memLock = false; memFound = 0;
  $("#q-progress").textContent = `Tìm đủ ${gameWords.length} cặp   •   ⭐ ${gameScore}`;
  $("#q-prompt").innerHTML = `<span class="big-q">Lật thẻ tìm cặp hình - từ!</span>`;
  const cards = [];
  gameWords.forEach(w => {
    cards.push({ w, side: "pic", html: visualHTML(w) });
    cards.push({ w, side: "word", html: `<span class="mword">${w.en}</span>` });
  });
  const area = $("#q-area");
  area.innerHTML = `<div class="mem-grid"></div>`;
  const grid = area.querySelector(".mem-grid");
  shuffle(cards).forEach(c => {
    const b = document.createElement("button");
    b.className = "mem-card"; b.innerHTML = "❓";
    b.addEventListener("click", () => {
      if (memLock || b.classList.contains("open") || b.classList.contains("done")) return;
      b.classList.add("open"); b.innerHTML = c.html;
      playAudio(wordAudio(c.w));
      if (!memFirst) { memFirst = { b, c }; return; }
      memLock = true;
      const a = memFirst; memFirst = null;
      if (a.c.w.id === c.w.id && a.c.side !== c.side) {
        setTimeout(() => {
          a.b.classList.add("done"); b.classList.add("done");
          gameScore++; memFound++;
          praiseCorrect(window.innerWidth / 2, 220);
          $("#q-progress").textContent = `Tìm đủ ${gameWords.length} cặp   •   ⭐ ${gameScore}`;
          memLock = false;
          if (memFound === gameWords.length) setTimeout(() => { gameRound = ROUNDS; showResult(); }, 900);
        }, 500);
      } else {
        noteMistake(c.w.id);
        combo = 0; updateComboBadge(); gameMistakes++;
        playAudio(UI_AUDIO.tryagain);
        setTimeout(() => {
          a.b.classList.remove("open"); a.b.innerHTML = "❓";
          b.classList.remove("open"); b.innerHTML = "❓";
          memLock = false;
        }, 800);
      }
    });
    grid.appendChild(b);
  });
}

// --- Game 4: GHÉP CÂU KÉO THẢ (kiểu Monkey Stories) ---
// Câu có các ô trống, mỗi ô hiện mờ từ cần điền. Bé kéo từ vào ô đúng
// (hoặc chạm vào từ để tự điền). Kéo thả bằng Pointer Events (chuột + cảm ứng).
function cleanWords(en) { return en.replace(/[.!?]$/, "").split(" "); }
const FILLER_WORDS = new Set(["a","an","the","is","are","was","were","in","on","at","to","and","or","of","my","your","his","her","its","our","their","this","that","these","those","it","i","you","we","they","he","she","me","him","us","them","do","does","did","can","could","with","for","as","so","but","by","from"]);
function roundSentence() {
  const s = gameSentences[gameRound];
  const words = cleanWords(s.en);
  const punct = s.en.match(/[.!?]$/) ? s.en.match(/[.!?]$/)[0] : "";
  // chọn ô trống: 45% chỉ điền 2-4 từ nội dung, còn lại xếp cả câu
  const contentIdx = words.map((w, i) => i).filter(i => !FILLER_WORDS.has(words[i].toLowerCase()));
  let blankIdx;
  if (Math.random() < 0.45 && contentIdx.length >= 2) {
    blankIdx = shuffle(contentIdx).slice(0, Math.min(4, Math.max(2, Math.ceil(contentIdx.length / 2))));
  } else {
    blankIdx = words.map((_, i) => i);
  }
  blankIdx.sort((a, b) => a - b);
  const isBlank = i => blankIdx.indexOf(i) !== -1;

  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Kéo từ vào ô trống!</span>`;
  const area = $("#q-area");
  area.innerHTML = `
    <div class="sen-hint">💡 ${s.vi}</div>
    <div class="drag-sen" id="drag-sen"></div>
    <div class="tile-bank" id="tile-bank"></div>
    <div class="drag-tip">👆 Kéo từ vào ô trống — hoặc chạm vào từ để tự điền</div>`;
  const say = () => playAudio(s.audio);
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);

  const senEl = area.querySelector("#drag-sen");
  const bank = area.querySelector("#tile-bank");

  // dựng câu: từ cố định + ô trống (hiện mờ từ gợi ý)
  words.forEach((w, i) => {
    const sp = document.createElement("span");
    if (isBlank(i)) {
      sp.className = "blank"; sp.dataset.i = i;
      sp.innerHTML = `<span class="ghost">${w}</span>`;
    } else {
      sp.className = "sw"; sp.textContent = w;
    }
    senEl.appendChild(sp);
  });
  if (punct) {
    const pg = document.createElement("span");
    pg.className = "punct"; pg.textContent = punct;
    senEl.appendChild(pg);
  }

  // khay từ (đảo thứ tự)
  shuffle(blankIdx.map(i => ({ i, w: words[i] }))).forEach(({ i, w }) => {
    const t = document.createElement("button");
    t.className = "tile"; t.textContent = w;
    t.dataset.w = w; t.dataset.i = i;
    t.addEventListener("pointerdown", onTileDown);
    bank.appendChild(t);
  });

  let dragTile = null, dragClone = null, hoverBlank = null;
  let startX = 0, startY = 0, moved = false, lastDrop = 0;

  const blanks = () => Array.from(senEl.querySelectorAll(".blank"));
  function blankAt(x, y) {
    const el = document.elementFromPoint(x, y);
    return el && el.closest ? el.closest(".blank") : null;
  }
  function placeTile(t, blank) {
    if (!blank || blank.classList.contains("filled")) return;
    const w = t.dataset.w;
    blank.classList.add("filled");
    blank.dataset.w = w;
    blank.innerHTML = `<span class="bw">${w}</span>`;
    t.classList.add("used");
    t.dataset.blank = blank.dataset.i;
    lastDrop = Date.now();
    const wo = WORD_BY_ID[w.toLowerCase()];
    if (wo) playAudio(wordAudio(wo));
    const r = blank.getBoundingClientRect();
    starBurst(r.left + r.width / 2, r.top - 10);
    if (blanks().every(b => b.classList.contains("filled"))) {
      setTimeout(checkDragSentence, 350);
    }
  }
  function unfillBlank(b) {
    const i = b.dataset.i;
    const tile = Array.from(bank.querySelectorAll(".tile")).find(t => t.dataset.blank === String(i));
    if (tile) { tile.classList.remove("used"); delete tile.dataset.blank; }
    b.classList.remove("filled");
    delete b.dataset.w;
    b.innerHTML = `<span class="ghost">${words[i]}</span>`;
  }
  function checkDragSentence() {
    const bs = blanks();
    let allOk = true;
    bs.forEach(b => {
      const ok = b.dataset.w === words[+b.dataset.i];
      b.classList.toggle("wrong", !ok);
      if (!ok) allOk = false;
    });
    if (allOk) {
      gameScore++;
      playAudio(s.audio, () => {
        const r = senEl.getBoundingClientRect();
        praiseCorrect(r.left + r.width / 2, r.top);
        setTimeout(() => { gameRound++; nextRound(); }, 1700);
      });
    } else {
      encourageWrong();
      setTimeout(() => {
        bs.forEach(b => {
          if (b.classList.contains("wrong")) { b.classList.remove("wrong"); unfillBlank(b); }
        });
      }, 1200);
    }
  }
  function autoPlace(t) {
    const b = blanks().find(x => !x.classList.contains("filled"));
    if (b) placeTile(t, b);
  }
  // chạm vào ô đã điền -> trả từ về khay (để sửa)
  senEl.addEventListener("click", e => {
    const b = e.target && e.target.closest ? e.target.closest(".blank") : null;
    if (b && b.classList.contains("filled") && Date.now() - lastDrop > 400) unfillBlank(b);
  });
  // ---- kéo thả ----
  function onTileDown(e) {
    const t = e.currentTarget;
    if (t.classList.contains("used")) return;
    e.preventDefault();
    dragTile = t; moved = false; hoverBlank = null;
    startX = e.clientX; startY = e.clientY;
    t.classList.add("drag-src");
    dragClone = t.cloneNode(true);
    dragClone.classList.add("drag-clone");
    dragClone.classList.remove("drag-src");
    dragClone.style.display = "none";
    moveClone(e.clientX, e.clientY);
    document.body.appendChild(dragClone);
    window.addEventListener("pointermove", onTileMove);
    window.addEventListener("pointerup", onTileUp, { once: true });
    window.addEventListener("pointercancel", onTileUp, { once: true });
  }
  function moveClone(x, y) {
    dragClone.style.left = x + "px";
    dragClone.style.top = y + "px";
  }
  function onTileMove(e) {
    if (!dragTile) return;
    if (!moved && Math.hypot(e.clientX - startX, e.clientY - startY) > 12) {
      moved = true;
      dragClone.style.display = "";
    }
    if (!moved) return;
    moveClone(e.clientX, e.clientY);
    const b = blankAt(e.clientX, e.clientY);
    if (hoverBlank && hoverBlank !== b) hoverBlank.classList.remove("hover");
    hoverBlank = (b && !b.classList.contains("filled")) ? b : null;
    if (hoverBlank) hoverBlank.classList.add("hover");
  }
  function onTileUp(e) {
    window.removeEventListener("pointermove", onTileMove);
    const t = dragTile;
    dragTile = null;
    if (dragClone) { dragClone.remove(); dragClone = null; }
    if (t) t.classList.remove("drag-src");
    if (hoverBlank) hoverBlank.classList.remove("hover");
    if (!t) return;
    if (!moved) autoPlace(t);       // chạm nhẹ = tự điền vào ô trống đầu tiên
    else if (hoverBlank) placeTile(t, hoverBlank);
    hoverBlank = null;
  }
}

// --- Kết quả ---
// ---------- Chấm điểm /10 + xếp loại ----------
function gradeOf(s10) {
  if (s10 >= 9) return { t: "Xuất sắc", e: "🏆" };
  if (s10 >= 7) return { t: "Giỏi", e: "🌟" };
  if (s10 >= 5) return { t: "Khá", e: "👍" };
  if (s10 >= 3) return { t: "Cần cố gắng", e: "💪" };
  return { t: "Đừng nản chí", e: "🌱" };
}
function saveGameScore(gid, score10) {
  const k = "score:" + gid;
  if ((store.data.gameScores[k] || 0) < score10) { store.data.gameScores[k] = score10; store.save(); }
}
function showResult() {
  const stars = gameMistakes === 0 ? 3 : gameMistakes <= 2 ? 2 : 1;
  const key = gameId + ":" + gameThemeId;
  if ((store.data.gameBest[key] || 0) < stars) store.data.gameBest[key] = stars;
  store.data.gamePlays++;
  addStars(stars);
  $("#result-emoji").textContent = stars === 3 ? "🎉" : stars === 2 ? "😊" : "💪";
  $("#result-title").textContent = stars === 3 ? "Tuyệt vời!" : stars === 2 ? "Giỏi lắm!" : "Cố lên bé nhé!";
  $("#result-stars").innerHTML = [1, 2, 3].map(i => `<span class="${i <= stars ? "" : "off"}">⭐</span>`).join("");
  const totalQ = totalRounds();
  const score10 = Math.round(gameScore / totalQ * 10);
  const gr = gradeOf(score10);
  saveGameScore(gameId, score10);
  $("#result-sub").innerHTML = `${gr.e} <b>${gr.t}</b>!<br>Bé được <b>${gameScore}/${totalQ}</b> điểm (thang 10: <b>${score10}</b>), nhận ${stars} ngôi sao!`;
  showScreen("screen-result", false);
  history.push("screen-result");
  playAudio(UI_AUDIO.welldone);
  if (score10 >= 7) confetti();
}
$("#result-home").addEventListener("click", () => showScreen("screen-home"));
$("#result-again").addEventListener("click", () => {
  if (gameId === "daily") { startDaily(); return; }
  if (gameId === "exam") { startExam(examNum); return; }
  gameRound = 0; gameMistakes = 0; gameScore = 0;
  if (gameId === "sentence") gameSentences = sample(poolSentences(), SEN_ROUNDS);
  else if (gameId === "counting") gameWords = sample(themeById("numbers").words.slice(0, 10), ROUNDS);
  else gameWords = sample(poolWords(), gameId === "memory" ? 6 : ROUNDS);
  resetCombo();
  showScreen("screen-game-play", false);
  history.push("screen-game-play");
  narrate(g.audio, 200, () => { if (g.guide) narrate(g.guide, 300); });
  nextRound();
});

// ============================================================
// TRUYỆN
// ============================================================
let story = null, pageIdx = 0;
function renderStories() {
  const box = $("#story-list"); box.innerHTML = "";
  STORIES.forEach(s => {
    const read = store.data.stories[s.id];
    const b = document.createElement("button");
    b.className = "story-card";
    b.innerHTML = `<span class="emoji">${s.emoji}</span>
      <span><span class="sname">${s.title}</span><br><span class="svi">${s.vi}</span></span>
      <span class="smeta">${read ? "✅ Đã đọc" : s.pages.length + " trang"}</span>`;
    b.addEventListener("click", () => startStory(s.id));
    box.appendChild(b);
  });
}
function startStory(id) {
  story = STORIES.find(s => s.id === id); pageIdx = 0;
  renderPage();
  showScreen("screen-story-read", true, () => playAudio(story.pages[pageIdx].audio));
}
function renderPage() {
  const p = story.pages[pageIdx];
  $("#page-img").src = p.img;
  $("#page-en").textContent = p.en;
  $("#page-vi").textContent = p.vi;
  $("#page-num").textContent = `${pageIdx + 1} / ${story.pages.length}`;
  $("#page-prev").disabled = pageIdx === 0;
  $("#page-next").textContent = pageIdx === story.pages.length - 1 ? "🏁 Xong" : "▶";
  if (pageIdx === story.pages.length - 1 && !store.data.stories[story.id]) {
    store.data.stories[story.id] = true; addStars(2); store.save();
    setTimeout(() => toast("📖 +2 ⭐ Đọc xong truyện!"), 1200);
  }
}
$("#page-prev").addEventListener("click", () => { if (pageIdx > 0) { pageIdx--; renderPage(); playAudio(story.pages[pageIdx].audio); } });
$("#page-next").addEventListener("click", () => {
  if (pageIdx < story.pages.length - 1) { pageIdx++; renderPage(); playAudio(story.pages[pageIdx].audio); }
  else goBack();
});
$("#page-say").addEventListener("click", () => playAudio(story.pages[pageIdx].audio));

// ============================================================
// THÀNH TÍCH
// ============================================================
function renderProgress() {
  $("#st-stars").textContent = store.data.stars;
  $("#st-words").textContent = Object.keys(store.data.seen).length;
  $("#st-stories").textContent = Object.keys(store.data.stories).length;
  $("#st-games").textContent = store.data.gamePlays;
  const box = $("#progress-rows"); box.innerHTML = "";
  const rk = document.createElement("div");
  rk.className = "rank-banner";
  rk.innerHTML = `<span style="font-size:30px">${kidRank().split(" ")[0]}</span><span><b>${kidRank().slice(kidRank().indexOf(" ") + 1)}</b><br><span style="font-size:13px;color:var(--ink-soft)">${store.data.stars} ⭐ — càng học càng lên hạng!</span></span>`;
  box.appendChild(rk);
  LEVELS.forEach(l => {
    const themes = themesOfLevel(l.id);
    if (!themes.length) return;
    const lh = document.createElement("div");
    lh.className = "level-head"; lh.style.marginTop = "14px";
    lh.innerHTML = `<span>${l.emoji} ${l.name}</span>`;
    box.appendChild(lh);
    themes.forEach(t => {
      const seen = t.words.filter(w => store.data.seen[w.id]).length;
      const senSeen = t.sentences.filter((s, i) => store.data.senSeen[t.id + ":" + i]).length;
      const pct = Math.round(seen / t.words.length * 100);
      const d = document.createElement("div");
      d.className = "prow";
      d.innerHTML = `<div class="ph"><span>${t.emoji} ${t.name}</span><span>📚${seen}/${t.words.length} · 📝${senSeen}/${t.sentences.length}</span></div>
        <div class="pbar"><div style="width:${pct}%"></div></div>`;
      box.appendChild(d);
    });
  });
  const g = document.createElement("div");
  g.className = "prow"; g.style.marginTop = "14px";
  const scoreRows = GAMES.map(gm => {
    const sc = store.data.gameScores["score:" + gm.id] || 0;
    const gr = sc > 0 ? gradeOf(sc) : null;
    const keys = Object.keys(store.data.gameBest).filter(k => k.startsWith(gm.id + ":"));
    const best = keys.length ? Math.max(...keys.map(k => store.data.gameBest[k])) : 0;
    return `<div class="srow"><span>${gm.emoji} ${gm.name}</span>` +
      `<span>${sc > 0 ? `<b>${sc}/10</b> ${gr.e} ${gr.t}` : "—"}` +
      `${best ? ` · ${"⭐".repeat(best)}` : ""}</span></div>`;
  }).join("");
  g.innerHTML = `<div class="ph"><span>🏅 Bảng điểm trò chơi</span></div>${scoreRows}`;
  box.appendChild(g);
}
$("#btn-reset").addEventListener("click", () => {
  if (confirm("Xóa hết sao và tiến trình học của bé?")) {
    store.reset(); refreshStarPill(); renderProgress(); toast("Đã xóa tiến trình 🗑️");
  }
});

// ---------- Khởi động (phần 1): tải dữ liệu ----------
store.load();
// màn hình đầu tiên do đoạn cuối file quyết định (welcome nếu chưa có tên bé)

// ============================================================
// TÍNH NĂNG MỚI: đánh vần, thử thách ngày, tô chữ, thú cưng, từ điển
// ============================================================

// ---------- Ghi nhận từ bé hay làm sai (để ôn tập thông minh) ----------
function noteMistake(wordId) {
  const m = store.data.mistakes || (store.data.mistakes = {});
  m[wordId] = (m[wordId] || 0) + 1;
  store.save();
}
function topMistakeWords(n) {
  const m = store.data.mistakes || {};
  return Object.keys(m).sort((a, b) => m[b] - m[a])
    .map(id => WORD_BY_ID[id]).filter(Boolean).slice(0, n);
}

// ---------- Streak (ngày học liên tiếp) ----------
function streakCount() { return (store.data.streak && store.data.streak.count) || 0; }
function todayStr(d) { return new Date(d).toISOString().slice(0, 10); }
function bumpStreak() {
  const today = todayStr(Date.now());
  const yest = todayStr(Date.now() - 864e5);
  const st = store.data.streak || { count: 0, last: "" };
  if (st.last !== today) {
    st.count = (st.last === yest) ? st.count + 1 : 1;
    st.last = today;
    store.data.streak = st; store.save();
  }
  return st.count;
}

// ============================================================
// GAME 5: ĐÁNH VẦN (nghe từ, xếp chữ cái)
// ============================================================
function roundSpell() {
  const target = gameWords[gameRound];
  const letters = target.en.toLowerCase().replace(/ /g, "").split("");
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Nghe và xếp chữ cái!</span>`;
  const area = $("#q-area");
  area.innerHTML = `
    <div class="page-img" style="height:170px">${visualBigHTML(target)}</div>
    <div class="answer-line" id="ans-line"><span class="ans-ph">Chạm chữ cái theo thứ tự...</span></div>
    <div class="chip-row" id="word-chips" style="justify-content:center"></div>`;
  const say = () => playAudio(wordAudio(target));
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);

  const chipBox = area.querySelector("#word-chips");
  const ansLine = area.querySelector("#ans-line");
  const picked = [];
  const renderAns = () => {
    ansLine.innerHTML = picked.length
      ? picked.map(l => `<span class="wchip-picked">${l.toUpperCase()}</span>`).join("")
      : `<span class="ans-ph">Chạm chữ cái theo thứ tự...</span>`;
  };
  const resetChips = () => {
    picked.length = 0; renderAns();
    chipBox.innerHTML = "";
    shuffle(letters).forEach(l => {
      const c = document.createElement("button");
      c.className = "wchip letter"; c.textContent = l.toUpperCase();
      c.addEventListener("click", () => {
        picked.push(l); c.style.visibility = "hidden";
        playAudio("audio/letter_" + l + ".mp3");
        renderAns();
        if (picked.length === letters.length) {
          const ok = picked.every((pl, i) => pl === letters[i]);
          if (ok) {
            gameScore++;
            ansLine.classList.add("correct");
            const r = ansLine.getBoundingClientRect();
            praiseCorrect(r.left + r.width / 2, r.top, wordAudio(target));
            setTimeout(() => { gameRound++; nextRound(); }, 2100);
          } else {
            noteMistake(target.id);
            encourageWrong();
            ansLine.classList.add("wrong");
            setTimeout(() => { ansLine.classList.remove("wrong"); resetChips(); }, 900);
          }
        }
      });
      chipBox.appendChild(c);
    });
  };
  renderAns(); resetChips();
}

// ============================================================
// THỬ THÁCH HẰNG NGÀY (8 câu trộn, ưu tiên từ hay sai)
// ============================================================
let dailyQueue = [], dailyIdx = 0;
function startDaily() {
  const hard = topMistakeWords(4);
  const rest = sample(allWords().filter(w => !hard.includes(w)), 10 - hard.length);
  const ws = shuffle([...hard, ...rest]);
  const sens = sample(allSentences(), 2);
  const nums10 = themeById("numbers").words.slice(0, 10);
  dailyQueue = [
    { k: "listen", w: ws[0] }, { k: "listen", w: ws[1] },
    { k: "word", w: ws[2] },   { k: "word", w: ws[3] },
    { k: "spell", w: ws[4] },  { k: "spell", w: ws[5] },
    { k: "senlisten", w: ws[6] },
    { k: "sentence", s: sens[0] }, { k: "sentence", s: sens[1] },
    { k: "oddone", w: ws[7] }, { k: "truefalse", w: ws[8] },
    { k: "counting", w: sample(nums10, 1)[0] },
  ];
  gameId = "daily"; gameThemeId = "daily";
  gameRound = 0; gameMistakes = 0; gameScore = 0; dailyIdx = 0;
  resetCombo();
  showScreen("screen-game-play", false);
  history.push("screen-game-play");
  nextDaily();
}
function nextDaily() {
  if (dailyIdx >= dailyQueue.length) return finishDaily();
  updateQProgress();
  const qa = $("#q-area");
  if (qa) { qa.classList.remove("q-enter"); void qa.offsetWidth; qa.classList.add("q-enter"); }
  const q = dailyQueue[dailyIdx];
  gameRound = 0;
  if (q.k === "listen") { gameWords = [q.w]; roundListen(); }
  else if (q.k === "word") { gameWords = [q.w]; roundWord(); }
  else if (q.k === "spell") { gameWords = [q.w]; roundSpell(); }
  else if (q.k === "senlisten") { gameWords = [q.w]; roundSenlisten(); }
  else if (q.k === "oddone") { gameWords = [q.w]; roundOddone(); }
  else if (q.k === "truefalse") { gameWords = [q.w]; roundTrueFalse(); }
  else if (q.k === "counting") { gameWords = [q.w]; roundCounting(); }
  else { gameSentences = [q.s]; roundSentence(); }
}
function finishDaily() {
  const streak = bumpStreak();
  const stars = gameMistakes === 0 ? 3 : gameMistakes <= 3 ? 2 : 1;
  const bonus = 2 + Math.min(streak, 5);
  const key = "daily:daily";
  if ((store.data.gameBest[key] || 0) < stars) store.data.gameBest[key] = stars;
  store.data.gamePlays++;
  addStars(stars + bonus);
  $("#result-emoji").textContent = "📅";
  $("#result-title").textContent = "Xong thử thách ngày!";
  $("#result-stars").innerHTML = [1, 2, 3].map(i => `<span class="${i <= stars ? "" : "off"}">⭐</span>`).join("");
  $("#result-sub").textContent = `${kidName()} được ${gameScore}/12 điểm, 🔥 ${streak} ngày liên tiếp, thưởng +${bonus} ⭐!`;
  showScreen("screen-result", false);
  history.push("screen-result");
  playAudio(UI_AUDIO.welldone);
  confetti();
}
// ============================================================
// THI THỬ: 100 đề ngẫu nhiên có sẵn (seed theo số đề)
// ============================================================
const EXAM_COUNT = 100, EXAM_QS = 20, EXAM_TIME = 15 * 60;
const EXAM_TYPES = ["listen", "word", "spell", "sentence", "senlisten", "oddone", "truefalse", "counting"];
let examNum = 0, examQueue = [], examIdx = 0, examTimeLeft = 0;
function mulberry32(a) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function renderExams() {
  const grid = $("#exam-grid"); grid.innerHTML = "";
  let bestTotal = 0, doneCount = 0;
  for (let n = 1; n <= EXAM_COUNT; n++) {
    const best = store.data.examBest["exam" + n];
    if (best != null) { doneCount++; bestTotal += best; }
    const b = document.createElement("button");
    b.className = "exam-cell" + (best >= 7 ? " good" : best != null ? " done" : "");
    b.innerHTML = `<span class="enum">${n}</span>` + (best != null ? `<span class="escore">${best}/10</span>` : "");
    b.addEventListener("click", () => startExam(n));
    grid.appendChild(b);
  }
  $("#exam-stats").innerHTML = doneCount
    ? `Đã thi <b>${doneCount}/${EXAM_COUNT}</b> đề · Điểm TB: <b>${(bestTotal / doneCount).toFixed(1)}/10</b>`
    : `Chưa thi đề nào — chọn 1 đề để bắt đầu!`;
}
function startExam(n) {
  const rnd = mulberry32(n * 100003 + 7);
  const words = allWords(), sens = allSentences();
  const nums = themeById("numbers").words.slice(0, 10);
  const pick = arr => arr[Math.floor(rnd() * arr.length)];
  examQueue = [];
  for (let i = 0; i < EXAM_QS; i++) {
    const k = EXAM_TYPES[i % EXAM_TYPES.length];
    if (k === "sentence") examQueue.push({ k, s: pick(sens) });
    else if (k === "counting") examQueue.push({ k, w: pick(nums) });
    else examQueue.push({ k, w: pick(words) });
  }
  examNum = n; examIdx = 0;
  gameId = "exam"; gameThemeId = "exam";
  gameRound = 0; gameMistakes = 0; gameScore = 0;
  resetCombo();
  examTimeLeft = EXAM_TIME;
  if (examTimer) clearInterval(examTimer);
  showScreen("screen-game-play", false);
  history.push("screen-game-play");
  nextExamQ();
  examTimer = setInterval(() => {
    examTimeLeft--;
    if (examTimeLeft <= 0) { finishExam(true); return; }
    updateQProgress();
  }, 1000);
}
function nextExamQ() {
  if (examIdx >= examQueue.length) return finishExam(false);
  updateQProgress();
  const qa = $("#q-area");
  if (qa) { qa.classList.remove("q-enter"); void qa.offsetWidth; qa.classList.add("q-enter"); }
  const q = examQueue[examIdx];
  gameRound = 0;
  if (q.k === "listen") { gameWords = [q.w]; roundListen(); }
  else if (q.k === "word") { gameWords = [q.w]; roundWord(); }
  else if (q.k === "spell") { gameWords = [q.w]; roundSpell(); }
  else if (q.k === "senlisten") { gameWords = [q.w]; roundSenlisten(); }
  else if (q.k === "oddone") { gameWords = [q.w]; roundOddone(); }
  else if (q.k === "truefalse") { gameWords = [q.w]; roundTrueFalse(); }
  else if (q.k === "counting") { gameWords = [q.w]; roundCounting(); }
  else { gameSentences = [q.s]; roundSentence(); }
}
function finishExam(timeout) {
  if (examTimer) { clearInterval(examTimer); examTimer = null; }
  const total = examQueue.length || EXAM_QS;
  const score10 = Math.round(gameScore / total * 10);
  const gr = gradeOf(score10);
  const key = "exam" + examNum;
  const isBest = score10 > (store.data.examBest[key] || 0);
  if (isBest) { store.data.examBest[key] = score10; store.save(); }
  store.data.gamePlays++;
  const bonus = score10 >= 9 ? 5 : score10 >= 7 ? 3 : score10 >= 5 ? 2 : 1;
  addStars(bonus);
  const stars = score10 >= 9 ? 3 : score10 >= 7 ? 2 : score10 >= 5 ? 1 : 0;
  $("#result-emoji").textContent = timeout ? "⏱️" : gr.e;
  $("#result-title").textContent = timeout ? "Hết giờ!" : "Nộp bài thi!";
  $("#result-stars").innerHTML = [1, 2, 3].map(i => `<span class="${i <= stars ? "" : "off"}">⭐</span>`).join("");
  $("#result-sub").innerHTML = `📝 Đề <b>${examNum}</b>: đúng <b>${gameScore}/${total}</b> câu ` +
    `(thang 10: <b>${score10}</b>) — ${gr.e} <b>${gr.t}</b>!` +
    (isBest ? `<br>🎉 <b>Kỷ lục mới!</b> +${bonus} ⭐` : `<br>+${bonus} ⭐`);
  showScreen("screen-result", false);
  history.push("screen-result");
  playAudio(score10 >= 5 ? UI_AUDIO.welldone : UI_AUDIO.tryagain);
  if (score10 >= 7) confetti();
}
// ============================================================
// TÔ CHỮ (tập viết chữ cái trên canvas)
// ============================================================
let traceTheme = null, traceWordIdx = 0, traceLetterIdx = 0, tracePool = [];
function initTrace() {
  const chips = $("#trace-chips"); chips.innerHTML = "";
  LEVELS.forEach(l => themesOfLevel(l.id).forEach(t => {
    const c = document.createElement("button");
    c.className = "chip"; c.textContent = t.emoji + " " + t.name;
    c.addEventListener("click", () => {
      $$("#trace-chips .chip").forEach(x => x.classList.remove("sel"));
      c.classList.add("sel");
      startTrace(t.id);
    });
    chips.appendChild(c);
  }));
  showScreen("screen-trace");
  // chọn chủ đề đầu tiên mặc định
  const first = chips.querySelector(".chip");
  if (first) first.click();
}
function startTrace(themeId) {
  traceTheme = themeById(themeId);
  tracePool = traceTheme.words.filter(w => !w.en.includes(" "));
  traceWordIdx = 0; traceLetterIdx = 0;
  drawTrace();
}
function traceCanvas() { return $("#trace-canvas"); }
function drawTraceLetter() {
  const cv = traceCanvas(), ctx = cv.getContext("2d");
  const w = tracePool[traceWordIdx];
  const ch = w.en.toUpperCase()[traceLetterIdx];
  const W = cv.width, H = cv.height;
  ctx.clearRect(0, 0, W, H);
  // lưới chấm mờ làm nền cho cao cấp
  ctx.save();
  ctx.fillStyle = "rgba(74,144,217,0.12)";
  for (let gx = 26; gx < W; gx += 46) {
    for (let gy = 26; gy < H; gy += 46) {
      ctx.beginPath(); ctx.arc(gx, gy, 2.5, 0, 7); ctx.fill();
    }
  }
  ctx.restore();
  const cx = W / 2, cy = H / 2 + 10;
  ctx.save();
  ctx.font = "900 300px 'Baloo 2', 'Comic Sans MS', sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  // bóng chữ mờ định hình
  ctx.globalAlpha = 0.10;
  ctx.fillStyle = "#4A90D9";
  ctx.fillText(ch, cx, cy);
  ctx.globalAlpha = 1;
  // CHẤM TRÒN TO theo nét chữ — bé tô theo các chấm này
  ctx.setLineDash([0.1, 26]);
  ctx.lineCap = "round";
  ctx.lineWidth = 16;
  ctx.strokeStyle = "#4A90D9";
  ctx.strokeText(ch, cx, cy);
  ctx.restore();
  // dải tiến trình chữ cái của từ
  const letters = $("#trace-letters");
  if (letters) {
    letters.innerHTML = "";
    const up = w.en.toUpperCase();
    for (let i = 0; i < up.length; i++) {
      const sp = document.createElement("span");
      sp.className = "tl" + (i < traceLetterIdx ? " done" : i === traceLetterIdx ? " now" : "");
      sp.textContent = up[i];
      letters.appendChild(sp);
    }
  }
  $("#trace-word").innerHTML =
    `<span class="trace-en">${w.en}</span> <span class="trace-vi">${w.vi}</span>
     <span class="trace-count">Chữ ${traceLetterIdx + 1}/${w.en.length} · Từ ${traceWordIdx + 1}/${tracePool.length}</span>`;
  const nx = $("#trace-next");
  if (nx) nx.textContent = traceLetterIdx === w.en.length - 1 ? "Từ tiếp ▶" : "Chữ tiếp ▶";
}
function drawTrace() { drawTraceLetter(); initTraceTouch(); }
let traceDrawing = false;
function initTraceTouch() {
  const cv = traceCanvas();
  const pos = e => {
    const r = cv.getBoundingClientRect();
    const t = e.touches[0];
    return [(t.clientX - r.left) * cv.width / r.width, (t.clientY - r.top) * cv.height / r.height];
  };
  cv.ontouchstart = e => {
    e.preventDefault(); traceDrawing = true;
    const ctx = cv.getContext("2d"), [x, y] = pos(e);
    ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineWidth = 34; ctx.lineCap = "round"; ctx.strokeStyle = "#FF7043";
    ctx.lineTo(x + 0.1, y + 0.1); ctx.stroke();
  };
  cv.ontouchmove = e => {
    e.preventDefault();
    if (!traceDrawing) return;
    const ctx = cv.getContext("2d"), [x, y] = pos(e);
    ctx.lineTo(x, y); ctx.stroke();
  };
  cv.ontouchend = () => { traceDrawing = false; };
  // chuột cho lúc test trên máy tính
  cv.onmousedown = e => {
    traceDrawing = true;
    const r = cv.getBoundingClientRect();
    const ctx = cv.getContext("2d");
    const x = (e.clientX - r.left) * cv.width / r.width, y = (e.clientY - r.top) * cv.height / r.height;
    ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineWidth = 34; ctx.lineCap = "round"; ctx.strokeStyle = "#FF7043";
  };
  cv.onmousemove = e => {
    if (!traceDrawing) return;
    const r = cv.getBoundingClientRect();
    const ctx = cv.getContext("2d");
    ctx.lineTo((e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height);
    ctx.stroke();
  };
  cv.onmouseup = () => { traceDrawing = false; };
}
$("#trace-clear").addEventListener("click", drawTraceLetter);
$("#trace-say").addEventListener("click", () => {
  if (tracePool.length) playAudio(wordAudio(tracePool[traceWordIdx]));
});
let traceJustFinished = false; // vừa tô xong 1 từ -> bỏ qua tiếng chữ cái
$("#trace-next").addEventListener("click", () => {
  const w = tracePool[traceWordIdx];
  if (traceLetterIdx < w.en.length - 1) { traceLetterIdx++; }
  else {
    traceLetterIdx = 0;
    traceJustFinished = true;
    addStars(1);
    traceWordIdx = (traceWordIdx + 1) % tracePool.length;
    const p = pickPraise();
    playAudio(p.audio);
    miniConfetti();
    toast(`⭐ +1 Bé tô xong từ "${w.en}"!`);
  }
  drawTraceLetter();
});

// ============================================================
// THÚ CƯNG MOMO
// ============================================================
function petState() {
  const p = store.data.pet || (store.data.pet = { happiness: 60, fed: 0, last: todayStr(Date.now()) });
  // giảm vui vẻ theo ngày không vào thăm
  const days = Math.round((Date.now() - new Date(p.last + "T00:00:00").getTime()) / 864e5);
  if (days > 0) { p.happiness = Math.max(0, p.happiness - days * 10); p.last = todayStr(Date.now()); store.save(); }
  return p;
}
function renderPet() {
  const p = petState();
  $("#pet-img").src = p.happiness >= 50 ? "img/pet_happy.png" : "img/pet_hungry.png";
  $("#pet-happy-bar").style.width = p.happiness + "%";
  $("#pet-msg").textContent =
    p.happiness >= 80 ? "Momo đang rất vui! 🎉" :
    p.happiness >= 50 ? "Momo thấy ổn. Cho Momo ăn nhé! 🍌" :
    p.happiness >= 20 ? "Momo hơi đói bụng... 🥺" : "Momo đói lắm rồi! Cho Momo ăn đi! 😢";
  showScreen("screen-pet");
}
$("#pet-feed").addEventListener("click", ev => {
  const p = petState();
  if (store.data.stars < 5) { toast("Bé chưa đủ 5 ⭐ để mua đồ ăn!"); playAudio(UI_AUDIO.tryagain); return; }
  store.data.stars -= 5; p.happiness = Math.min(100, p.happiness + 25); p.fed++;
  store.save(); refreshStarPill();
  playAudio(UI_AUDIO.pet_yum);
  starBurst(ev.clientX, ev.clientY);
  renderPet();
  setTimeout(() => toast("🍌 Momo cảm ơn bé!"), 800);
});

// ============================================================
// TỪ ĐIỂN (tra 100 từ)
// ============================================================
function renderDict() {
  const grid = $("#dict-grid");
  const q = ($("#dict-search").value || "").toLowerCase().trim();
  grid.innerHTML = "";
  allWords()
    .filter(w => !q || w.en.toLowerCase().includes(q) || w.vi.toLowerCase().includes(q))
    .forEach(w => {
      const d = document.createElement("button");
      d.className = "dict-item";
      d.innerHTML = `${visualHTML(w, "dict-vis")}<span class="dict-en">${w.en}</span><span class="dict-vi">${w.vi}</span>`;
      d.addEventListener("click", () => playAudio(wordAudio(w)));
      grid.appendChild(d);
    });
  if (!grid.children.length) grid.innerHTML = `<p style="grid-column:1/-1;text-align:center;color:var(--ink-soft)">Không tìm thấy từ nào 🔍</p>`;
  showScreen("screen-dict");
}
$("#dict-search").addEventListener("input", () => {
  // render lại mà không push history
  const grid = $("#dict-grid");
  const q = ($("#dict-search").value || "").toLowerCase().trim();
  grid.innerHTML = "";
  allWords()
    .filter(w => !q || w.en.toLowerCase().includes(q) || w.vi.toLowerCase().includes(q))
    .forEach(w => {
      const d = document.createElement("button");
      d.className = "dict-item";
      d.innerHTML = `${visualHTML(w, "dict-vis")}<span class="dict-en">${w.en}</span><span class="dict-vi">${w.vi}</span>`;
      d.addEventListener("click", () => playAudio(wordAudio(w)));
      grid.appendChild(d);
    });
});

// ============================================================
// TƯƠNG TÁC MỚI: chào hỏi, đọc theo, thú cưng, tô chữ có tiếng
// ============================================================

// Chạm linh vật Momo trên trang chủ -> chào bằng tiếng Anh
$("#mascot").addEventListener("click", ev => {
  playAudio(UI_AUDIO.hello);
  const m = $("#mascot");
  m.classList.remove("wiggle"); void m.offsetWidth; m.classList.add("wiggle");
  starBurst(ev.clientX, ev.clientY);
});

// Đọc theo trên flashcard: bé đọc to rồi tự chấm
$("#flash-read-btn").addEventListener("click", () => {
  const w = learnTheme.words[learnIdx];
  playAudio(wordAudio(w));
  $("#flash-read").style.display = "flex";
});
$("#flash-read-done").addEventListener("click", () => {
  const w = learnTheme.words[learnIdx];
  const rw = store.data.readWords || (store.data.readWords = {});
  if (!rw[w.id]) {
    rw[w.id] = true; store.save();
    addStars(1);
    toast("⭐ +1 Bé đọc giỏi quá!");
    playAudio(UI_AUDIO.great);
  } else {
    toast("Bé đọc hay lắm! 🎉");
    playAudio(UI_AUDIO.good);
  }
  $("#flash-read").style.display = "none";
});
// chuyển từ thì ẩn khung đọc theo
["flash-prev", "flash-next"].forEach(id =>
  document.getElementById(id).addEventListener("click", () => {
    document.getElementById("flash-read").style.display = "none";
  }));

// Chạm vào thú cưng -> Momo phản ứng
const PET_MSGS = ["Hi hi! Bé chơi với Momo nhé! 🐵", "Momo thích bé lắm! 💛", "Bé học giỏi quá! 🎉", "Cho Momo ăn nữa đi! 🍌", "Hôm nay bé học gì nào? 📚"];
$("#pet-img").addEventListener("click", ev => {
  const msgs = PET_MSGS;
  $("#pet-msg").textContent = msgs[Math.floor(Math.random() * msgs.length)];
  if (Math.random() < 0.4) playAudio(UI_AUDIO.pet_yum);
  else playAudio(UI_AUDIO.good);
  starBurst(ev.clientX, ev.clientY);
});

// Tô chữ: đọc tên chữ cái mỗi khi sang chữ mới (trừ lúc vừa ăn mừng xong từ)
const _traceNext = document.getElementById("trace-next");
_traceNext.addEventListener("click", () => {
  if (traceJustFinished) { traceJustFinished = false; return; }
  setTimeout(() => {
    if (tracePool.length) {
      const w = tracePool[traceWordIdx];
      const ch = w.en.toLowerCase().replace(/ /g, "")[traceLetterIdx];
      if (ch) playAudio("audio/letter_" + ch + ".mp3");
    }
  }, 400);
});

// ============================================================
// GAME 6: NGHE CÂU CHỌN HÌNH (nghe cả câu, chọn đúng hình)
// ============================================================
function themeOfWord(wordId) {
  return THEMES.find(t => t.words.some(w => w.id === wordId)) || null;
}
function roundSenlisten() {
  const target = gameWords[gameRound];
  const theme = themeOfWord(target.id);
  let sen = null;
  if (theme) {
    const cands = theme.sentences.filter(s => s.en.toLowerCase().includes(target.en.toLowerCase()));
    if (cands.length) sen = cands[Math.floor(Math.random() * cands.length)];
  }
  const audioSrc = sen ? sen.audio : wordAudio(target);
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Nghe câu và chọn hình!</span>`;
  const area = $("#q-area"); area.innerHTML = "";
  const grid = document.createElement("div");
  grid.className = "opt-grid"; area.appendChild(grid);
  const opts = shuffle([target, ...sample(poolWords().filter(w => w.id !== target.id), 3)]);
  opts.forEach(w => {
    const b = document.createElement("button");
    b.className = "opt";
    b.innerHTML = `${visualHTML(w)}<span class="opt-vi">${w.vi}</span>`;
    b.addEventListener("click", () => {
      if (w.id === target.id) {
        b.classList.add("correct"); gameScore++;
        const r = b.getBoundingClientRect();
        praiseCorrect(r.left + r.width / 2, r.top, audioSrc);
        setTimeout(() => { gameRound++; nextRound(); }, 2100);
      } else {
        b.classList.add("wrong"); noteMistake(target.id);
        encourageWrong();
        setTimeout(() => b.classList.remove("wrong"), 600);
      }
    });
    grid.appendChild(b);
  });
  const say = () => playAudio(audioSrc);
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);
}

// ============================================================
// THUYẾT MINH TIẾNG VIỆT (cho bé chưa biết chữ)
// ============================================================
function narrateCurrent() {
  const active = document.querySelector(".screen.active");
  const key = active && NARRATE[active.id];
  if (key && UI_AUDIO[key]) playAudio(UI_AUDIO[key]);
}
$("#btn-narrate").addEventListener("click", narrateCurrent);
// hook thuyết minh vào showScreen gốc (xem trong hàm showScreen)

// ============================================================
// BÀI HÁT
// ============================================================
function renderSongs() {
  const box = $("#song-list"); box.innerHTML = "";
  SONGS.forEach(s => {
    const b = document.createElement("button");
    b.className = "song-card";
    b.innerHTML = `<span class="emoji">${s.emoji}</span>
      <span class="song-info"><span class="gname">${s.title}</span><br><span class="gsub">${s.vi}</span></span>
      <span class="splay">▶️</span>`;
    b.addEventListener("click", () => playSong(s));
    box.appendChild(b);
  });
}
function playSong(s) {
  $("#song-play-emoji").textContent = s.emoji;
  $("#song-play-title").textContent = s.title;
  $("#song-play-vi").textContent = s.vi;
  $("#song-lyrics").innerText = s.lyrics;
  $("#song-replay").onclick = () => playAudio(s.audio);
  playAudio(s.audio);
  showScreen("screen-song-play", false);
  history.push("screen-song-play");
}

// ============================================================
// BẢNG CHỮ CÁI
// ============================================================
function renderABC() {
  const grid = $("#abc-grid"); grid.innerHTML = "";
  ALPHABET.forEach(([ch, wid]) => {
    const b = document.createElement("button");
    b.className = "abc-cell"; b.textContent = ch;
    b.addEventListener("click", () => showLetter(ch, wid, b));
    grid.appendChild(b);
  });
  $("#abc-detail").innerHTML = `<p class="abc-hint">Chạm vào một chữ cái 👆</p>`;
}
function showLetter(ch, wid, btn) {
  $$("#abc-grid .abc-cell").forEach(x => x.classList.remove("sel"));
  if (btn) btn.classList.add("sel");
  playAudio("audio/letter_" + ch.toLowerCase() + ".mp3");
  const w = wid ? WORD_BY_ID[wid] : null;
  $("#abc-detail").innerHTML = `
    <div class="abc-big">${ch.toUpperCase()}${ch.toLowerCase()}</div>
    ${w ? `<div class="abc-visual">${visualBigHTML(w)}</div>
           <div class="abc-en">${w.en}</div><div class="abc-vi">${w.vi}</div>`
        : `<div class="abc-vi">Chữ ${ch}</div>`}`;
  if (w) narrate(wordAudio(w), 1400);
}

// ============================================================
// THỬ THÁCH NGÀY: 10 câu (thêm nghe-câu-chọn-hình)
// ============================================================


// ============================================================
// 3 GAME TƯƠNG TÁC MỚI
// ============================================================

// GAME 7: TÌM HÌNH KHÁC LOẠI (3 cùng chủ đề + 1 khác)
function roundOddone() {
  const target = gameWords[gameRound];
  const sameTheme = (gameThemeId !== "all" && gameThemeId !== "daily" && gameThemeId !== "exam") ? themeById(gameThemeId) : themeOfWord(target.id);
  let diff = target;
  if (themeOfWord(diff.id) === sameTheme) {
    diff = sample(allWords().filter(w => themeOfWord(w.id) !== sameTheme), 1)[0];
  }
  const sames = shuffle(sameTheme.words.filter(w => w.id !== diff.id)).slice(0, 3);
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Tìm hình khác loại!</span>`;
  const area = $("#q-area"); area.innerHTML = "";
  const grid = document.createElement("div");
  grid.className = "opt-grid"; area.appendChild(grid);
  shuffle([...sames, diff]).forEach(w => {
    const b = document.createElement("button");
    b.className = "opt";
    b.innerHTML = `${visualHTML(w)}<span class="opt-vi">${w.vi}</span>`;
    b.addEventListener("click", () => {
      if (w.id === diff.id) {
        b.classList.add("correct"); gameScore++;
        const r = b.getBoundingClientRect();
        praiseCorrect(r.left + r.width / 2, r.top, wordAudio(diff));
        setTimeout(() => { gameRound++; nextRound(); }, 2100);
      } else {
        b.classList.add("wrong"); noteMistake(diff.id);
        encourageWrong();
        setTimeout(() => b.classList.remove("wrong"), 600);
      }
    });
    grid.appendChild(b);
  });
  const say = () => playAudio(UI_AUDIO.oddone);
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);
}

// GAME 8: ĐÚNG HAY SAI (nhìn hình, nghe từ, chọn đúng/sai)
function roundTrueFalse() {
  const target = gameWords[gameRound];
  const isCorrect = Math.random() < 0.5;
  const heard = isCorrect ? target : sample(poolWords().filter(w => w.id !== target.id), 1)[0];
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Đúng hay sai?</span>`;
  const area = $("#q-area");
  area.innerHTML = `
    <div class="page-img" style="height:190px">${visualBigHTML(target)}</div>
    <div class="tf-row">
      <button class="tf-btn yes" id="tf-yes">✅<span>Đúng</span></button>
      <button class="tf-btn no" id="tf-no">❌<span>Sai</span></button>
    </div>`;
  const say = () => playAudio(wordAudio(heard));
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);
  const answer = yes => {
    const ok = yes === isCorrect;
    if (ok) {
      gameScore++;
      praiseCorrect(window.innerWidth / 2, 200);
    } else {
      noteMistake(target.id);
      encourageWrong();
    }
    setTimeout(() => { gameRound++; nextRound(); }, 1300);
  };
  $("#tf-yes").addEventListener("click", () => answer(true));
  $("#tf-no").addEventListener("click", () => answer(false));
}

// GAME 9: ĐẾM SỐ (đếm hình rồi chọn số đúng)
function roundCounting() {
  const target = gameWords[gameRound]; // từ số 1-10
  const n = parseInt(target.num, 10);
  const item = sample(allWords().filter(w => w.kind === "image"), 1)[0];
  $("#q-prompt").innerHTML = `<button class="speaker big" id="q-say">🔊</button>
    <span class="big-q">Đếm xem có bao nhiêu?</span>`;
  const area = $("#q-area"); area.innerHTML = "";
  const box = document.createElement("div");
  box.className = "count-box";
  for (let i = 0; i < n; i++) {
    const s = document.createElement("span");
    s.className = "count-item"; s.innerHTML = visualHTML(item);
    box.appendChild(s);
  }
  area.appendChild(box);
  const opts = new Set([n]);
  while (opts.size < 3) {
    const c = n + (Math.floor(Math.random() * 5) - 2);
    if (c >= 1 && c <= 10) opts.add(c);
  }
  const row = document.createElement("div");
  row.className = "chip-row"; row.style.justifyContent = "center";
  shuffle([...opts]).forEach(v => {
    const b = document.createElement("button");
    b.className = "wchip bignum-choice"; b.textContent = v;
    b.addEventListener("click", () => {
      if (v === n) {
        gameScore++;
        const r = b.getBoundingClientRect();
        praiseCorrect(r.left + r.width / 2, r.top, wordAudio(target));
        setTimeout(() => { gameRound++; nextRound(); }, 2100);
      } else {
        encourageWrong();
        b.classList.add("wrong");
        setTimeout(() => b.classList.remove("wrong"), 600);
      }
    });
    row.appendChild(b);
  });
  area.appendChild(row);
  const say = () => playAudio(UI_AUDIO.counting);
  $("#q-say").addEventListener("click", say);
  narrate(say, 600);
}

// ============================================================
// TÊN BÉ + AVATAR (cá nhân hóa)
// ============================================================
function kidName() { return (store.data.childName || "").trim() || "Bé"; }
function kidAvatar() { return store.data.childAvatar || "🐵"; }
const AVATARS = ["🐵", "🐱", "🐶", "🐰", "🦊", "🐼", "🐯", "🐨"];

// Màn hình chào bé lần đầu
function renderWelcome() {
  const grid = $("#welcome-avatars"); grid.innerHTML = "";
  let sel = AVATARS[0];
  AVATARS.forEach(a => {
    const b = document.createElement("button");
    b.className = "avatar-pick" + (a === sel ? " sel" : "");
    b.textContent = a;
    b.addEventListener("click", () => {
      sel = a;
      grid.querySelectorAll(".avatar-pick").forEach(x => x.classList.remove("sel"));
      b.classList.add("sel");
    });
    grid.appendChild(b);
  });
  playAudio(UI_AUDIO.welcome);
  showScreen("screen-welcome", false);
  history.push("screen-welcome");
  $("#welcome-start").onclick = () => {
    const name = $("#welcome-name").value.trim().slice(0, 20);
    store.data.childName = name || "Bé";
    store.data.childAvatar = sel;
    store.save();
    refreshHome();
    showScreen("screen-home");
  };
}

// ============================================================
// TÙY CHỈNH GIAO DIỆN (màu sắc, cỡ chữ, bố cục)
// ============================================================
const UI_THEMES = [
  { id: "rainbow", name: "Cầu vồng", emoji: "🌈" },
  { id: "pink",    name: "Hồng dâu", emoji: "🌸" },
  { id: "ocean",   name: "Biển xanh", emoji: "🌊" },
  { id: "forest",  name: "Rừng xanh", emoji: "🍃" },
  { id: "grape",   name: "Tím mơ",   emoji: "🍇" },
];
function uiPrefs() {
  return Object.assign({ theme: "rainbow", fontSize: "normal", homeGrid: "2" }, store.data.uiPrefs || {});
}
function applyUiPrefs() {
  const p = uiPrefs();
  document.body.dataset.theme = p.theme;
  document.body.dataset.fontsize = p.fontSize;
  document.body.dataset.homegrid = p.homeGrid;
  store.data.uiPrefs = p; store.save();
}
function renderSettings() {
  $("#set-name").value = store.data.childName || "";
  const ag = $("#set-avatars"); ag.innerHTML = "";
  AVATARS.forEach(a => {
    const b = document.createElement("button");
    b.className = "avatar-pick" + (a === kidAvatar() ? " sel" : "");
    b.textContent = a;
    b.addEventListener("click", () => {
      store.data.childAvatar = a; store.save();
      ag.querySelectorAll(".avatar-pick").forEach(x => x.classList.remove("sel"));
      b.classList.add("sel");
      refreshHome(); toast("Đã đổi hình " + a);
    });
    ag.appendChild(b);
  });
  const tg = $("#set-themes"); tg.innerHTML = "";
  UI_THEMES.forEach(t => {
    const b = document.createElement("button");
    b.className = "theme-pick theme-" + t.id + (t.id === uiPrefs().theme ? " sel" : "");
    b.innerHTML = `<span>${t.emoji}</span><span>${t.name}</span>`;
    b.addEventListener("click", () => {
      const p = uiPrefs(); p.theme = t.id; store.data.uiPrefs = p; store.save();
      applyUiPrefs();
      tg.querySelectorAll(".theme-pick").forEach(x => x.classList.remove("sel"));
      b.classList.add("sel");
    });
    tg.appendChild(b);
  });
  const segWire = (id, key) => {
    const seg = $(id);
    seg.querySelectorAll("button").forEach(b => {
      b.classList.toggle("sel", b.dataset.v === uiPrefs()[key]);
      b.onclick = () => {
        const p = uiPrefs(); p[key] = b.dataset.v; store.data.uiPrefs = p; store.save();
        applyUiPrefs();
        seg.querySelectorAll("button").forEach(x => x.classList.toggle("sel", x === b));
      };
    });
  };
  segWire("#set-fontsize", "fontSize");
  segWire("#set-homegrid", "homeGrid");
}
$("#set-name-save").addEventListener("click", () => {
  const name = $("#set-name").value.trim().slice(0, 20);
  if (!name) { toast("Bé gõ tên vào nhé!"); return; }
  store.data.childName = name; store.save();
  refreshHome(); toast("Chào " + name + "! 👋");
});

// Trang chủ chào theo tên bé
const _refreshHome = refreshHome;
refreshHome = function() {
  _refreshHome();
  const hello = $("#hero-hello");
  if (hello) hello.innerHTML = `Chào <b>${kidName()}</b> ${kidAvatar()}! Chạm Momo để chào nhé! 🎉`;
};

// Kết quả game gọi tên bé
const _showResult = showResult;
showResult = function() {
  _showResult();
  const sub = $("#result-sub");
  if (sub && sub.textContent.indexOf("Bé") === 0) {
    sub.textContent = kidName() + sub.textContent.slice(3);
  }
};

// ---------- Khởi động (phần 2): giao diện + màn hình đầu ----------
applyUiPrefs();
refreshStarPill();
refreshHome();
if (!store.data.childName) renderWelcome();
else { showScreen("screen-home", false); history.push("screen-home"); }

// ---------- Thanh chữ chạy cuối app: nội dung từ notepad.pw/englishkids ----------
const TICKER_URL = "https://notepad.pw/fetch/englishkids";
const TICKER_DEFAULT = "Made with ❤️ by <b>Jinken Nguyễn</b> · 1989";
function sanitizeTicker(html) {
  const tmp = document.createElement("div");
  tmp.innerHTML = html;
  tmp.querySelectorAll("script, iframe, object, embed, style, link").forEach(e => e.remove());
  tmp.querySelectorAll("*").forEach(e => {
    Array.from(e.attributes).forEach(a => { if (/^on/i.test(a.name)) e.removeAttribute(a.name); });
  });
  return tmp.innerHTML;
}
async function loadTicker() {
  let html = "";
  try {
    const r = await fetch(TICKER_URL, { cache: "no-store" });
    if (r.ok) html = (await r.text()).trim();
  } catch (e) { /* offline: dùng chữ mặc định */ }
  if (!html) html = TICKER_DEFAULT;
  else if (!/<[a-z][\s\S]*>/i.test(html)) html = html.replace(/\s*\n+\s*/g, " &nbsp;•&nbsp; ");
  const safe = sanitizeTicker(html);
  $("#ticker-a").innerHTML = safe;
  $("#ticker-b").innerHTML = safe;
  // tốc độ chạy chữ tỉ lệ với độ dài nội dung
  const len = $("#ticker-a").textContent.length;
  $("#ticker-track").style.animationDuration = Math.max(12, Math.round(len * 0.45)) + "s";
}
loadTicker();
setInterval(loadTicker, 5 * 60 * 1000); // làm mới mỗi 5 phút
