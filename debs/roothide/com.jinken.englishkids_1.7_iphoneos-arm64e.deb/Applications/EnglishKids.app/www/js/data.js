// ============================================================
// DỮ LIỆU HỌC TẬP - English Kids (bản mở rộng)
// 12 chủ đề - 100 từ vựng - 48 câu, theo 5 cấp độ (Mầm non -> Lớp 5)
// kind: "image" (ảnh), "color" (ô màu), "number" (chữ số)
// ============================================================

const LEVELS = [
  { id: 1, name: "Mầm non", emoji: "🌱" },
  { id: 2, name: "Lớp 1-2", emoji: "🎒" },
  { id: 3, name: "Lớp 3", emoji: "🌤️" },
  { id: 4, name: "Lớp 4", emoji: "🏠" },
  { id: 5, name: "Lớp 5", emoji: "🚀" },
];

const THEMES = [
  // ---------- CẤP 1 ----------
  {
    id: "animals", level: 1, name: "Động vật", en: "Animals", emoji: "🐾", color: "#FF8A65",
    words: [
      { id: "cat",   en: "Cat",    vi: "Con mèo",   ex: "The cat is cute.",   kind: "image", img: "img/cat.png" },
      { id: "dog",   en: "Dog",    vi: "Con chó",   ex: "The dog is happy.",  kind: "image", img: "img/dog.png" },
      { id: "bird",  en: "Bird",   vi: "Con chim",  ex: "The bird can fly.",  kind: "image", img: "img/bird.png" },
      { id: "fish",  en: "Fish",   vi: "Con cá",    ex: "The fish can swim.", kind: "image", img: "img/fish.png" },
      { id: "lion",  en: "Lion",   vi: "Con sư tử", ex: "The lion is big.",   kind: "image", img: "img/lion.png" },
      { id: "monkey",en: "Monkey", vi: "Con khỉ",   ex: "The monkey is funny.", kind: "image", img: "img/monkey.png" },
      { id: "tiger", en: "Tiger",  vi: "Con hổ",    ex: "The tiger is strong.", kind: "image", img: "img/tiger.png" },
      { id: "bear",  en: "Bear",   vi: "Con gấu",   ex: "The bear is big.",   kind: "image", img: "img/bear.png" },
      { id: "panda", en: "Panda",  vi: "Gấu trúc",  ex: "The panda is cute.", kind: "image", img: "img/panda.png" },
      { id: "rabbit",en: "Rabbit", vi: "Con thỏ",   ex: "The rabbit can jump.", kind: "image", img: "img/rabbit.png" },
    ],
    sentences: [
      { en: "The cat is cute.", vi: "Con mèo dễ thương.", audio: "audio/sen_animals_1.mp3" },
      { en: "I see a tiger.", vi: "Tôi nhìn thấy một con hổ.", audio: "audio/sen_animals_2.mp3" },
      { en: "The bear is big.", vi: "Con gấu to lớn.", audio: "audio/sen_animals_3.mp3" },
      { en: "The panda is black and white.", vi: "Gấu trúc có màu đen và trắng.", audio: "audio/sen_animals_4.mp3" },
      { en: "The bird can fly.", vi: "Con chim biết bay.", audio: "audio/sen_animals_5.mp3" },
      { en: "The fish can swim.", vi: "Con cá biết bơi.", audio: "audio/sen_animals_6.mp3" },
    ]
  },
  {
    id: "colors", level: 1, name: "Màu sắc", en: "Colors", emoji: "🎨", color: "#BA68C8",
    words: [
      { id: "red",    en: "Red",    vi: "Màu đỏ",       ex: "The apple is red.",   kind: "color", css: "#E53935" },
      { id: "blue",   en: "Blue",   vi: "Màu xanh dương", ex: "The sky is blue.",  kind: "color", css: "#1E88E5" },
      { id: "green",  en: "Green",  vi: "Màu xanh lá",  ex: "The leaf is green.",  kind: "color", css: "#43A047" },
      { id: "yellow", en: "Yellow", vi: "Màu vàng",     ex: "The sun is yellow.",  kind: "color", css: "#FDD835" },
      { id: "orange", en: "Orange", vi: "Màu cam",      ex: "The orange is orange.", kind: "color", css: "#FB8C00" },
      { id: "purple", en: "Purple", vi: "Màu tím",      ex: "The grape is purple.", kind: "color", css: "#8E24AA" },
      { id: "black",  en: "Black",  vi: "Màu đen",      ex: "The cat is black.",   kind: "color", css: "#212121" },
      { id: "white",  en: "White",  vi: "Màu trắng",    ex: "The milk is white.",  kind: "color", css: "#FFFFFF", border: true },
    ],
    sentences: [
      { en: "The apple is red.", vi: "Quả táo màu đỏ.", audio: "audio/sen_colors_1.mp3" },
      { en: "The sky is blue.", vi: "Bầu trời màu xanh dương.", audio: "audio/sen_colors_2.mp3" },
      { en: "The cat is black.", vi: "Con mèo màu đen.", audio: "audio/sen_colors_3.mp3" },
      { en: "The milk is white.", vi: "Sữa màu trắng.", audio: "audio/sen_colors_4.mp3" },
      { en: "My bag is red.", vi: "Cái cặp của tôi màu đỏ.", audio: "audio/sen_colors_5.mp3" },
      { en: "The ball is green.", vi: "Quả bóng màu xanh lá.", audio: "audio/sen_colors_6.mp3" },
    ]
  },
  {
    id: "numbers", level: 1, name: "Số đếm", en: "Numbers", emoji: "🔢", color: "#4FC3F7",
    words: [
      { id: "one",   en: "One",   vi: "Số một", ex: "One apple.",   kind: "number", num: "1" },
      { id: "two",   en: "Two",   vi: "Số hai", ex: "Two cats.",    kind: "number", num: "2" },
      { id: "three", en: "Three", vi: "Số ba",  ex: "Three birds.", kind: "number", num: "3" },
      { id: "four",  en: "Four",  vi: "Số bốn", ex: "Four fish.",   kind: "number", num: "4" },
      { id: "five",  en: "Five",  vi: "Số năm", ex: "Five dogs.",   kind: "number", num: "5" },
      { id: "six",   en: "Six",   vi: "Số sáu", ex: "Six monkeys.", kind: "number", num: "6" },
      { id: "seven", en: "Seven", vi: "Số bảy", ex: "Seven ducks.",  kind: "number", num: "7" },
      { id: "eight", en: "Eight", vi: "Số tám", ex: "Eight fish.",   kind: "number", num: "8" },
      { id: "nine",  en: "Nine",  vi: "Số chín", ex: "Nine birds.",  kind: "number", num: "9" },
      { id: "ten",   en: "Ten",   vi: "Số mười", ex: "Ten apples.",  kind: "number", num: "10" },
      { id: "eleven", en: "Eleven", vi: "Số mười một", ex: "I can count to eleven!", kind: "number", num: "11" },
      { id: "twelve", en: "Twelve", vi: "Số mười hai", ex: "I can count to twelve!", kind: "number", num: "12" },
      { id: "thirteen", en: "Thirteen", vi: "Số mười ba", ex: "I can count to thirteen!", kind: "number", num: "13" },
      { id: "fourteen", en: "Fourteen", vi: "Số mười bốn", ex: "I can count to fourteen!", kind: "number", num: "14" },
      { id: "fifteen", en: "Fifteen", vi: "Số mười lăm", ex: "I can count to fifteen!", kind: "number", num: "15" },
      { id: "sixteen", en: "Sixteen", vi: "Số mười sáu", ex: "I can count to sixteen!", kind: "number", num: "16" },
      { id: "seventeen", en: "Seventeen", vi: "Số mười bảy", ex: "I can count to seventeen!", kind: "number", num: "17" },
      { id: "eighteen", en: "Eighteen", vi: "Số mười tám", ex: "I can count to eighteen!", kind: "number", num: "18" },
      { id: "nineteen", en: "Nineteen", vi: "Số mười chín", ex: "I can count to nineteen!", kind: "number", num: "19" },
      { id: "twenty", en: "Twenty", vi: "Số hai mươi", ex: "I can count to twenty!", kind: "number", num: "20" },
    ],
    sentences: [
      { en: "One apple.", vi: "Một quả táo.", audio: "audio/sen_numbers_1.mp3" },
      { en: "Two cats.", vi: "Hai con mèo.", audio: "audio/sen_numbers_2.mp3" },
      { en: "I am five years old.", vi: "Tôi năm tuổi.", audio: "audio/sen_numbers_3.mp3" },
      { en: "There are ten birds.", vi: "Có mười con chim.", audio: "audio/sen_numbers_4.mp3" },
      { en: "I have two hands.", vi: "Tôi có hai bàn tay.", audio: "audio/sen_numbers_5.mp3" },
      { en: "I see three birds.", vi: "Tôi thấy ba con chim.", audio: "audio/sen_numbers_6.mp3" },
    ]
  },
  {
    id: "food", level: 1, name: "Đồ ăn", en: "Food", emoji: "🍎", color: "#FFD54F",
    words: [
      { id: "apple",  en: "Apple",  vi: "Quả táo",   ex: "I like apples.",       kind: "image", img: "img/apple.png" },
      { id: "banana", en: "Banana", vi: "Quả chuối", ex: "The banana is yellow.", kind: "image", img: "img/banana.png" },
      { id: "milk",   en: "Milk",   vi: "Sữa",       ex: "I drink milk.",        kind: "image", img: "img/milk.png" },
      { id: "bread",  en: "Bread",  vi: "Bánh mì",   ex: "I eat bread.",         kind: "image", img: "img/bread.png" },
      { id: "egg",    en: "Egg",    vi: "Quả trứng", ex: "The egg is white.",    kind: "image", img: "img/egg.png" },
      { id: "cake",   en: "Cake",   vi: "Bánh kem",  ex: "The cake is yummy.",   kind: "image", img: "img/cake.png" },
      { id: "rice",   en: "Rice",   vi: "Cơm",       ex: "I eat rice.",          kind: "image", img: "img/rice.png" },
      { id: "chicken",en: "Chicken",vi: "Thịt gà",   ex: "The chicken is yummy.", kind: "image", img: "img/chicken.png" },
      { id: "juice",  en: "Juice",  vi: "Nước ép",   ex: "I drink juice.",       kind: "image", img: "img/juice.png" },
      { id: "icecream",en: "Ice cream", vi: "Kem",   ex: "I like ice cream.",    kind: "image", img: "img/icecream.png" },
    ],
    sentences: [
      { en: "I like apples.", vi: "Tôi thích táo.", audio: "audio/sen_food_1.mp3" },
      { en: "I eat rice every day.", vi: "Tôi ăn cơm mỗi ngày.", audio: "audio/sen_food_2.mp3" },
      { en: "The chicken is yummy.", vi: "Thịt gà rất ngon.", audio: "audio/sen_food_3.mp3" },
      { en: "I drink orange juice.", vi: "Tôi uống nước cam.", audio: "audio/sen_food_4.mp3" },
      { en: "I drink milk.", vi: "Tôi uống sữa.", audio: "audio/sen_food_5.mp3" },
      { en: "I eat an apple.", vi: "Tôi ăn một quả táo.", audio: "audio/sen_food_6.mp3" },
    ]
  },
  {
    id: "family", level: 1, name: "Gia đình", en: "Family", emoji: "👨‍👩‍👧", color: "#AED581",
    words: [
      { id: "father",      en: "Father",      vi: "Bố",     ex: "My father is tall.",  kind: "image", img: "img/father.png" },
      { id: "mother",      en: "Mother",      vi: "Mẹ",     ex: "My mother is kind.",  kind: "image", img: "img/mother.png" },
      { id: "brother",     en: "Brother",     vi: "Anh trai", ex: "My brother is fun.", kind: "image", img: "img/brother.png" },
      { id: "sister",      en: "Sister",      vi: "Chị gái", ex: "My sister is sweet.", kind: "image", img: "img/sister.png" },
      { id: "baby",        en: "Baby",        vi: "Em bé",  ex: "The baby is small.",  kind: "image", img: "img/baby.png" },
      { id: "grandmother", en: "Grandmother", vi: "Bà",     ex: "My grandmother is nice.", kind: "image", img: "img/grandmother.png" },
      { id: "grandfather", en: "Grandfather", vi: "Ông",    ex: "This is my grandfather.", kind: "image", img: "img/grandfather.png" },
      { id: "aunt", en: "Aunt", vi: "Cô/Dì", ex: "This is my aunt.", kind: "image", img: "img/aunt.png" },
      { id: "cousin", en: "Cousin", vi: "Anh/Chị/Em họ", ex: "This is my cousin.", kind: "image", img: "img/cousin.png" },
      { id: "uncle",       en: "Uncle",       vi: "Chú",    ex: "My uncle is funny.",  kind: "image", img: "img/uncle.png" },
    ],
    sentences: [
      { en: "My father is tall.", vi: "Bố tôi cao.", audio: "audio/sen_family_1.mp3" },
      { en: "My mother is kind.", vi: "Mẹ tôi hiền hậu.", audio: "audio/sen_family_2.mp3" },
      { en: "This is my grandfather.", vi: "Đây là ông của tôi.", audio: "audio/sen_family_3.mp3" },
      { en: "I love my family!", vi: "Tôi yêu gia đình của tôi!", audio: "audio/sen_family_4.mp3" },
      { en: "I love my mother.", vi: "Tôi yêu mẹ của tôi.", audio: "audio/sen_family_5.mp3" },
      { en: "My father is tall.", vi: "Bố tôi cao lớn.", audio: "audio/sen_family_6.mp3" },
    ]
  },
  // ---------- CẤP 2 ----------
  {
    id: "body", level: 2, name: "Cơ thể", en: "Body", emoji: "🖐️", color: "#F48FB1",
    words: [
      { id: "head",  en: "Head",  vi: "Cái đầu",   ex: "This is my head.",  kind: "image", img: "img/head.png" },
      { id: "eye",   en: "Eye",   vi: "Con mắt",   ex: "I have two eyes.",  kind: "image", img: "img/eye.png" },
      { id: "nose",  en: "Nose",  vi: "Cái mũi",   ex: "This is my nose.",  kind: "image", img: "img/nose.png" },
      { id: "mouth", en: "Mouth", vi: "Cái miệng", ex: "Open your mouth.",  kind: "image", img: "img/mouth.png" },
      { id: "ear",   en: "Ear",   vi: "Cái tai",   ex: "I have two ears.",  kind: "image", img: "img/ear.png" },
      { id: "hand",  en: "Hand",  vi: "Bàn tay",   ex: "Clap your hands.",  kind: "image", img: "img/hand.png" },
      { id: "leg",   en: "Leg",   vi: "Cái chân",  ex: "I have two legs.",  kind: "image", img: "img/leg.png" },
      { id: "foot",  en: "Foot",  vi: "Bàn chân",  ex: "Stamp your feet.",  kind: "image", img: "img/foot.png" },
    ],
    sentences: [
      { en: "This is my head.", vi: "Đây là đầu của tôi.", audio: "audio/sen_body_1.mp3" },
      { en: "I have two eyes.", vi: "Tôi có hai con mắt.", audio: "audio/sen_body_2.mp3" },
      { en: "Clap your hands!", vi: "Vỗ tay nào!", audio: "audio/sen_body_3.mp3" },
      { en: "Stamp your feet!", vi: "Giậm chân nào!", audio: "audio/sen_body_4.mp3" },
      { en: "I have two eyes.", vi: "Tôi có hai con mắt.", audio: "audio/sen_body_5.mp3" },
      { en: "Clap your hands!", vi: "Vỗ tay nào!", audio: "audio/sen_body_6.mp3" },
    ]
  },
  {
    id: "school", level: 2, name: "Đồ dùng học tập", en: "School things", emoji: "🎒", color: "#90CAF9",
    words: [
      { id: "book",   en: "Book",   vi: "Quyển sách", ex: "This is my book.",   kind: "image", img: "img/book.png" },
      { id: "pen",    en: "Pen",    vi: "Bút mực",    ex: "I have a pen.",      kind: "image", img: "img/pen.png" },
      { id: "pencil", en: "Pencil", vi: "Bút chì",    ex: "This is my pencil.", kind: "image", img: "img/pencil.png" },
      { id: "bag",    en: "Bag",    vi: "Cặp sách",   ex: "My bag is red.",     kind: "image", img: "img/bag.png" },
      { id: "ruler",  en: "Ruler",  vi: "Thước kẻ",   ex: "The ruler is long.", kind: "image", img: "img/ruler.png" },
      { id: "eraser", en: "Eraser", vi: "Cục tẩy",    ex: "Where is my eraser?", kind: "image", img: "img/eraser.png" },
      { id: "desk",   en: "Desk",   vi: "Bàn học",    ex: "The book is on the desk.", kind: "image", img: "img/desk.png" },
      { id: "chair",  en: "Chair",  vi: "Cái ghế",    ex: "Sit on the chair.",  kind: "image", img: "img/chair.png" },
    ],
    sentences: [
      { en: "This is my book.", vi: "Đây là quyển sách của tôi.", audio: "audio/sen_school_1.mp3" },
      { en: "I have a pen.", vi: "Tôi có một cây bút mực.", audio: "audio/sen_school_2.mp3" },
      { en: "Open your school bag.", vi: "Mở cặp sách của bạn ra.", audio: "audio/sen_school_3.mp3" },
      { en: "Sit on the chair.", vi: "Ngồi lên ghế nào.", audio: "audio/sen_school_4.mp3" },
      { en: "Open your book.", vi: "Mở sách ra nào.", audio: "audio/sen_school_5.mp3" },
      { en: "I have a pen.", vi: "Tôi có một cây bút.", audio: "audio/sen_school_6.mp3" },
    ]
  },
  // ---------- CẤP 3 ----------
  {
    id: "clothes", level: 3, name: "Quần áo", en: "Clothes", emoji: "👕", color: "#CE93D8",
    words: [
      { id: "shirt",  en: "Shirt",  vi: "Áo sơ mi", ex: "I wear a red shirt.", kind: "image", img: "img/shirt.png" },
      { id: "pants",  en: "Pants",  vi: "Quần dài", ex: "My pants are blue.", kind: "image", img: "img/pants.png" },
      { id: "dress",  en: "Dress",  vi: "Váy",      ex: "She has a blue dress.", kind: "image", img: "img/dress.png" },
      { id: "shoes",  en: "Shoes",  vi: "Giày",     ex: "Put on your shoes.", kind: "image", img: "img/shoes.png" },
      { id: "hat",    en: "Hat",    vi: "Mũ",       ex: "My hat is yellow.",  kind: "image", img: "img/hat.png" },
      { id: "socks",  en: "Socks",  vi: "Tất",      ex: "These are my socks.", kind: "image", img: "img/socks.png" },
      { id: "jacket", en: "Jacket", vi: "Áo khoác", ex: "My jacket is warm.", kind: "image", img: "img/jacket.png" },
      { id: "skirt",  en: "Skirt",  vi: "Chân váy", ex: "Her skirt is pink.", kind: "image", img: "img/skirt.png" },
    ],
    sentences: [
      { en: "I wear a red shirt.", vi: "Tôi mặc áo sơ mi đỏ.", audio: "audio/sen_clothes_1.mp3" },
      { en: "She has a blue dress.", vi: "Cô ấy có một chiếc váy xanh.", audio: "audio/sen_clothes_2.mp3" },
      { en: "Put on your shoes.", vi: "Mang giày vào nào.", audio: "audio/sen_clothes_3.mp3" },
      { en: "My hat is yellow.", vi: "Chiếc mũ của tôi màu vàng.", audio: "audio/sen_clothes_4.mp3" },
      { en: "My shirt is blue.", vi: "Áo của tôi màu xanh dương.", audio: "audio/sen_clothes_5.mp3" },
      { en: "Put on your shoes.", vi: "Mang giày vào nào.", audio: "audio/sen_clothes_6.mp3" },
    ]
  },
  {
    id: "weather", level: 3, name: "Thời tiết", en: "Weather", emoji: "🌤️", color: "#80DEEA",
    words: [
      { id: "sunny",  en: "Sunny",  vi: "Trời nắng",  ex: "It is sunny today.", kind: "image", img: "img/sunny.png" },
      { id: "rainy",  en: "Rainy",  vi: "Trời mưa",   ex: "It is rainy.",       kind: "image", img: "img/rainy.png" },
      { id: "cloudy", en: "Cloudy", vi: "Nhiều mây",  ex: "It is cloudy.",      kind: "image", img: "img/cloudy.png" },
      { id: "windy",  en: "Windy",  vi: "Nhiều gió",  ex: "It is windy.",       kind: "image", img: "img/windy.png" },
      { id: "hot",    en: "Hot",    vi: "Nóng",       ex: "It is hot today.",   kind: "image", img: "img/hot.png" },
      { id: "cold",   en: "Cold",   vi: "Lạnh",       ex: "It is cold today.",  kind: "image", img: "img/cold.png" },
    ],
    sentences: [
      { en: "It is sunny today.", vi: "Hôm nay trời nắng.", audio: "audio/sen_weather_1.mp3" },
      { en: "It is rainy.", vi: "Trời đang mưa.", audio: "audio/sen_weather_2.mp3" },
      { en: "The wind is strong.", vi: "Gió thổi mạnh.", audio: "audio/sen_weather_3.mp3" },
      { en: "It is cold today.", vi: "Hôm nay trời lạnh.", audio: "audio/sen_weather_4.mp3" },
      { en: "It is sunny today.", vi: "Hôm nay trời nắng.", audio: "audio/sen_weather_5.mp3" },
      { en: "It is cold.", vi: "Trời lạnh.", audio: "audio/sen_weather_6.mp3" },
    ]
  },
  // ---------- CẤP 4 ----------
  {
    id: "jobs", level: 4, name: "Nghề nghiệp", en: "Jobs", emoji: "👩‍⚕️", color: "#FFCC80",
    words: [
      { id: "teacher",   en: "Teacher",   vi: "Giáo viên", ex: "She is a teacher.",   kind: "image", img: "img/teacher.png" },
      { id: "doctor",    en: "Doctor",    vi: "Bác sĩ",    ex: "He is a doctor.",     kind: "image", img: "img/doctor.png" },
      { id: "farmer",    en: "Farmer",    vi: "Nông dân",  ex: "My father is a farmer.", kind: "image", img: "img/farmer.png" },
      { id: "policeman", en: "Policeman", vi: "Cảnh sát",  ex: "The policeman is kind.", kind: "image", img: "img/policeman.png" },
      { id: "driver",    en: "Driver",    vi: "Tài xế",    ex: "He is a driver.",     kind: "image", img: "img/driver.png" },
      { id: "nurse",     en: "Nurse",     vi: "Y tá",      ex: "She is a nurse.",     kind: "image", img: "img/nurse.png" },
      { id: "cook",      en: "Cook",      vi: "Đầu bếp",   ex: "My mother is a cook.", kind: "image", img: "img/cook.png" },
      { id: "student",   en: "Student",   vi: "Học sinh",  ex: "I am a student.",    kind: "image", img: "img/student.png" },
    ],
    sentences: [
      { en: "She is a teacher.", vi: "Cô ấy là giáo viên.", audio: "audio/sen_jobs_1.mp3" },
      { en: "He is a doctor.", vi: "Chú ấy là bác sĩ.", audio: "audio/sen_jobs_2.mp3" },
      { en: "My father is a farmer.", vi: "Bố tôi là nông dân.", audio: "audio/sen_jobs_3.mp3" },
      { en: "The policeman is kind.", vi: "Chú cảnh sát thật tốt bụng.", audio: "audio/sen_jobs_4.mp3" },
      { en: "She is a teacher.", vi: "Cô ấy là giáo viên.", audio: "audio/sen_jobs_5.mp3" },
      { en: "He is a doctor.", vi: "Chú ấy là bác sĩ.", audio: "audio/sen_jobs_6.mp3" },
    ]
  },
  {
    id: "home", level: 4, name: "Nhà cửa", en: "Home", emoji: "🏠", color: "#BCAAA4",
    words: [
      { id: "house",   en: "House",   vi: "Ngôi nhà", ex: "This is my house.",  kind: "image", img: "img/house.png" },
      { id: "door",    en: "Door",    vi: "Cánh cửa", ex: "Open the door.",     kind: "image", img: "img/door.png" },
      { id: "window",  en: "Window",  vi: "Cửa sổ",   ex: "Look at the window.", kind: "image", img: "img/window.png" },
      { id: "bed",     en: "Bed",     vi: "Giường",   ex: "The bed is big.",    kind: "image", img: "img/bed.png" },
      { id: "table",   en: "Table",   vi: "Cái bàn",  ex: "The apple is on the table.", kind: "image", img: "img/table.png" },
      { id: "lamp",    en: "Lamp",    vi: "Cái đèn",  ex: "The lamp is bright.", kind: "image", img: "img/lamp.png" },
      { id: "sofa",    en: "Sofa",    vi: "Ghế sofa", ex: "Sit on the sofa.",   kind: "image", img: "img/sofa.png" },
      { id: "kitchen", en: "Kitchen", vi: "Nhà bếp",  ex: "Mom is in the kitchen.", kind: "image", img: "img/kitchen.png" },
    ],
    sentences: [
      { en: "This is my house.", vi: "Đây là nhà của tôi.", audio: "audio/sen_home_1.mp3" },
      { en: "Open the door, please.", vi: "Mở cửa ra nào.", audio: "audio/sen_home_2.mp3" },
      { en: "The bed is big.", vi: "Cái giường thật to.", audio: "audio/sen_home_3.mp3" },
      { en: "Mom is in the kitchen.", vi: "Mẹ đang ở trong bếp.", audio: "audio/sen_home_4.mp3" },
      { en: "This is my house.", vi: "Đây là nhà của tôi.", audio: "audio/sen_home_5.mp3" },
      { en: "I sleep in my bed.", vi: "Tôi ngủ trên giường.", audio: "audio/sen_home_6.mp3" },
    ]
  },
  // ---------- CẤP 5 ----------
  {
    id: "sports", level: 5, name: "Đồ chơi & Thể thao", en: "Toys & Sports", emoji: "⚽", color: "#9CCC65",
    words: [
      { id: "ball",     en: "Ball",     vi: "Quả bóng", ex: "This is my ball.", kind: "image", img: "img/ball.png" },
      { id: "doll",     en: "Doll",     vi: "Búp bê",   ex: "She has a doll.",  kind: "image", img: "img/doll.png" },
      { id: "kite",     en: "Kite",     vi: "Diều",     ex: "Let's fly a kite.", kind: "image", img: "img/kite.png" },
      { id: "bike",     en: "Bike",     vi: "Xe đạp",   ex: "I ride my bike.",  kind: "image", img: "img/bike.png" },
      { id: "football", en: "Football", vi: "Bóng đá",  ex: "I like football.", kind: "image", img: "img/football.png" },
      { id: "swim",     en: "Swim",     vi: "Bơi lội",  ex: "She can swim.",    kind: "image", img: "img/swim.png" },
      { id: "run",      en: "Run",      vi: "Chạy",     ex: "I can run.",       kind: "image", img: "img/run.png" },
      { id: "jump",     en: "Jump",     vi: "Nhảy",     ex: "The rabbit can jump.", kind: "image", img: "img/jump.png" },
    ],
    sentences: [
      { en: "I like football.", vi: "Tôi thích bóng đá.", audio: "audio/sen_sports_1.mp3" },
      { en: "She can swim.", vi: "Cô ấy biết bơi.", audio: "audio/sen_sports_2.mp3" },
      { en: "Let's fly a kite!", vi: "Cùng nhau thả diều nào!", audio: "audio/sen_sports_3.mp3" },
      { en: "I ride my bike every day.", vi: "Tôi đạp xe mỗi ngày.", audio: "audio/sen_sports_4.mp3" },
      { en: "Run fast!", vi: "Chạy nhanh lên!", audio: "audio/sen_sports_5.mp3" },
      { en: "I can jump high.", vi: "Tôi nhảy cao được.", audio: "audio/sen_sports_6.mp3" },
    ]
  },
  {
    id: "nature", level: 3, name: "Thiên nhiên", en: "Nature", emoji: "🌳", color: "#66BB6A",
    words: [
      { id: "tree", en: "Tree", vi: "Cây", ex: "The tree is big.", kind: "image", img: "img/tree.png" },
      { id: "flower", en: "Flower", vi: "Bông hoa", ex: "The flower is red.", kind: "image", img: "img/flower.png" },
      { id: "leaf", en: "Leaf", vi: "Lá cây", ex: "The leaf is green.", kind: "image", img: "img/leaf.png" },
      { id: "grass", en: "Grass", vi: "Cỏ", ex: "The grass is green.", kind: "image", img: "img/grass.png" },
      { id: "mountain", en: "Mountain", vi: "Ngọn núi", ex: "The mountain is high.", kind: "image", img: "img/mountain.png" },
      { id: "river", en: "River", vi: "Dòng sông", ex: "The river is long.", kind: "image", img: "img/river.png" },
      { id: "sea", en: "Sea", vi: "Biển", ex: "The sea is blue.", kind: "image", img: "img/sea.png" },
      { id: "sky", en: "Sky", vi: "Bầu trời", ex: "The sky is blue.", kind: "image", img: "img/sky.png" },
    ],
    sentences: [
      { en: "The tree is big.", vi: "Cái cây to lớn.", audio: "audio/sen_nature_1.mp3" },
      { en: "I see a flower.", vi: "Tôi thấy một bông hoa.", audio: "audio/sen_nature_2.mp3" },
      { en: "The sea is blue.", vi: "Biển màu xanh dương.", audio: "audio/sen_nature_3.mp3" },
      { en: "Birds fly in the sky.", vi: "Chim bay trên bầu trời.", audio: "audio/sen_nature_4.mp3" },
      { en: "The river is long.", vi: "Dòng sông dài.", audio: "audio/sen_nature_5.mp3" },
      { en: "The mountain is high.", vi: "Ngọn núi cao.", audio: "audio/sen_nature_6.mp3" },
    ]
  },
  {
    id: "feelings", level: 4, name: "Cảm xúc", en: "Feelings", emoji: "😊", color: "#FFA726",
    words: [
      { id: "happy", en: "Happy", vi: "Vui vẻ", ex: "I am happy.", kind: "image", img: "img/happy.png" },
      { id: "sad", en: "Sad", vi: "Buồn", ex: "He is sad.", kind: "image", img: "img/sad.png" },
      { id: "angry", en: "Angry", vi: "Giận dữ", ex: "Dad is angry.", kind: "image", img: "img/angry.png" },
      { id: "scared", en: "Scared", vi: "Sợ hãi", ex: "The cat is scared.", kind: "image", img: "img/scared.png" },
      { id: "tired", en: "Tired", vi: "Mệt mỏi", ex: "I am tired.", kind: "image", img: "img/tired.png" },
      { id: "hungry", en: "Hungry", vi: "Đói bụng", ex: "I am hungry.", kind: "image", img: "img/hungry.png" },
      { id: "sleepy", en: "Sleepy", vi: "Buồn ngủ", ex: "She is sleepy.", kind: "image", img: "img/sleepy.png" },
      { id: "excited", en: "Excited", vi: "Háo hức", ex: "We are excited.", kind: "image", img: "img/excited.png" },
    ],
    sentences: [
      { en: "I am happy.", vi: "Tôi vui vẻ.", audio: "audio/sen_feelings_1.mp3" },
      { en: "She is sad.", vi: "Cô ấy buồn.", audio: "audio/sen_feelings_2.mp3" },
      { en: "Don't be angry.", vi: "Đừng giận nhé.", audio: "audio/sen_feelings_3.mp3" },
      { en: "The baby is hungry.", vi: "Em bé đói bụng.", audio: "audio/sen_feelings_4.mp3" },
      { en: "I am happy today.", vi: "Hôm nay tôi rất vui.", audio: "audio/sen_feelings_5.mp3" },
      { en: "He is sleepy.", vi: "Anh ấy buồn ngủ.", audio: "audio/sen_feelings_6.mp3" },
    ]
  },
  {
    id: "shapes", level: 1, name: "Hình dạng", en: "Shapes", emoji: "🔷", color: "#4DD0E1",
    words: [
      { id: "circle", en: "Circle", vi: "Hình tròn", ex: "It is a circle.", kind: "image", img: "img/circle.png" },
      { id: "square", en: "Square", vi: "Hình vuông", ex: "It is a square.", kind: "image", img: "img/square.png" },
      { id: "triangle", en: "Triangle", vi: "Hình tam giác", ex: "It is a triangle.", kind: "image", img: "img/triangle.png" },
      { id: "star", en: "Star", vi: "Ngôi sao", ex: "The star is yellow.", kind: "image", img: "img/star.png" },
      { id: "heart", en: "Heart", vi: "Trái tim", ex: "The heart is red.", kind: "image", img: "img/heart.png" },
      { id: "rectangle", en: "Rectangle", vi: "Hình chữ nhật", ex: "It is a rectangle.", kind: "image", img: "img/rectangle.png" },
      { id: "oval", en: "Oval", vi: "Hình bầu dục", ex: "It is an oval.", kind: "image", img: "img/oval.png" },
      { id: "diamond", en: "Diamond", vi: "Hình thoi", ex: "The diamond is blue.", kind: "image", img: "img/diamond.png" },
    ],
    sentences: [
      { en: "It is a circle.", vi: "Đây là hình tròn.", audio: "audio/sen_shapes_1.mp3" },
      { en: "The star is yellow.", vi: "Ngôi sao màu vàng.", audio: "audio/sen_shapes_2.mp3" },
      { en: "I see a square.", vi: "Tôi thấy một hình vuông.", audio: "audio/sen_shapes_3.mp3" },
      { en: "The heart is red.", vi: "Trái tim màu đỏ.", audio: "audio/sen_shapes_4.mp3" },
      { en: "It is a triangle.", vi: "Đây là hình tam giác.", audio: "audio/sen_shapes_5.mp3" },
      { en: "The diamond is blue.", vi: "Hình thoi màu xanh dương.", audio: "audio/sen_shapes_6.mp3" },
    ]
  },
  {
    id: "vegetables", level: 2, name: "Rau củ", en: "Vegetables", emoji: "🥕", color: "#9CCC65",
    words: [
      { id: "carrot", en: "Carrot", vi: "Cà rốt", ex: "I like carrots.", kind: "image", img: "img/carrot.png" },
      { id: "tomato", en: "Tomato", vi: "Cà chua", ex: "The tomato is red.", kind: "image", img: "img/tomato.png" },
      { id: "potato", en: "Potato", vi: "Khoai tây", ex: "I like potatoes.", kind: "image", img: "img/potato.png" },
      { id: "cabbage", en: "Cabbage", vi: "Bắp cải", ex: "The cabbage is green.", kind: "image", img: "img/cabbage.png" },
      { id: "corn", en: "Corn", vi: "Bắp", ex: "I eat corn.", kind: "image", img: "img/corn.png" },
      { id: "onion", en: "Onion", vi: "Hành tây", ex: "The onion is white.", kind: "image", img: "img/onion.png" },
      { id: "pumpkin", en: "Pumpkin", vi: "Bí đỏ", ex: "The pumpkin is big.", kind: "image", img: "img/pumpkin.png" },
      { id: "mushroom", en: "Mushroom", vi: "Nấm", ex: "I see a mushroom.", kind: "image", img: "img/mushroom.png" },
    ],
    sentences: [
      { en: "I like carrots.", vi: "Tôi thích cà rốt.", audio: "audio/sen_vegetables_1.mp3" },
      { en: "The tomato is red.", vi: "Quả cà chua màu đỏ.", audio: "audio/sen_vegetables_2.mp3" },
      { en: "I eat corn.", vi: "Tôi ăn bắp.", audio: "audio/sen_vegetables_3.mp3" },
      { en: "The pumpkin is big.", vi: "Quả bí đỏ to.", audio: "audio/sen_vegetables_4.mp3" },
      { en: "I see a mushroom.", vi: "Tôi thấy một cây nấm.", audio: "audio/sen_vegetables_5.mp3" },
      { en: "The onion is white.", vi: "Củ hành màu trắng.", audio: "audio/sen_vegetables_6.mp3" },
    ]
  },
  {
    id: "fruits", level: 2, name: "Trái cây", en: "Fruits", emoji: "🍓", color: "#F06292",
    words: [
      { id: "strawberry", en: "Strawberry", vi: "Dâu tây", ex: "I like strawberries.", kind: "image", img: "img/strawberry.png" },
      { id: "watermelon", en: "Watermelon", vi: "Dưa hấu", ex: "The watermelon is big.", kind: "image", img: "img/watermelon.png" },
      { id: "grape", en: "Grape", vi: "Nho", ex: "Grapes are purple.", kind: "image", img: "img/grape.png" },
      { id: "pineapple", en: "Pineapple", vi: "Dứa", ex: "The pineapple is sweet.", kind: "image", img: "img/pineapple.png" },
      { id: "mango", en: "Mango", vi: "Xoài", ex: "The mango is sweet.", kind: "image", img: "img/mango.png" },
      { id: "lemon", en: "Lemon", vi: "Chanh", ex: "The lemon is sour.", kind: "image", img: "img/lemon.png" },
      { id: "peach", en: "Peach", vi: "Đào", ex: "I eat a peach.", kind: "image", img: "img/peach.png" },
      { id: "cherry", en: "Cherry", vi: "Anh đào", ex: "The cherry is red.", kind: "image", img: "img/cherry.png" },
    ],
    sentences: [
      { en: "I like strawberries.", vi: "Tôi thích dâu tây.", audio: "audio/sen_fruits_1.mp3" },
      { en: "The watermelon is big.", vi: "Quả dưa hấu to.", audio: "audio/sen_fruits_2.mp3" },
      { en: "Grapes are purple.", vi: "Nho màu tím.", audio: "audio/sen_fruits_3.mp3" },
      { en: "The mango is sweet.", vi: "Quả xoài ngọt.", audio: "audio/sen_fruits_4.mp3" },
      { en: "The lemon is sour.", vi: "Quả chanh chua.", audio: "audio/sen_fruits_5.mp3" },
      { en: "I eat a peach.", vi: "Tôi ăn một quả đào.", audio: "audio/sen_fruits_6.mp3" },
    ]
  },
  {
    id: "vehicles", level: 3, name: "Phương tiện", en: "Vehicles", emoji: "🚗", color: "#FF8A65",
    words: [
      { id: "car", en: "Car", vi: "Ô tô", ex: "The car is red.", kind: "image", img: "img/car.png" },
      { id: "bus", en: "Bus", vi: "Xe buýt", ex: "I see a bus.", kind: "image", img: "img/bus.png" },
      { id: "train", en: "Train", vi: "Tàu hỏa", ex: "The train is long.", kind: "image", img: "img/train.png" },
      { id: "plane", en: "Plane", vi: "Máy bay", ex: "The plane can fly.", kind: "image", img: "img/plane.png" },
      { id: "ship", en: "Ship", vi: "Tàu thủy", ex: "The ship is big.", kind: "image", img: "img/ship.png" },
      { id: "truck", en: "Truck", vi: "Xe tải", ex: "Dad drives a truck.", kind: "image", img: "img/truck.png" },
      { id: "taxi", en: "Taxi", vi: "Taxi", ex: "I see a taxi.", kind: "image", img: "img/taxi.png" },
      { id: "motorcycle", en: "Motorcycle", vi: "Xe máy", ex: "The motorcycle is fast.", kind: "image", img: "img/motorcycle.png" },
    ],
    sentences: [
      { en: "The car is red.", vi: "Chiếc ô tô màu đỏ.", audio: "audio/sen_vehicles_1.mp3" },
      { en: "I see a bus.", vi: "Tôi thấy một chiếc xe buýt.", audio: "audio/sen_vehicles_2.mp3" },
      { en: "The train is very long.", vi: "Tàu hỏa rất dài.", audio: "audio/sen_vehicles_3.mp3" },
      { en: "The plane flies high.", vi: "Máy bay bay cao.", audio: "audio/sen_vehicles_4.mp3" },
      { en: "The ship is on the sea.", vi: "Tàu thủy ở trên biển.", audio: "audio/sen_vehicles_5.mp3" },
      { en: "The truck is big.", vi: "Xe tải to lớn.", audio: "audio/sen_vehicles_6.mp3" },
    ]
  },
  {
    id: "insects", level: 3, name: "Côn trùng", en: "Insects", emoji: "🦋", color: "#AED581",
    words: [
      { id: "butterfly", en: "Butterfly", vi: "Bướm", ex: "The butterfly is beautiful.", kind: "image", img: "img/butterfly.png" },
      { id: "bee", en: "Bee", vi: "Ong", ex: "The bee can fly.", kind: "image", img: "img/bee.png" },
      { id: "ant", en: "Ant", vi: "Kiến", ex: "I see an ant.", kind: "image", img: "img/ant.png" },
      { id: "spider", en: "Spider", vi: "Nhện", ex: "The spider is small.", kind: "image", img: "img/spider.png" },
      { id: "ladybug", en: "Ladybug", vi: "Bọ rùa", ex: "The ladybug is red.", kind: "image", img: "img/ladybug.png" },
      { id: "dragonfly", en: "Dragonfly", vi: "Chuồn chuồn", ex: "The dragonfly can fly.", kind: "image", img: "img/dragonfly.png" },
      { id: "snail", en: "Snail", vi: "Ốc sên", ex: "The snail is slow.", kind: "image", img: "img/snail.png" },
      { id: "worm", en: "Worm", vi: "Giun", ex: "I see a worm.", kind: "image", img: "img/worm.png" },
    ],
    sentences: [
      { en: "The butterfly is beautiful.", vi: "Bướm thật đẹp.", audio: "audio/sen_insects_1.mp3" },
      { en: "The bee can fly.", vi: "Ong biết bay.", audio: "audio/sen_insects_2.mp3" },
      { en: "I see an ant.", vi: "Tôi thấy một con kiến.", audio: "audio/sen_insects_3.mp3" },
      { en: "The spider is small.", vi: "Nhện nhỏ xíu.", audio: "audio/sen_insects_4.mp3" },
      { en: "The ladybug is red.", vi: "Bọ rùa màu đỏ.", audio: "audio/sen_insects_5.mp3" },
      { en: "The snail is slow.", vi: "Ốc sên bò chậm.", audio: "audio/sen_insects_6.mp3" },
    ]
  },
  {
    id: "snacks", level: 2, name: "Đồ ăn nhẹ", en: "Snacks", emoji: "🍪", color: "#FFD54F",
    words: [
      { id: "candy", en: "Candy", vi: "Kẹo", ex: "I like candy.", kind: "image", img: "img/candy.png" },
      { id: "cookie", en: "Cookie", vi: "Bánh quy", ex: "The cookie is sweet.", kind: "image", img: "img/cookie.png" },
      { id: "chocolate", en: "Chocolate", vi: "Sô cô la", ex: "I like chocolate.", kind: "image", img: "img/chocolate.png" },
      { id: "pizza", en: "Pizza", vi: "Pizza", ex: "I eat pizza.", kind: "image", img: "img/pizza.png" },
      { id: "hamburger", en: "Hamburger", vi: "Hamburger", ex: "The hamburger is yummy.", kind: "image", img: "img/hamburger.png" },
      { id: "sandwich", en: "Sandwich", vi: "Sandwich", ex: "The sandwich is big.", kind: "image", img: "img/sandwich.png" },
      { id: "popcorn", en: "Popcorn", vi: "Bắp rang", ex: "I like popcorn.", kind: "image", img: "img/popcorn.png" },
    ],
    sentences: [
      { en: "I like candy.", vi: "Tôi thích kẹo.", audio: "audio/sen_snacks_1.mp3" },
      { en: "The cookie is sweet.", vi: "Bánh quy ngọt.", audio: "audio/sen_snacks_2.mp3" },
      { en: "I eat pizza.", vi: "Tôi ăn pizza.", audio: "audio/sen_snacks_3.mp3" },
      { en: "The hamburger is yummy.", vi: "Bánh hamburger ngon.", audio: "audio/sen_snacks_4.mp3" },
      { en: "I like popcorn.", vi: "Tôi thích bắp rang.", audio: "audio/sen_snacks_5.mp3" },
      { en: "The sandwich is big.", vi: "Bánh sandwich to.", audio: "audio/sen_snacks_6.mp3" },
    ]
  },
  {
    id: "actions", level: 4, name: "Hành động", en: "Actions", emoji: "🏃", color: "#4DB6AC",
    words: [
      { id: "eat", en: "Eat", vi: "Ăn", ex: "I eat an apple.", kind: "image", img: "img/eat.png" },
      { id: "drink", en: "Drink", vi: "Uống", ex: "I drink milk.", kind: "image", img: "img/drink.png" },
      { id: "sleep", en: "Sleep", vi: "Ngủ", ex: "I sleep at night.", kind: "image", img: "img/sleep.png" },
      { id: "sing", en: "Sing", vi: "Hát", ex: "I can sing.", kind: "image", img: "img/sing.png" },
      { id: "dance", en: "Dance", vi: "Nhảy múa", ex: "She can dance.", kind: "image", img: "img/dance.png" },
      { id: "read", en: "Read", vi: "Đọc", ex: "I read a book.", kind: "image", img: "img/read.png" },
      { id: "write", en: "Write", vi: "Viết", ex: "I write my name.", kind: "image", img: "img/write.png" },
      { id: "draw", en: "Draw", vi: "Vẽ", ex: "He can draw.", kind: "image", img: "img/draw.png" },
    ],
    sentences: [
      { en: "I can sing.", vi: "Tôi biết hát.", audio: "audio/sen_actions_1.mp3" },
      { en: "She can dance.", vi: "Cô ấy biết nhảy múa.", audio: "audio/sen_actions_2.mp3" },
      { en: "I read a book.", vi: "Tôi đọc sách.", audio: "audio/sen_actions_3.mp3" },
      { en: "He can draw.", vi: "Anh ấy biết vẽ.", audio: "audio/sen_actions_4.mp3" },
      { en: "I write my name.", vi: "Tôi viết tên mình.", audio: "audio/sen_actions_5.mp3" },
      { en: "We eat rice.", vi: "Chúng tôi ăn cơm.", audio: "audio/sen_actions_6.mp3" },
    ]
  },
  {
    id: "adjectives", level: 4, name: "Tính từ", en: "Adjectives", emoji: "📏", color: "#7986CB",
    words: [
      { id: "big", en: "Big", vi: "To", ex: "The bear is big.", kind: "image", img: "img/big.png" },
      { id: "small", en: "Small", vi: "Nhỏ", ex: "The ant is small.", kind: "image", img: "img/small.png" },
      { id: "long", en: "Long", vi: "Dài", ex: "The river is long.", kind: "image", img: "img/long.png" },
      { id: "short", en: "Short", vi: "Ngắn", ex: "The ruler is short.", kind: "image", img: "img/short.png" },
      { id: "tall", en: "Tall", vi: "Cao", ex: "The tree is tall.", kind: "image", img: "img/tall.png" },
      { id: "fast", en: "Fast", vi: "Nhanh", ex: "The rabbit is fast.", kind: "image", img: "img/fast.png" },
      { id: "slow", en: "Slow", vi: "Chậm", ex: "The snail is slow.", kind: "image", img: "img/slow.png" },
      { id: "new", en: "New", vi: "Mới", ex: "My bag is new.", kind: "image", img: "img/new.png" },
    ],
    sentences: [
      { en: "The bear is big.", vi: "Gấu to lớn.", audio: "audio/sen_adjectives_1.mp3" },
      { en: "The ant is small.", vi: "Kiến nhỏ xíu.", audio: "audio/sen_adjectives_2.mp3" },
      { en: "The river is long.", vi: "Dòng sông dài.", audio: "audio/sen_adjectives_3.mp3" },
      { en: "The ruler is short.", vi: "Thước kẻ ngắn.", audio: "audio/sen_adjectives_4.mp3" },
      { en: "The tree is tall.", vi: "Cái cây cao.", audio: "audio/sen_adjectives_5.mp3" },
      { en: "The rabbit is fast.", vi: "Thỏ chạy nhanh.", audio: "audio/sen_adjectives_6.mp3" },
    ]
  },
  {
    id: "time", level: 5, name: "Thời gian", en: "Time", emoji: "⏰", color: "#90A4AE",
    words: [
      { id: "morning", en: "Morning", vi: "Buổi sáng", ex: "Good morning!", kind: "image", img: "img/morning.png" },
      { id: "afternoon", en: "Afternoon", vi: "Buổi chiều", ex: "Good afternoon!", kind: "image", img: "img/afternoon.png" },
      { id: "evening", en: "Evening", vi: "Buổi tối", ex: "Good evening!", kind: "image", img: "img/evening.png" },
      { id: "night", en: "Night", vi: "Ban đêm", ex: "Good night!", kind: "image", img: "img/night.png" },
      { id: "today", en: "Today", vi: "Hôm nay", ex: "I am happy today.", kind: "image", img: "img/today.png" },
      { id: "tomorrow", en: "Tomorrow", vi: "Ngày mai", ex: "See you tomorrow!", kind: "image", img: "img/tomorrow.png" },
    ],
    sentences: [
      { en: "Good morning!", vi: "Chào buổi sáng!", audio: "audio/sen_time_1.mp3" },
      { en: "Good afternoon!", vi: "Chào buổi chiều!", audio: "audio/sen_time_2.mp3" },
      { en: "Good evening!", vi: "Chào buổi tối!", audio: "audio/sen_time_3.mp3" },
      { en: "Good night!", vi: "Chúc ngủ ngon!", audio: "audio/sen_time_4.mp3" },
      { en: "I am happy today.", vi: "Hôm nay tôi rất vui.", audio: "audio/sen_time_5.mp3" },
      { en: "See you tomorrow!", vi: "Hẹn gặp lại ngày mai!", audio: "audio/sen_time_6.mp3" },
    ]
  },
  {
    id: "sea", level: 2, name: "Động vật biển", en: "Sea Animals", emoji: "🐬", color: "#4FC3F7",
    words: [
      { id: "dolphin", en: "Dolphin", vi: "Cá heo", ex: "The dolphin is smart.", kind: "image", img: "img/dolphin.png" },
      { id: "shark", en: "Shark", vi: "Cá mập", ex: "The shark is big.", kind: "image", img: "img/shark.png" },
      { id: "octopus", en: "Octopus", vi: "Bạch tuộc", ex: "The octopus has eight arms.", kind: "image", img: "img/octopus.png" },
      { id: "crab", en: "Crab", vi: "Con cua", ex: "The crab is red.", kind: "image", img: "img/crab.png" },
      { id: "turtle", en: "Turtle", vi: "Rùa biển", ex: "The turtle swims slowly.", kind: "image", img: "img/turtle.png" },
      { id: "whale", en: "Whale", vi: "Cá voi", ex: "The whale is huge.", kind: "image", img: "img/whale.png" },
      { id: "seahorse", en: "Seahorse", vi: "Cá ngựa", ex: "The seahorse is small.", kind: "image", img: "img/seahorse.png" },
      { id: "starfish", en: "Starfish", vi: "Sao biển", ex: "The starfish has five arms.", kind: "image", img: "img/starfish.png" }
    ],
    sentences: [
      { en: "The dolphin jumps high.", vi: "Cá heo nhảy cao.", audio: "audio/sen_sea_1.mp3" },
      { en: "I see a big shark.", vi: "Tôi thấy một con cá mập to.", audio: "audio/sen_sea_2.mp3" },
      { en: "The crab walks sideways.", vi: "Con cua đi ngang.", audio: "audio/sen_sea_3.mp3" },
      { en: "A turtle swims in the sea.", vi: "Một con rùa bơi trong biển.", audio: "audio/sen_sea_4.mp3" },
      { en: "The octopus has eight arms.", vi: "Bạch tuộc có tám xúc tu.", audio: "audio/sen_sea_5.mp3" },
      { en: "The whale sings a song.", vi: "Cá voi hát một bài hát.", audio: "audio/sen_sea_6.mp3" }
    ]
  },
  {
    id: "space", level: 4, name: "Vũ trụ", en: "Space", emoji: "🚀", color: "#5C6BC0",
    words: [
      { id: "moon", en: "Moon", vi: "Mặt trăng", ex: "The moon is round.", kind: "image", img: "img/moon.png" },
      { id: "sun", en: "Sun", vi: "Mặt trời", ex: "The sun is hot.", kind: "image", img: "img/sun.png" },
      { id: "rocket", en: "Rocket", vi: "Tên lửa", ex: "The rocket flies high.", kind: "image", img: "img/rocket.png" },
      { id: "planet", en: "Planet", vi: "Hành tinh", ex: "The Earth is a planet.", kind: "image", img: "img/planet.png" },
      { id: "astronaut", en: "Astronaut", vi: "Phi hành gia", ex: "The astronaut wears a suit.", kind: "image", img: "img/astronaut.png" },
      { id: "telescope", en: "Telescope", vi: "Kính viễn vọng", ex: "I see the moon with a telescope.", kind: "image", img: "img/telescope.png" },
      { id: "comet", en: "Comet", vi: "Sao chổi", ex: "The comet has a long tail.", kind: "image", img: "img/comet.png" },
      { id: "satellite", en: "Satellite", vi: "Vệ tinh", ex: "The satellite is in space.", kind: "image", img: "img/satellite.png" }
    ],
    sentences: [
      { en: "The moon is round and bright.", vi: "Mặt trăng tròn và sáng.", audio: "audio/sen_space_1.mp3" },
      { en: "I want to be an astronaut.", vi: "Tôi muốn làm phi hành gia.", audio: "audio/sen_space_2.mp3" },
      { en: "The rocket flies to space.", vi: "Tên lửa bay vào vũ trụ.", audio: "audio/sen_space_3.mp3" },
      { en: "Stars shine at night.", vi: "Các ngôi sao tỏa sáng vào ban đêm.", audio: "audio/sen_space_4.mp3" },
      { en: "The sun gives us light.", vi: "Mặt trời cho chúng ta ánh sáng.", audio: "audio/sen_space_5.mp3" },
      { en: "Look at the red planet!", vi: "Nhìn hành tinh đỏ kìa!", audio: "audio/sen_space_6.mp3" }
    ]
  },
  {
    id: "music", level: 3, name: "Nhạc cụ", en: "Music", emoji: "🎵", color: "#F06292",
    words: [
      { id: "guitar", en: "Guitar", vi: "Đàn guitar", ex: "I play the guitar.", kind: "image", img: "img/guitar.png" },
      { id: "drum", en: "Drum", vi: "Cái trống", ex: "The drum is loud.", kind: "image", img: "img/drum.png" },
      { id: "piano", en: "Piano", vi: "Đàn piano", ex: "She plays the piano.", kind: "image", img: "img/piano.png" },
      { id: "flute", en: "Flute", vi: "Sáo", ex: "The flute is long.", kind: "image", img: "img/flute.png" },
      { id: "trumpet", en: "Trumpet", vi: "Kèn trumpet", ex: "He plays the trumpet.", kind: "image", img: "img/trumpet.png" },
      { id: "violin", en: "Violin", vi: "Đàn violin", ex: "The violin is small.", kind: "image", img: "img/violin.png" },
      { id: "microphone", en: "Microphone", vi: "Micro", ex: "Sing into the microphone.", kind: "image", img: "img/microphone.png" },
      { id: "saxophone", en: "Saxophone", vi: "Kèn saxophone", ex: "The saxophone is shiny.", kind: "image", img: "img/saxophone.png" }
    ],
    sentences: [
      { en: "I play the guitar every day.", vi: "Tôi chơi đàn guitar mỗi ngày.", audio: "audio/sen_music_1.mp3" },
      { en: "The drum goes boom boom.", vi: "Cái trống kêu bùm bùm.", audio: "audio/sen_music_2.mp3" },
      { en: "She sings into the microphone.", vi: "Cô ấy hát vào micro.", audio: "audio/sen_music_3.mp3" },
      { en: "The piano has black and white keys.", vi: "Đàn piano có phím đen và trắng.", audio: "audio/sen_music_4.mp3" },
      { en: "We dance to the music.", vi: "Chúng tôi nhảy theo nhạc.", audio: "audio/sen_music_5.mp3" },
      { en: "He plays a loud trumpet.", vi: "Anh ấy thổi kèn trumpet to.", audio: "audio/sen_music_6.mp3" }
    ]
  },
  {
    id: "drinks", level: 1, name: "Đồ uống", en: "Drinks", emoji: "🥛", color: "#FFB74D",
    words: [
      { id: "water", en: "Water", vi: "Nước", ex: "Drink some water.", kind: "image", img: "img/water.png" },
      { id: "tea", en: "Tea", vi: "Trà", ex: "Mom drinks tea.", kind: "image", img: "img/tea.png" },
      { id: "lemonade", en: "Lemonade", vi: "Nước chanh", ex: "Lemonade is sour.", kind: "image", img: "img/lemonade.png" },
      { id: "soda", en: "Soda", vi: "Nước ngọt có ga", ex: "Soda has bubbles.", kind: "image", img: "img/soda.png" },
      { id: "coffee", en: "Coffee", vi: "Cà phê", ex: "Dad drinks coffee.", kind: "image", img: "img/coffee.png" },
      { id: "smoothie", en: "Smoothie", vi: "Sinh tố", ex: "A strawberry smoothie, please.", kind: "image", img: "img/smoothie.png" },
      { id: "coconut", en: "Coconut", vi: "Nước dừa", ex: "I drink coconut juice.", kind: "image", img: "img/coconut.png" },
      { id: "yogurt", en: "Yogurt", vi: "Sữa chua", ex: "Yogurt is yummy.", kind: "image", img: "img/yogurt.png" }
    ],
    sentences: [
      { en: "I drink milk every morning.", vi: "Tôi uống sữa mỗi sáng.", audio: "audio/sen_drinks_1.mp3" },
      { en: "Water is good for you.", vi: "Nước tốt cho bạn.", audio: "audio/sen_drinks_2.mp3" },
      { en: "Orange juice is my favorite.", vi: "Nước cam là món tôi thích nhất.", audio: "audio/sen_drinks_3.mp3" },
      { en: "Mom makes fresh lemonade.", vi: "Mẹ làm nước chanh tươi.", audio: "audio/sen_drinks_4.mp3" },
      { en: "Do you want some tea?", vi: "Bạn có muốn uống trà không?", audio: "audio/sen_drinks_5.mp3" },
      { en: "The smoothie is cold and sweet.", vi: "Sinh tố lạnh và ngọt.", audio: "audio/sen_drinks_6.mp3" }
    ]
  },
  // ---------- 4 CHỦ ĐỀ MỚI (v1.5) ----------
  {
    id: "toys", level: 2, name: "Đồ chơi", en: "Toys", emoji: "🧸", color: "#FF8A65",
    words: [
      { id: "teddy",   en: "Teddy bear", vi: "Gấu bông",          ex: "I hug my teddy bear.",        kind: "emoji", emoji: "🧸" },
      { id: "robot",   en: "Robot",      vi: "Người máy",         ex: "The robot can walk.",          kind: "emoji", emoji: "🤖" },
      { id: "puzzle",  en: "Puzzle",     vi: "Trò chơi xếp hình", ex: "I do a puzzle.",              kind: "emoji", emoji: "🧩" },
      { id: "blocks",  en: "Blocks",     vi: "Khối xếp hình",     ex: "I build with blocks.",        kind: "emoji", emoji: "🧱" },
      { id: "yoyo",    en: "Yo-yo",      vi: "Cái yo-yo",         ex: "The yo-yo goes up and down.", kind: "emoji", emoji: "🪀" },
      { id: "balloon", en: "Balloon",    vi: "Quả bóng bay",      ex: "The balloon is red.",         kind: "emoji", emoji: "🎈" },
      { id: "top",     en: "Spinning top", vi: "Con quay",        ex: "The top spins fast.",         kind: "emoji", emoji: "🌀" },
      { id: "gamepad", en: "Gamepad",    vi: "Tay cầm chơi game", ex: "I play with a gamepad.",     kind: "emoji", emoji: "🎮" },
    ],
    sentences: [
      { en: "I hug my teddy bear.", vi: "Tôi ôm gấu bông của mình.", audio: "audio/sen_toys_1.mp3" },
      { en: "The robot can walk and talk.", vi: "Người máy biết đi và biết nói.", audio: "audio/sen_toys_2.mp3" },
      { en: "I build a tower with blocks.", vi: "Tôi xếp tháp bằng các khối hình.", audio: "audio/sen_toys_3.mp3" },
      { en: "The balloon flies up high.", vi: "Quả bóng bay lên cao.", audio: "audio/sen_toys_4.mp3" },
      { en: "We play with toys together.", vi: "Chúng tôi chơi đồ chơi cùng nhau.", audio: "audio/sen_toys_5.mp3" },
      { en: "My yo-yo goes up and down.", vi: "Yo-yo của tôi lên xuống liên tục.", audio: "audio/sen_toys_6.mp3" },
    ]
  },
  {
    id: "beach", level: 2, name: "Bãi biển", en: "Beach", emoji: "🏖️", color: "#4FC3F7",
    words: [
      { id: "sand",       en: "Sand",        vi: "Cát",            ex: "I play with sand.",      kind: "emoji", emoji: "⏳" },
      { id: "shell",      en: "Shell",       vi: "Vỏ sò",          ex: "I find a shell.",        kind: "emoji", emoji: "🐚" },
      { id: "beachball",  en: "Beach ball",  vi: "Bóng bãi biển",  ex: "We play beach ball.",   kind: "emoji", emoji: "🏐" },
      { id: "umbrella",   en: "Umbrella",    vi: "Cái ô",           ex: "We sit under the umbrella.", kind: "emoji", emoji: "⛱️" },
      { id: "wave",       en: "Wave",        vi: "Sóng biển",      ex: "The wave is big.",      kind: "emoji", emoji: "🌊" },
      { id: "bucket",     en: "Bucket",      vi: "Cái xô",          ex: "I fill the bucket.",    kind: "emoji", emoji: "🪣" },
      { id: "sunglasses", en: "Sunglasses",  vi: "Kính râm",        ex: "I wear sunglasses.",    kind: "emoji", emoji: "🕶️" },
      { id: "sandcastle", en: "Sandcastle",  vi: "Lâu đài cát",    ex: "I build a sandcastle.", kind: "emoji", emoji: "🏰" },
    ],
    sentences: [
      { en: "We play at the beach.", vi: "Chúng tôi chơi ở bãi biển.", audio: "audio/sen_beach_1.mp3" },
      { en: "I build a sandcastle.", vi: "Tôi xây lâu đài cát.", audio: "audio/sen_beach_2.mp3" },
      { en: "The waves are big today.", vi: "Hôm nay sóng to.", audio: "audio/sen_beach_3.mp3" },
      { en: "I find a pretty shell.", vi: "Tôi nhặt được một vỏ sò đẹp.", audio: "audio/sen_beach_4.mp3" },
      { en: "We swim in the sea.", vi: "Chúng tôi bơi ở biển.", audio: "audio/sen_beach_5.mp3" },
      { en: "I wear my sunglasses.", vi: "Tôi đeo kính râm.", audio: "audio/sen_beach_6.mp3" },
    ]
  },
  {
    id: "kitchen", level: 3, name: "Nhà bếp", en: "Kitchen", emoji: "🍳", color: "#FFB74D",
    words: [
      { id: "plate",      en: "Plate",      vi: "Cái đĩa",         ex: "The plate is round.",   kind: "emoji", emoji: "🍽️" },
      { id: "cup",        en: "Cup",        vi: "Cái cốc",         ex: "I drink from a cup.",   kind: "emoji", emoji: "🥤" },
      { id: "spoon",      en: "Spoon",      vi: "Cái thìa",        ex: "I eat with a spoon.",   kind: "emoji", emoji: "🥄" },
      { id: "fork",       en: "Fork",       vi: "Cái dĩa ăn",      ex: "I eat with a fork.",    kind: "emoji", emoji: "🍴" },
      { id: "pot",        en: "Pot",        vi: "Cái nồi",         ex: "Mom cooks in a pot.",   kind: "emoji", emoji: "🍲" },
      { id: "pan",        en: "Pan",        vi: "Cái chảo",        ex: "Dad fries in a pan.",   kind: "emoji", emoji: "🍳" },
      { id: "bowl",       en: "Bowl",       vi: "Cái bát",         ex: "I eat rice from a bowl.", kind: "emoji", emoji: "🍚" },
      { id: "chopsticks", en: "Chopsticks", vi: "Đôi đũa",        ex: "I use chopsticks.",     kind: "emoji", emoji: "🥢" },
    ],
    sentences: [
      { en: "Mom cooks in the kitchen.", vi: "Mẹ nấu ăn trong bếp.", audio: "audio/sen_kitchen_1.mp3" },
      { en: "I eat rice with chopsticks.", vi: "Tôi ăn cơm bằng đũa.", audio: "audio/sen_kitchen_2.mp3" },
      { en: "The soup is in the bowl.", vi: "Canh ở trong bát.", audio: "audio/sen_kitchen_3.mp3" },
      { en: "Dad fries eggs in a pan.", vi: "Bố rán trứng bằng chảo.", audio: "audio/sen_kitchen_4.mp3" },
      { en: "Please give me a spoon.", vi: "Cho tôi một cái thìa.", audio: "audio/sen_kitchen_5.mp3" },
      { en: "We wash the plates together.", vi: "Chúng tôi rửa đĩa cùng nhau.", audio: "audio/sen_kitchen_6.mp3" },
    ]
  },
  {
    id: "camping", level: 4, name: "Cắm trại", en: "Camping", emoji: "⛺", color: "#81C784",
    words: [
      { id: "tent",        en: "Tent",         vi: "Cái lều",      ex: "We sleep in a tent.",      kind: "emoji", emoji: "⛺" },
      { id: "campfire",    en: "Campfire",     vi: "Lửa trại",      ex: "We sit by the campfire.", kind: "emoji", emoji: "🔥" },
      { id: "backpack",    en: "Backpack",     vi: "Ba lô",         ex: "I carry a backpack.",    kind: "emoji", emoji: "🎒" },
      { id: "flashlight",  en: "Flashlight",   vi: "Đèn pin",       ex: "I have a flashlight.",   kind: "emoji", emoji: "🔦" },
      { id: "sleepingbag", en: "Sleeping bag", vi: "Túi ngủ",       ex: "I sleep in a sleeping bag.", kind: "emoji", emoji: "🛏️" },
      { id: "marshmallow", en: "Marshmallow",  vi: "Kẹo dẻo",       ex: "I roast a marshmallow.", kind: "emoji", emoji: "🍡" },
      { id: "compass",     en: "Compass",      vi: "La bàn",        ex: "We use a compass.",      kind: "emoji", emoji: "🧭" },
      { id: "binoculars",  en: "Binoculars",   vi: "Ống nhòm",      ex: "I see birds with binoculars.", kind: "emoji", emoji: "🔭" },
    ],
    sentences: [
      { en: "We go camping in the forest.", vi: "Chúng tôi đi cắm trại trong rừng.", audio: "audio/sen_camping_1.mp3" },
      { en: "We sleep in a tent.", vi: "Chúng tôi ngủ trong lều.", audio: "audio/sen_camping_2.mp3" },
      { en: "We sit by the campfire.", vi: "Chúng tôi ngồi bên lửa trại.", audio: "audio/sen_camping_3.mp3" },
      { en: "I see many stars at night.", vi: "Tôi ngắm nhiều sao vào ban đêm.", audio: "audio/sen_camping_4.mp3" },
      { en: "We roast marshmallows.", vi: "Chúng tôi nướng kẹo dẻo.", audio: "audio/sen_camping_5.mp3" },
      { en: "Camping is so fun!", vi: "Đi cắm trại thật vui!", audio: "audio/sen_camping_6.mp3" },
    ]
  }
];

const STORIES = [
  {
    id: "story1", title: "My Cat", vi: "Con mèo của tôi", emoji: "🐱",
    pages: [
      { img: "img/cat.png",  en: "This is my cat.",      vi: "Đây là con mèo của tôi.",   audio: "audio/story1_p1.mp3" },
      { img: "img/fish.png", en: "My cat likes fish.",   vi: "Mèo của tôi thích ăn cá.",  audio: "audio/story1_p2.mp3" },
      { img: "img/milk.png", en: "My cat drinks milk.",  vi: "Mèo của tôi uống sữa.",     audio: "audio/story1_p3.mp3" },
      { img: "img/cat.png",  en: "I love my cat!",       vi: "Tôi yêu con mèo của tôi!",  audio: "audio/story1_p4.mp3" },
    ]
  },
  {
    id: "story2", title: "I Like Fruit", vi: "Tôi thích trái cây", emoji: "🍓",
    pages: [
      { img: "img/apple.png",  en: "I like apples.",      vi: "Tôi thích táo.",          audio: "audio/story2_p1.mp3" },
      { img: "img/banana.png", en: "I like bananas.",     vi: "Tôi thích chuối.",        audio: "audio/story2_p2.mp3" },
      { img: "img/cake.png",   en: "I like cake, too.",   vi: "Tôi cũng thích bánh kem.", audio: "audio/story2_p3.mp3" },
      { img: "img/apple.png",  en: "Fruit is good for me!", vi: "Trái cây rất tốt cho tôi!", audio: "audio/story2_p4.mp3" },
    ]
  },
  {
    id: "story3", title: "My Family", vi: "Gia đình tôi", emoji: "👪",
    pages: [
      { img: "img/father.png",      en: "This is my father.",     vi: "Đây là bố của tôi.",        audio: "audio/story3_p1.mp3" },
      { img: "img/mother.png",      en: "This is my mother.",     vi: "Đây là mẹ của tôi.",        audio: "audio/story3_p2.mp3" },
      { img: "img/baby.png",        en: "This is my baby brother.", vi: "Đây là em trai bé bỏng của tôi.", audio: "audio/story3_p3.mp3" },
      { img: "img/grandmother.png", en: "I love my family!",      vi: "Tôi yêu gia đình của tôi!", audio: "audio/story3_p4.mp3" },
    ]
  },
  {
    id: "story4", title: "Momo Goes to the Sea", vi: "Momo đi biển", emoji: "🏖️",
    pages: [
      { img: "img/sea.png",   en: "Momo goes to the sea.", vi: "Momo đi ra biển.",           audio: "audio/story4_p1.mp3" },
      { img: "img/sunny.png", en: "It is sunny today.",    vi: "Hôm nay trời nắng đẹp.",     audio: "audio/story4_p2.mp3" },
      { img: "img/fish.png",  en: "Momo sees a fish.",     vi: "Momo nhìn thấy một con cá.", audio: "audio/story4_p3.mp3" },
      { img: "img/happy.png", en: "Momo is happy!",        vi: "Momo rất vui!",              audio: "audio/story4_p4.mp3" },
    ]
  },
  {
    id: "story5", title: "Momo's Day", vi: "Một ngày của Momo", emoji: "🌙",
    pages: [
      { img: "img/hungry.png", en: "Momo is hungry.",   vi: "Momo thấy đói bụng.",   audio: "audio/story5_p1.mp3" },
      { img: "img/cake.png",   en: "Momo eats a cake.", vi: "Momo ăn một cái bánh.", audio: "audio/story5_p2.mp3" },
      { img: "img/sleepy.png", en: "Momo is sleepy.",   vi: "Momo buồn ngủ quá.",    audio: "audio/story5_p3.mp3" },
      { img: "img/bed.png",    en: "Good night, Momo!", vi: "Chúc Momo ngủ ngon!",   audio: "audio/story5_p4.mp3" },
    ]
  },
  {
    id: "story6", title: "Momo's Breakfast", vi: "Bữa sáng của Momo", emoji: "🍳",
    pages: [
      { img: "img/egg.png",   en: "Momo eats an egg.",  vi: "Momo ăn một quả trứng.", audio: "audio/story6_p1.mp3" },
      { img: "img/milk.png",  en: "Momo drinks milk.",  vi: "Momo uống sữa.",         audio: "audio/story6_p2.mp3" },
      { img: "img/bread.png", en: "Momo eats bread.",   vi: "Momo ăn bánh mì.",       audio: "audio/story6_p3.mp3" },
      { img: "img/happy.png", en: "Yummy! Momo is happy!", vi: "Ngon quá! Momo vui lắm!", audio: "audio/story6_p4.mp3" },
    ]
  },
  {
    id: "story7", title: "In the Garden", vi: "Trong vườn", emoji: "🌻",
    pages: [
      { img: "img/flower.png",    en: "Momo sees a flower.",   vi: "Momo thấy một bông hoa.", audio: "audio/story7_p1.mp3" },
      { img: "img/butterfly.png", en: "A butterfly is beautiful.", vi: "Bướm thật đẹp.",       audio: "audio/story7_p2.mp3" },
      { img: "img/bee.png",       en: "The bee is busy.",      vi: "Ong đang bận rộn.",       audio: "audio/story7_p3.mp3" },
      { img: "img/sky.png",       en: "Momo loves the garden!", vi: "Momo yêu khu vườn!",     audio: "audio/story7_p4.mp3" },
    ]
  },
  {
    id: "story8", title: "Momo's Toys", vi: "Đồ chơi của Momo", emoji: "🧸",
    pages: [
      { img: "img/ball.png",  en: "Momo has a ball.",   vi: "Momo có một quả bóng.", audio: "audio/story8_p1.mp3" },
      { img: "img/kite.png",  en: "Momo flies a kite.", vi: "Momo thả diều.",        audio: "audio/story8_p2.mp3" },
      { img: "img/doll.png",  en: "Momo hugs the doll.", vi: "Momo ôm búp bê.",      audio: "audio/story8_p3.mp3" },
      { img: "img/happy.png", en: "What fun!",          vi: "Vui quá đi!",           audio: "audio/story8_p4.mp3" },
    ]
  },
  {
    id: "story9", title: "Rainy Day", vi: "Ngày mưa", emoji: "🌧️",
    pages: [
      { img: "img/rainy.png", en: "It is rainy today.",  vi: "Hôm nay trời mưa.",   audio: "audio/story9_p1.mp3" },
      { img: "img/house.png", en: "Momo stays at home.", vi: "Momo ở nhà.",         audio: "audio/story9_p2.mp3" },
      { img: "img/book.png",  en: "Momo reads a book.",  vi: "Momo đọc sách.",      audio: "audio/story9_p3.mp3" },
      { img: "img/happy.png", en: "Momo is happy!",      vi: "Momo rất vui!",       audio: "audio/story9_p4.mp3" },
    ]
  },
  {
    id: "story10", title: "Momo Learns Shapes", vi: "Momo học hình dạng", emoji: "🔷",
    pages: [
      { img: "img/circle.png", en: "This is a circle.", vi: "Đây là hình tròn.",   audio: "audio/story10_p1.mp3" },
      { img: "img/square.png", en: "This is a square.", vi: "Đây là hình vuông.",  audio: "audio/story10_p2.mp3" },
      { img: "img/star.png",   en: "This is a star.",   vi: "Đây là ngôi sao.",    audio: "audio/story10_p3.mp3" },
      { img: "img/happy.png",  en: "Momo knows shapes!", vi: "Momo biết các hình rồi!", audio: "audio/story10_p4.mp3" },
    ]
  },
  {
    id: "story11", title: "Good Morning!", vi: "Chào buổi sáng!", emoji: "🌅",
    pages: [
      { img: "img/morning.png", en: "Good morning, Momo!", vi: "Chào buổi sáng, Momo!", audio: "audio/story11_p1.mp3" },
      { img: "img/bread.png",   en: "Momo eats bread.",    vi: "Momo ăn bánh mì.",      audio: "audio/story11_p2.mp3" },
      { img: "img/book.png",    en: "Momo reads a book.",  vi: "Momo đọc sách.",        audio: "audio/story11_p3.mp3" },
      { img: "img/happy.png",   en: "Have a nice day!",    vi: "Chúc một ngày vui vẻ!", audio: "audio/story11_p4.mp3" },
    ]
  },
  {
    id: "story12", title: "Momo's Birthday", vi: "Sinh nhật Momo", emoji: "🎂",
    pages: [
      { img: "img/cake.png",   en: "Today is Momo's birthday!", vi: "Hôm nay là sinh nhật của Momo!", audio: "audio/story12_p1.mp3" },
      { img: "img/monkey.png", en: "Friends come to the party.", vi: "Các bạn đến dự tiệc.",          audio: "audio/story12_p2.mp3" },
      { img: "img/star.png",   en: "Momo makes a wish.",          vi: "Momo ước một điều.",            audio: "audio/story12_p3.mp3" },
      { img: "img/happy.png",  en: "Happy birthday, Momo!",       vi: "Chúc mừng sinh nhật, Momo!",    audio: "audio/story12_p4.mp3" },
    ]
  },
  {
    id: "story13", title: "Momo Goes Camping", vi: "Momo đi cắm trại", emoji: "⛺",
    pages: [
      { img: "img/tree.png",   en: "Momo goes camping in the forest.", vi: "Momo đi cắm trại trong rừng.", audio: "audio/story13_p1.mp3" },
      { img: "img/monkey.png", en: "Momo sleeps in a tent.",           vi: "Momo ngủ trong lều.",           audio: "audio/story13_p2.mp3" },
      { img: "img/star.png",   en: "Momo sees many stars at night.",   vi: "Momo ngắm nhiều sao vào ban đêm.", audio: "audio/story13_p3.mp3" },
      { img: "img/happy.png",  en: "Camping is so fun!",               vi: "Đi cắm trại thật vui!",          audio: "audio/story13_p4.mp3" },
    ]
  },
];

// Âm thanh hướng dẫn / khen thưởng (tiếng Anh)

const SONGS = [
  { id: "song_abc",     title: "ABC Song",            vi: "Bài hát bảng chữ cái", emoji: "🔤",
    lyrics: "A B C D E F G,\nH I J K L M N O P,\nQ R S, T U V,\nW X, Y and Z!\nNow I know my ABCs,\nnext time won't you sing with me!",
    audio: "audio/song_abc.mp3" },
  { id: "song_twinkle", title: "Twinkle Twinkle",     vi: "Lấp lánh ngôi sao nhỏ", emoji: "⭐",
    lyrics: "Twinkle, twinkle, little star,\nhow I wonder what you are!\nUp above the world so high,\nlike a diamond in the sky.\nTwinkle, twinkle, little star,\nhow I wonder what you are!",
    audio: "audio/song_twinkle.mp3" },
  { id: "song_baa",     title: "Baa Baa Black Sheep", vi: "Cừu đen Baa Baa",       emoji: "🐑",
    lyrics: "Baa, baa, black sheep,\nhave you any wool?\nYes sir, yes sir,\nthree bags full!\nOne for the master,\none for the dame,\none for the little boy\nwho lives down the lane.",
    audio: "audio/song_baa.mp3" },
  { id: "song_row",     title: "Row Your Boat",       vi: "Chèo thuyền",            emoji: "🚣",
    lyrics: "Row, row, row your boat,\ngently down the stream.\nMerrily, merrily, merrily, merrily,\nlife is but a dream!",
    audio: "audio/song_row.mp3" },
  { id: "song_head",    title: "Head, Shoulders, Knees and Toes", vi: "Đầu, vai, đầu gối và ngón chân", emoji: "🧍",
    lyrics: "Head, shoulders, knees and toes,\nknees and toes!\nHead, shoulders, knees and toes,\nknees and toes!\nAnd eyes, and ears, and mouth, and nose!\nHead, shoulders, knees and toes,\nknees and toes!",
    audio: "audio/song_head.mp3" },
  { id: "song_happy",   title: "If You're Happy",     vi: "Nếu bé vui",             emoji: "😊",
    lyrics: "If you're happy and you know it, clap your hands!\nIf you're happy and you know it, clap your hands!\nIf you're happy and you know it, then your face will surely show it!\nIf you're happy and you know it, clap your hands!",
    audio: "audio/song_happy.mp3" },
];

const ALPHABET = [
  ["A","apple"],["B","ball"],["C","cat"],["D","dog"],["E","egg"],["F","fish"],
  ["G","grape"],["H","happy"],["I","icecream"],["J","juice"],["K","kite"],["L","lion"],
  ["M","monkey"],["N","nose"],["O","onion"],["P","panda"],["Q",null],["R","rabbit"],
  ["S","sea"],["T","tiger"],["U","uncle"],["V",null],["W","window"],["X",null],
  ["Y","yellow"],["Z",null],
];

const UI_AUDIO = {
  listen:   "audio/ui_listen.mp3",
  word:     "audio/ui_word.mp3",
  memory:   "audio/ui_memory.mp3",
  sentence: "audio/ui_sentence.mp3",
  spell:    "audio/ui_spell.mp3",
  pet_yum:  "audio/ui_pet_yum.mp3",
  hello:    "audio/ui_hello.mp3",
  senlisten: "audio/ui_senlisten.mp3",
  nav_home: "audio/ui_nav_home.mp3", nav_topics: "audio/ui_nav_topics.mp3",
  nav_learn: "audio/ui_nav_learn.mp3", nav_games: "audio/ui_nav_games.mp3",
  nav_sentences: "audio/ui_nav_sentences.mp3", nav_stories: "audio/ui_nav_stories.mp3",
  nav_songs: "audio/ui_nav_songs.mp3", nav_abc: "audio/ui_nav_abc.mp3",
  nav_trace: "audio/ui_nav_trace.mp3", nav_daily: "audio/ui_nav_daily.mp3",
  nav_pet: "audio/ui_nav_pet.mp3", nav_dict: "audio/ui_nav_dict.mp3",
  nav_progress: "audio/ui_nav_progress.mp3",
  guide_listen: "audio/ui_guide_listen.mp3", guide_word: "audio/ui_guide_word.mp3",
  guide_memory: "audio/ui_guide_memory.mp3", guide_sentence: "audio/ui_guide_sentence.mp3",
  guide_spell: "audio/ui_guide_spell.mp3", guide_senlisten: "audio/ui_guide_senlisten.mp3",
  guide_oddone: "audio/ui_guide_oddone.mp3", guide_truefalse: "audio/ui_guide_truefalse.mp3",
  guide_counting: "audio/ui_guide_counting.mp3",
  oddone: "audio/ui_oddone.mp3", truefalse: "audio/ui_truefalse.mp3",
  counting: "audio/ui_counting.mp3", welcome: "audio/ui_welcome.mp3",
  great:    "audio/ui_great.mp3",
  tryagain: "audio/ui_tryagain.mp3",
  welldone: "audio/ui_welldone.mp3",
  // Lời khen đa dạng kiểu Monkey Stories (khen đúng)
  praise1: "audio/ui_praise1.mp3", praise2: "audio/ui_praise2.mp3",
  praise3: "audio/ui_praise3.mp3", praise4: "audio/ui_praise4.mp3",
  praise5: "audio/ui_praise5.mp3", praise6: "audio/ui_praise6.mp3",
  // Lời khen / động viên tiếng Việt
  vipraise1: "audio/vi_praise1.mp3", vipraise2: "audio/vi_praise2.mp3",
  vipraise3: "audio/vi_praise3.mp3", vipraise4: "audio/vi_praise4.mp3",
  vitry1: "audio/vi_try1.mp3", vitry2: "audio/vi_try2.mp3",
};

// Tra cứu nhanh
const WORD_BY_ID = {};
THEMES.forEach(t => t.words.forEach(w => { WORD_BY_ID[w.id] = w; w.theme = t.id; }));
// Âm thanh tiếng Việt tự động: nghĩa của từ + bản dịch câu
THEMES.forEach(t => {
  t.words.forEach(w => { if (!w.audioVi) w.audioVi = "audio/vi_" + w.id + ".mp3"; });
  (t.sentences || []).forEach(s => { if (!s.audioVi) s.audioVi = s.audio.replace("sen_", "vi_sen_"); });
});
function allWords() { return THEMES.flatMap(t => t.words); }
function themeById(id) { return THEMES.find(t => t.id === id); }
function levelById(id) { return LEVELS.find(l => l.id === id); }
function themesOfLevel(lid) { return THEMES.filter(t => t.level === lid); }
function allSentences() {
  const out = [];
  THEMES.forEach(t => t.sentences.forEach((s, i) => out.push(Object.assign({ theme: t.id, idx: i }, s))));
  return out;
}
